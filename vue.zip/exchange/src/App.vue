<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
#app {
  height: 100%;
}
html,body{
    /*background: transparent!important;*/
    background: #fff!important;
    /*opacity: 0!important;*/
    width: 100%;
    height: 100%;
}
</style>






