import axios from 'axios'
import qs from 'qs'
import {getStore,removeStore} from '@/common/storage'
import {router,that} from '../main.js'


//api接口地址
const ApiUrl = () => {
    let apiUrl
    if(process.env.NODE_ENV === 'development'){
//       apiUrl = 'http://www.400.com/api.html'  //本地
//       apiUrl = 'https://devex.qztrip.cn/api.html'         //线上
         
         apiUrl = 'http://www.777.com/api.html'    //xs       
         

    }else if(process.env.NODE_ENV === 'production'){
//		apiUrl = 'http://www.400.com/api.html'	 //本地
//      apiUrl = 'https://devex.qztrip.cn/api.html'      //线上
 		apiUrl = 'http://www.777.com/api.html'    //xs    
    }
    return apiUrl
}

// 接口token验证
function post (method, data, callback) {
    data.method = method
    data.token = getStore('user_token')
    sendPost(ApiUrl(), qs.stringify(data), {}, callback)
}

// axios统一请求
function sendPost (url, data, config ={} ,callback){
    axios.post(url, data, callback).then( response => {
            // 异地登录，强制退出
        if(!response.data.status){
            if(response.data.data === 14007) {
                that.$dialog.toast({mes:response.data.msg,callback:()=>{
                    removeStore('twopassword')
                    router.replace({path:'/login'})
                }})
            }
        }
        
        // 11001 为系统关闭时间。强制退出。
        if(response.data.status === 11001){
            that.$dialog.toast({mes:response.data.msg,timeout:2000,callback:() =>{
                removeStore('twopassword')
                that.$router.push({path:'/login'})
                return;
            }})
        }
        callback(response.data)
    }).catch(err => {
    })
}


// 登陆
//export const login = (data, callback) => post('member.login', data, callback)


//注册
export const register = (data, callback) => post('user.register', data, callback)

//发送验证码
export const checkSms = (data, callback) => post('sms.send', data, callback)

//登入
export const login = (data, callback) => post('user.login', data, callback)

//退出登入
export const logout = (data, callback) => post('user.logout', data, callback)

//获取地区信息
export const indexs = (data, callback) => post('user.index', data, callback)

//忘记密码
export const resetpassword = (data, callback) => post('user.resetpassword', data, callback)
	

//新闻首页
export const newindex = (data, callback) => post('news.index', data, callback)

//新闻详情
export const newsinfor = (data, callback) => post('news.info', data, callback)

//广告
export const releaseIndex = (data, callback) => post('advertisement.releaseIndex', data, callback)

//修改广告
export const changeStatus = (data, callback) => post('advertisement.changeStatus', data, callback)

//发布广告
export const release = (data, callback) => post('advertisement.release', data, callback)