import Vue from 'vue'

Vue.filter('NumFormat', (value,num)=>{
    if(!value) return '0.00';
    let intPart =  Number(value)|0; // 获取整数部分(去除掉小数点后面的)
    let intPartFormat = intPart.toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,'); // 将整数部分逢三一断

    let intfloat = parseFloat(value).toFixed(num)
    let floatPart = intfloat.split(".")[1];
    return intPartFormat +"."+ floatPart   // 返回的为字符串，如要与数字大小判断切记先转为数字。

})
