<template>
	<div class="tabbar">
		<router-link class="tabbar-item" :id="item.active" v-for="(item, index) in tab" :to="item.link" :key="index" replace >
			<svg-icon :icon-class="item.black" v-show="!item.active" class="icon-tabbar"></svg-icon>
			<svg-icon :icon-class="item.orange" v-show='item.active' class="icon-tabbar"></svg-icon>
		<span>{{item.title}}</span>
		</router-link>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				tab: [{
						title: '行情',
						link: '/index',
						active: true,
						black: 'top_market',
						orange: 'top_market_green'
					},
					{
						title: '交易',
						link: '/transactions',
						active: false,
						black: 'top_trading',
						orange: 'top_trading_green'
					},
					{
						title: '资产',
						link: '/assets',
						active: false,
						black: 'top_market',
						orange: 'top_market_green'
					},
					{
						title: '动态',
						link: '/dynamics',
						active: false,
						black: 'top_dynamic',
						orange: 'top_dynamic_green'
					},
					{
						title: '我的',
						link: '/user',
						active: false,
						black: 'top_my',
						orange: 'top_my_green'
					},
				]
			}
		},
		watch: {
            '$route': {
                handler() {
                    for(let k in this.tab) {
                        if(this.tab[k].link === this.$route.path) {
                            this.tab[k].active = true
                        } else {
                            this.tab[k].active = false
                        }
                    }
                },
                //      是否立即執行
                immediate: true
            }
		},
		methods: {

		}
	}
</script>

<style lang="less" scoped>
	.tabbar {
		position: fixed;
		bottom: 0;
		background-color: #fff;
		border-top: 1px solid #e1e1e1;
		width: 100%;
		.tabbar-item {
			text-align: center;
			display: inline-block;
			width: 20%;
			box-sizing: border-box;
			padding: .15rem 0 .05rem;
			img{
				width: 24px;
				height: 22px;
			}
			span {
				display: block;
				color: #333333;
			}
		}
	}
	.icon-tabbar{
		font-size: 20px;
        text-align: center;
        margin:1px 0 1px 0;	
	}
	#true>i,
	#true>span {
		color: #287A81;
	}
</style>