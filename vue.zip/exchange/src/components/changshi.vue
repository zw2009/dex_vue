<template>
  <div>
    <div class="moreData">

    </div>
    <div class="banner" >
      <span v-for="(item,index) in banners"  :key='index'    @click="active(index)"  :class="Index == index?'activeclass':''">{{item.title}}</span>
    </div>
    <div v-for="(items,index) in banners" :key1='index' v-if="Index == index && showBanner" class="banner-bottom">
        <span v-for="(item,cindex) in items.list" :key1="cindex" @click="select(cindex)" :class="cIndex == cindex?'selectclass':''">{{item}}</span>
    </div>
    <ve-candle :data="chartData" :settings="chartSettings" style="padding: 0 10px;"></ve-candle>

  </div>
</template>
<script>
  export default {
    data () {
      this.chartSettings = {
        showVol: true,
        showMA: false,
        dataType:'KMB',
        showDataZoom: false,
        downColor:'#F66765',
        upColor:'#4DB374',
      }
      return {
        banners:[
        {title:'分时',list:['分时','1分','5分','15分','30分','1小时','2小时','4小时','6小时','12小时','日','周','月']},
        {title:'指标',list:['1121','22']},
        {title:'深度',list:['112','22']},
        {title:'XXXX',list:['1133','22']}
        ],
        Index:-1,
        cIndex:-1,
        showBanner:true,
        chartData: {
          columns: ['日期', 'open', 'close', 'lowest', 'highest', 'vol'],
          rows: [
            { '日期': '2004-01-05', open: 10411.85, close: 10544.07, lowest: 10411.85, highest: 10575.92, vol: 221290000 },
            { '日期': '2004-01-06', open: 10543.85, close: 10538.66, lowest: 10454.37, highest: 10584.07, vol: 191460000 },
            { '日期': '2004-01-07', open: 10535.46, close: 10529.03, lowest: 10432.12, highest: 10587.55, vol: 225490000 },
            { '日期': '2004-01-08', open: 10530.07, close: 10592.44, lowest: 10480.59, highest: 10651.99, vol: 237770000 },
            { '日期': '2004-01-09', open: 10589.25, close: 10458.89, lowest: 10420.52, highest: 10603.48, vol: 223250000 },
            { '日期': '2004-01-12', open: 10461.55, close: 10485.18, lowest: 10389.85, highest: 10543.03, vol: 197960000 },
            { '日期': '2004-01-13', open: 10485.18, close: 10427.18, lowest: 10341.19, highest: 10539.25, vol: 197310000 },
            { '日期': '2004-01-14', open: 10428.67, close: 10538.37, lowest: 10426.89, highest: 10573.85, vol: 186280000 },
            { '日期': '2004-01-15', open: 10534.52, close: 10553.85, lowest: 10454.52, highest: 10639.03, vol: 260090000 },

          ]
        }
      }
    },
    methods:{
      active(index){
        this.showBanner = true
        this.Index = index
      },
      select(cindex){
        this.cIndex = cindex
        this.banners[this.Index].title = this.banners[this.Index].list[cindex]
        this.showBanner = false
      }
    }
  }
</script>
<style lang="less" scoped>
  .moreData{
    width: 100%;
    height: 100px;
    background: #1C53D4;
  }
  .banner{
    width: 100%;
    span{
      display: inline-block;
      width: 25%;
      height: 60px;
      line-height: 60px;
      text-align: center;
      font-size: 16px;
      color: #000000;
    }
    .activeclass{
      color: #ffffff;
      background: #3C4145;
      opacity: 0.9;
    }

  }
  .banner-bottom{
    width: 100%;
    background: #3C4145;
    opacity: 0.9;
    position: absolute;
    z-index: 9999;
    span{
      width: 20%;
      color: #ffffff;
      text-align: center;
      display: inline-block;
      height: 50px;
      line-height: 50px;
      font-size: 14px;
    }
    .selectclass {
      color: #FFC600;
    }
  }
</style>
