<template>
	<div class="chatroom_template">
		<div class="top_chatroom">
			<img src="@/assets/information/top_return.png" class="img_return" @click="back">
			<div class="chatroom_name">
				<span>{{pageName}}</span>
				<router-link to='/information/chatroom/remark'><img src="@/assets/information/me_editor.png" class="img_edit"></router-link>
			</div>
		</div>

		<div class="body_chatroom" ref='wrapper'>
			<ul v-for="item in content">
				<!-- 我的聊天文字 -->
				<li class='ask' >
					<img :src="item.askImg">
					<p>{{item.askContent}}</p>
				</li>
				<!-- 对方的聊天文字 -->
				<li class='reply'>
					<router-link to='/information/usercare'><img src="@/assets/information/me_head.png"></router-link>
					<p>你说的都对</p>
				</li>
			</ul>
		</div>
		<!-- 底部 -->
		
		<div class="bottom_chatroom">
	        <div class="send">
	          <input 
	            type="text" 
	            class="sText"
	            ref="sTest" v-model='inText'/>
	            <img v-show='!inText' src="@/assets/information/information_expression.png" style="margin-right: 0.2rem">
	            <img v-show='!inText' src="@/assets/information/information_add.png" style="margin-right: 0.15rem">
	          <input v-show='inText' type="button" class="btn" value="发送" @click="sendContent" />
	        </div>
      </div>
	</div>
</template>

<script>
	import BScroll from 'better-scroll'
	export default{
		created(){
				console.log('111',this.$route.query.mid)
		},
		mounted(){
			// this.$nextTick(()=>{
			// 	this.scroll= new BScroll(this.$refs.wrapper,{
			// 		click:true
			// 	})
			// })
		},
		data(){
			return{
				pageName:this.$route.query.name,
				text:'',
				inText:'',
				showSend:false,
				randomReply:[
				  '你谁啊？',
		          '请你再说一遍！',
		          '想和我聊天？得先夸我！',
		          '我不知道你在讲什么。。。',
		          '不好意思，我不想和你说话。',
		          '先告诉我你是谁。',
		          '竖子不足以谋也！',
		          '我选择沉默',
		          '来吧，一起吹牛逼。。',
		          '我很困，不想聊天',
		          '别废话，先给我讲个笑话',
		          '你从哪里来',
		          '心情不好，最好别搭理我',
		          '等我忙完再回复你',
		          '敢问尊姓大名',
		          '近来可好？',
		          '看来你是想和我聊天',
		          '你是要请我吃饭吗？',
		          '先给我一个让我回复你的理由',
		          '哈哈哈'
				],
				content:[
				]
			}
		},
		components:{
			BScroll
		},
		computed:{
			 // ...mapGetters([
    //     		'info'
    //   		])
		},
		methods:{
			back(){
				this.$router.back(-1);
			},
			sendContent(){
				this.text = this.$refs.sTest.value
				if(this.text !== ''){
					this.content.push({
						askImg:require('@/assets/information/me_head.png'),
						askContent:this.text
					})

					// setTimeout(() => {
			  //           this.content.push({
			  //             replyImg: '',
			  //             replyContent: this.randomReply[Math.floor(Math.random() * 19)]
			  //           })
			  //           // for (let i = 0; i < this.content.length; i++) { // 定义回复者的头像
			  //           //   this.content[i].replyImg = this.info.imgurl
			  //           // }
			  //         }, 1000)
				}
				this.$refs.sTest.value = '' // 清空输入框的内容
				this.inText=''
			}
		}
	}
</script>

<style lang="less" scoped>
	.chatroom_template{
		.top_chatroom{
			width: 100%;
			height: 0.88rem;
			background: #91C3D2;
			box-sizing: border-box;
			padding: 0.22rem 0.22rem;
			position: relative;
			.img_return{
				width: 0.15rem;
				height: 0.32rem;
				left: 0.3rem;
				top: 0.3rem;
				position: absolute;
			}
			.chatroom_name{
					margin: 0 auto;
					width: 1.6rem;
				span{
					color:#ffffff;
					font-size: 0.32rem;
					width:0.96rem;
					vertical-align: 0.04rem;
					margin-left: 0.3rem;
				}
				.img_edit{
					display: inline-block;
					width: 0.32rem;
					height: 0.32rem;
					margin-left: 0.09rem;
				}
			}
		}
		.body_chatroom{
			width: 100%;
			padding: 20px 10px;
			ul{
				position: relative;
				li{
					position: relative;
					overflow: hidden;
					margin-bottom: 15px;
					line-height: 28px;
					img{
						position: relative;
						width: 0.66rem;
						height: 0.66rem;
					}

				}
				.ask{
					text-align: right;
					img{
						float: right;
						margin-left: 15px;
					}
					p{
						border-radius: 4px;
					    text-align: left;
					    font: 14px 'Microsoft YaHei';
					    line-height: 30px;
					    float: right;
					    padding: 2px 10px;
					    max-width: 182px;
					    background: #91C3D2;
					    color: #fff;
					    word-break:normal;
					    word-wrap:break-word;word-break:break-all;
					    position: relative;
					}
				    p::after{
				    	position: absolute;
			            content: "";
			            width: 0;
			            height: 0;
			            left: 100%;
			            top: 10px;
			            border-top: 3px solid transparent;
			            border-left: 6px solid #91C3D2;
			            border-bottom: 3px solid transparent;
				    }
				}
				.reply{
					text-align: left;
					img{
						float: left;
						margin-right: 15px;
					}
					p{
						border-radius: 4px;
					    text-align: left;
					    font: 14px 'Microsoft YaHei';
					    line-height: 30px;
					    left: 2px;
					    float: left;
					    padding: 2px 10px;
					    max-width: 190px;
					    background: #ffffff;
					    position: relative;
					}
					p::before{
				    	position: absolute;
			            content: "";
			            width: 0;
			            height: 0;
			            right: 100%;
			            top: 10px;
			            border-top: 3px solid transparent;
			            border-right: 6px solid #ffffff;
			            border-bottom: 3px solid transparent;
				    }
				}
			}
		}

		.bottom_chatroom{
			position: fixed;
		    height: 50px;
		    bottom: 0;
		    left: 0;
		    right: 0;
		    background-color: #F6F6F8;
		    border-top: 1px solid #c9c9c9;
		    .send{
			    display: flex;
			    .sText{
			    	flex: 6;
				    height: 30px;
				    margin: 10px;
				    border: 0;
				    padding-left: 8px;
				    font-size: 15px;
				    border: 1px solid #c9c9c9;
				    background: #ffffff;
				    border-radius: 5px;
			    }
			    img{
			    	width: 0.48rem;
			    	height: 0.48rem;
			    	margin-top: 0.25rem;
			    }
			    .btn{
				    flex: 1;
				    width: 65px;
				    height: 30px;
				    margin: 10px 10px;
				    border: 0;
				    border-radius: 5px;
				    /*float: right;*/
				    text-align: center;
				    font-size: 18px;
				    color: white;
				    background-color: #09BB07;
				}
			}
		}
	}
</style>