<template>
	<div class="otcTab">
		<router-link class="tabbar-item" :id="item.active" v-for="(item, index) in tab" :to="item.link" :key="index" replace >
			<svg-icon :icon-class="item.blacks" v-show="!item.active" class="icon-tabbar"></svg-icon>
			<svg-icon :icon-class="item.oranges" v-show='item.active' class="icon-tabbar"></svg-icon>
		<span>{{item.title}}</span>
		</router-link>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				tab: [{
						title: '交易',
						link: '/otc',
						active: true,
						blacks: 'otc_jy',
						oranges: 'otc_jyl'
					},
					{
						title: '订单',
						link: '/otcOrder',
						active: false,
						blacks: 'otc_dd',
						oranges: 'otc_ddl'
					},
					{
						title: '广告',
						link: '/otcPoster',
						active: false,
						blacks: 'otc_gg',
						oranges: 'otc_ggl'
					},
					{
						title: '账户',
						link: '/otcAccount',
						active: false,
						blacks: 'otc_zh',
						oranges: 'otc_zhl'
					},
				]
			}
		},
		watch: {
            '$route': {
                handler() {
                    for(let k in this.tab) {
                        if(this.tab[k].link === this.$route.path) {
                            this.tab[k].active = true
                        } else {
                            this.tab[k].active = false
                        }
                    }
                },
                //      是否立即執行
                immediate: true
            }
		},
		methods: {

		}
	}
</script>

<style lang="less" scoped>
	.otcTab {
		position: fixed;
		bottom: 0;
		background-color: #fff;
		border-top: 1px solid #e1e1e1;
		width: 100%;
		.tabbar-item {
			text-align: center;
			display: inline-block;
			width: 25%;
			box-sizing: border-box;
			padding: .15rem 0 .05rem;
			img{
				width: 24px;
				height: 22px;
			}
			span {
				display: block;
				color: #333333;
			}
		}
	}
	.icon-tabbar{
		font-size: 20px;
        text-align: center;
        margin:1px 0 1px 0;	
	}
	#true>i,
	#true>span {
		color: #287A81;
	}
</style>