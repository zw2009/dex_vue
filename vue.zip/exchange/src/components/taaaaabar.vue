<template>
	<div class="babbar">
		<router-link class="tabbar-item" :id="item.active" v-for="(item, index) in tab" :to="item.link" :key="index" replace >
			<img :src="item.img" v-show="!item.active">
			<img :src="item.color_img" v-show='item.active'>
			<span>{{item.title}}</span>
		</router-link>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				tab: [{
						title: '行情',
						link: '/index',
						active: true,
						img: require('@/assets/top_market.png'),
						color_img: require('@/assets/top_market_green.png')
					},
					{
						title: '交易',
						link: '/transactions',
						active: false,
						img: require('@/assets/top_trading.png'),
						color_img: require('@/assets/top_trading_green.png')
					},
					{
						title: '资产',
						link: '/assets',
						active: false,
						img: require('@/assets/top_assets.png'),
						color_img: require('@/assets/top_assets_green.png')
					},
					{
						title: '动态',
						link: '/dynamics',
						active: false,
						img: require('@/assets/top_dynamic.png'),
						color_img: require('@/assets/top_dynamic_green.png')
					},
					{
						title: '我的',
						link: '/user',
						active: false,
						img: require('@/assets/top_my.png'),
						color_img: require('@/assets/top_my_green.png')
					},
				]
			}
		},
		watch: {
            '$route': {
                handler() {
                    for(let k in this.tab) {
                        if(this.tab[k].link === this.$route.path) {
                            this.tab[k].active = true
                        } else {
                            this.tab[k].active = false
                        }
                    }
                },
                //      是否立即執行
                immediate: true
            }
		},
		methods: {

		}
	}
</script>

<style lang="less" scoped>
	.babbar {
		position: fixed;
		bottom: 0;
		background-color: #fff;
		border-top: 1px solid #e1e1e1;
		width: 100%;
		.tabbar-item {
			text-align: center;
			display: inline-block;
			width: 20%;
			box-sizing: border-box;
			padding: .15rem 0 .05rem;
			img{
				width: 24px;
				height: 22px;
			}
			span {
				display: block;
				color: #333333;
			}
		}
	}
	#true>i,
	#true>span {
		color: #287A81;
	}
</style>