// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import routers from './router/index'
import VueRouter from 'vue-router'

import * as Api from './common/api'
//import store from './store'
import '@/common/filter'
import '@/icons' // icon

Vue.prototype.$api = Api
import YDUI from 'vue-ydui'
import 'vue-ydui/dist/ydui.rem.css'

//import VCharts from 'v-charts'
import candle from 'v-charts/lib/candle.common'
Vue.component(candle.name, candle)
//import echarts from 'echarts'
//
import BScroll from 'better-scroll';

//Vue.prototype.$echarts = echarts 
import { Range} from 'mint-ui'
Vue.component(Range.name, Range);

Vue.use(YDUI)
Vue.use(VueRouter)
Vue.config.productionTip = false

const router = new VueRouter({
    mode: 'hash',
    routes: routers,
    // scrollBehavior (to, from, savedPosition) {
    //     if (savedPosition) {
    //         return savedPosition
    //     }
    //     return {x: 0, y: 0}
    // }
})

const that = new Vue({
  el: '#app',
  router,
  components: { App },
   render: h => h(App),
  template: '<App/>'
})


document.addEventListener('deviceready', function() {
that
}, false);

export {router,that}