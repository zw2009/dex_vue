<template>
	<div class="home">
		<div class="topTitle" style="padding:23px 0px 0px 15px; ">
			<span style="font-size: 20px;color: #434A59;">行情</span>
		</div>
		<!--<div class="top_nav">
			<span class="name">名称</span>
			<span class="price">最新价格</span>
			<span class="time">日涨跌</span>
		</div>-->
		<div class="content">
			<ul v-for="tab in items">
				<p class="title">{{tab.title}}专区</p>
				<router-link to="transactionsEntrust">
				<li v-for="item in tab.list">
					<div class="left_ats">
						<span class="fourteen">{{item.name}} <span class="gray">/{{item.area}}</span></span>
						<span class="gray stylels">成交量 {{item.volume}}</span>
					</div>
					<div class="mid_ats">
						<span class="sixteen">{{item.num}}</span>
						<span class="gray" style="display:block; padding-top: 5px;">￥{{item.price}}</span>
					</div>
					<div class="right_ats" >
						<span :class="{'red':(item.itee>0),'yellow':(item.itee==0),'blue':(item.itee<0)}">{{item.itee}}%</span>
					</div>
				</li>
				</router-link>
			</ul>
		</div>
		<tabbar></tabbar>
		<!--<button @click="aa">22</button>-->
	</div>
</template>

<script>
	import tabbar from '@/components/TabBar'
//	import { removeStore,getStore } from '@/common/storage'
	export default {
		data() {
			return {
//				sist:[-6],
				items: [{
						title: 'TC',
						list: [
							{
								name: 'BTC',
								area:'TC',
								num: "26,492",
								price: "26,492",
								volume: "60,397,976,802	",
								itee: '+8.14'
							},
							{
								name: 'ETH',
								area:'TC',
								num: 960.49,
								price: 960.49,
								volume: "31,525,952,216	",
								itee: "-0.14"
							},
							{
								name: 'XRP',
								area:'TC',
								num: 2.18,
								price:2.1,
								volume: "7,276,521,843",
								itee: 0.00
							},
						],
					},
					{
						title: 'ETH',
						list: [{
								name: 'EOS',
								num: 24.16,
								area:'ETH',
								price: 24,
								volume: "11,208,176,234	",
								itee: '+8.14'
							},
							{
								name: 'LTC',
								num: 322.21,
								area:'ETH',
								price: 322,
								volume: "8,727,014,263	",
								itee: 0.00
							},
							{
								name: 'USDT',
								num:6.79,
								area:'ETH',
								price: 5.31,
								volume: "56,220,466,082	",
								itee: '-3.14'
							},
						],
					},
				]
			}
		},
//		methods: {
//			aa(){
//				console.log(getStore('user_token'))
//			}
//		},
		components: {
			tabbar
		},
	}
</script>
<style type="text/css">
	.yd-navbar {
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%)!important;
	}
	.yd-navbar-center-title{
		font-size: 17px!important;
	}
	.gray {
		color: #B9B9B9;
		font-size: 10px;
	}
	
	.fourteen {
		font-size: 14px;
		color: #222222;
	}
	
	.sixteen {
		font-size: 16px;
		color: #222222;
	}
</style>
<style lang="less" scoped>
	.home {
		.top_nav {
			background: #FFFFFF;
			line-height: 30px;
			overflow: hidden;
			span {
				float: left;
				font-size: 10px;
				color: #9A9A9A;
			}
			.name {
				width: 60%;
				padding-left: 15px;
			}
			.price {
				width: 20%;
				padding-right: 20px;
				text-align: right;
			}
			.time {
				width: 20%;
				text-align: right;
				padding-right: 15px;
			}
		}
		.content {

			padding-bottom: 50px;
			ul {
				background: #FFFFFF;
							padding-top: 28px;
				.title {
					height: 20px;
					padding-left: 15px;
					line-height: 30px;
					font-size: 14px;
					color: #434A59;
				}
				li {
					margin-left: 15px;
					height: 57px;
					overflow: hidden;
					border-bottom: 1px solid #ECECEC;
					.left_ats {
						padding-top: 11px;
						width: 60%;
						float: left;
						display: block;
						.stylels {
							display: inline-block;
							padding-top: 5px;
							width: 100%;
						}
					}
					.mid_ats {
						padding-right: 20px;
						text-align: right;
						padding-top: 11px;
						width: 20%;
						float: left;
						display: block;
					}
					.right_ats {
						width: 20%;
						float: left;
						display: block;
						.colorBlock {
							font-size: 12px;
							color: white;
							border-radius: 3px;
							text-align: center;
							margin-top: 13px;
							display: block;
							width: 61px;
							height: 29px;
							background: #00A96C;
							line-height: 29px;
						}
						.red{
							background: #00A96C!important;
							font-size: 12px;
							color: white;
							border-radius: 3px;
							text-align: center;
							margin-top: 13px;
							display: block;
							width: 61px;
							height: 29px;
							line-height: 29px;
						}
						.yellow{
							background: #B6B9C3!important;
							font-size: 12px;
							color: white;
							border-radius: 3px;
							text-align: center;
							margin-top: 13px;
							display: block;
							width: 61px;
							height: 29px;
							line-height: 29px;
						}
						.blue{
							background: #E85353!important;
							font-size: 12px;
							color: white;
							border-radius: 3px;
							text-align: center;
							margin-top: 13px;
							display: block;
							width: 61px;
							height: 29px;
							line-height: 29px;
						}
					}
				}
			}
		}
	}
</style>