<template>
	<div class="areaCode">
		<div class="top-back" style="">
			<router-link to="register">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span style="text-align: center;">国家/地区</span>
		</div>
		<div class="search">
			<yd-search v-model="value1" :on-submit="submitHandler"></yd-search>
		</div>
		<ul v-for="tab in list">
			<p>{{tab.title}}</p>
			<li @click="clicks(index)" v-for="(item,index) in tab.list" :key="index">
				<span class="leftname">{{item.name}}</span>
				<span class="rightname">{{item.code}}</span>
			</li>
			
		</ul>
		<div class="posright">
			<div class="number" v-for="num in vertical">
				<span>{{num.Letter}}</span>
			</div>
		</div>
	</div>
</template>

<script>
	
	export default {
		data() {
			return {	
				value1: '',
				vertical:[
					{Letter:'#'},{Letter:'A'},{Letter:'B'},{Letter:'C'},{Letter:'D'},{Letter:'E'},{Letter:'F'},{Letter:'G'},{Letter:'H'},{Letter:'I'},{Letter:'J'},{Letter:'K'},{Letter:'L'},{Letter:'M'},{Letter:'N'},{Letter:'O'},{Letter:'P'},{Letter:'Q'},{Letter:'R'},{Letter:'S'},{Letter:'T'},{Letter:'U'},{Letter:'V'},{Letter:'S'},{Letter:'Y'},{Letter:'Z'},
				],
				list:[
					{
						title: 'A',
						list: [
							{name:'阿尔巴尼亚',code:355},
							{name:'阿尔巴尼亚',code:355},
							{name:'阿尔巴尼亚',code:355},
						]
					},
					{
						title: 'B',
						list: [
							{name:'巴',code:3},
							{name:'巴',code:3},
							{name:'巴',code:3},
						]
					},
					{
						title: 'C',
						list: [
							{name:'巴',code:3},
							{name:'巴',code:3},
							{name:'巴',code:3},
						]
					},
					{
						title: 'D',
						list: [
							{name:'巴',code:3},
							{name:'巴',code:3},
							{name:'巴',code:3},
						]
					},
				]
			}
		},
		methods: {
            submitHandler(value) {
                this.$dialog.toast({mes: `搜索：${value}`});
            },
            clicks(index){
            	console.log(index)
//      		console.log(this.list[0].list[0].code)
//				console.log(this.list[this].list[0].code)
            	
            }
        },
	}
</script>
	<style type="text/css">
	.areaCode .yd-search-input>.cancel-text{
		display: none;
	}
	.areaCode .yd-search-input:after, .yd-search-input:before{
		display: none;
	}
	.areaCode .yd-search-input{
		background: #fff;
	}
	.areaCode .yd-search-input>.search-input, .yd-search-input>.search-input .search-icon{
		border-radius: 10px;
		    background: #F5F6F6;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.areaCode{
		position: relative;
		ul{
				padding-left: 20px;
				padding-right: 40px;
			p{
				font-size: 24px;
				line-height: 50px;
			}
			li{
				line-height: 40px;
				overflow: hidden;
				border-bottom: 1px solid #F1F1F1;
				.leftname{
					float: left;
					display: block;
				}
				.rightname{
					display: block;
					float: right;
				}
			}
		}
		.posright{
			position: fixed;
			top: 110px;
			width: 16px;
			right: 10px;
			height: 100px;
			.number{
				span{
					display: block;
					line-height: 20px;
				}
			}
		}
	}
</style>