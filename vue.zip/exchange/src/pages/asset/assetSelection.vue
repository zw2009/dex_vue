<template>
	<div class="assetSelection">
		<div class="top-back">
				<router-link to="transactions">
			<!--<router-link to="assets">-->
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>资产选择</span>
		</div>
		<!--<span style="font-size: 20px;color: #434A59;padding:20px 0px 20px 15px;display: block;">资产选择</span>-->
		<span style="font-size: 12px;color: #434A59;padding-left: 15px;display: inline-block;">当前选择：<span>{{current}}/ TC</span></span>
		<ul v-for="tab in list">
			<p> {{tab.type}} 专区</p>
			<li v-for="(item,index) in tab.lists" :id="item.active" :key="index"  v-model="typename" @click="typenames(index)">
				<div class="leftCt">
					<span>{{item.name}} <span style="color:  #ECECEC;">/ {{item.nametype}}</span></span>
				</div>
				<div class="midCt">
					<span>{{item.number}}</span>
				</div>
				<div class="rightCt">
					<span>{{item.vule}}</span>
				</div>
			</li>
			
		</ul>
	</div>
</template>

<script>
	export default {
		created(){
			this.getfor()
		},
		data() {
			return {
				typename:'',
				current:'STWC',
				list:[
					{type:'TC',lists:[
						{name:'SWTC',number:0.00586,vule:'+8.14%',nametype:'TC'},
						{name:'STM',number:0.00551,vule:'+2.14%',nametype:'TC'},
						{name:'MOAC',number:5.31,vule:'-1.14%',nametype:'TC'},
					]},
					{type:'ETH',lists:[
						{name:'SWTC',number:0.000005698,vule:'0.00%',nametype:'TC'},
					]
					}
				]
			}
		},
		methods: {
			typenames(index){
//				console.log(this.list[1].lists,1223)
//				console.log(this.list,123)
//				this.Index = index
				console.log(this.list["0"].lists[index].name)
				let typeName = this.list["0"].lists[index].name
				this.$router.push({path: '/transactions',query: {typeName:typeName}})
				
				
				
				
				
//				this.$router.replace('/transactions')
				
			},
			getfor(){
				this.typeId = this.$route.query.typeId 
				console.log(this.typeId,123)
				this.current = this.typeId  
			}
		}
	}	
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.assetSelection{
		ul{
			padding-top: 28px;
			padding-left:15px;
			p{
				padding-bottom: 20px;
			}
			li{
				overflow: hidden;
				border-bottom: 1px solid #ECECEC;
				padding-right: 15px;
				height: 50px;
				line-height: 50px;
				.leftCt{
					float: left;
					width: 30%;
					display: block;
					font-size: 14px;
				}
				.midCt{
					float: left;
					width: 40%;
					text-align: right;
					font-size: 14px;
				}
				.rightCt{
					text-align: center;
					float: right;
					width: 20%;
				}
			}
		}
	}
</style>