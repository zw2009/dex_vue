<template>
	<div class="wallet_windows">
		<div class="wallet_one" v-show="wallet">
			<div class="top-back">
				<div class="test_two">
					<div class="topleft">
						<!--<router-link to="assetSelection">-->
							<span class="leftSpan">资产</span>
						<!--</router-link>-->
						<router-link to="otc">
							<span class="rightSpan">OTC</span>
						</router-link>
					</div>
					<div class="rigt_test">
						<span class="TwentyFour"  v-show='showValue'>1,012.3</span>
						<span class="TwentyFour"  v-show='!showValue'>****</span>
					</div>
				</div>

				<div class="Valuation">
					<span class="gu-one" style="font-size: 10px;">估值(¥)</span>										
					<!--<img @click="ShowValue" class="click-oneimg" :src="showValue? require('../../static/img/landing_open.png'): require('../../static/img/landing_closed.png')" />-->					
					<img @click="ShowValue" class="click-oneimg" :src="showValue? require('../../../static/img/assets_open.png'): require('../../../static/img/assets_closed.png')" />
					
				</div>
			</div>
			<div class="Assets-content">
				<ul>
					<li class="Assets-li" @click="show2 = true">
						<span class="big_sp left">资产列表</span>
						<span class="blue-span right right-big" style="color: #05535C;">总额</span>
						<img src="../../../static/img/assets_Under_green.png"/>
						<!--<svg-icon icon-class="ball-triangle" class='loading-icon'/>-->
					</li>
					<router-link to="assetsDetails">
						<li v-for="item in items">
							<span class="font-Fourteen">{{item.title}}</span>
							<span class="blue-span right lin-height">{{item.value.toFixed(3)}}</span>
						</li>
					</router-link>
				</ul>
			</div>
		</div>
			<yd-popup v-model="show2" position="bottom" height="38%">
			  	<div  style="background-color:#fff;text-align: center;">
				  	<span style="display: block;color: #6F6F6F;border-bottom: 1px solid #ECECEC;line-height: 40px;">请选择类型</span>
				  	<span style="display: block;border-bottom: 1px solid #ECECEC;color: #222222;line-height: 40px;">总额</span>
				  	<span style="display: block;border-bottom: 1px solid #ECECEC;color: #222222;line-height: 40px;">可用</span>
				  	<span style="display: block;border-bottom: 1px solid #ECECEC;color: #222222;line-height: 40px;">冻结</span>
				  	<span style="display: block;border-bottom: 5px solid #ECECEC;color: #222222;line-height: 40px;">估值( ¥ )</span>
				  	<span style="display: block;line-height: 40px;color: #888888;" @click="show2 = false">取消</span>
			  	</div> 
		  	</yd-popup>
		<tabbar></tabbar>
	</div>
</template>

<script>
	import tabbar from '@/components/TabBar'
	export default {
		data() {
			return {				
				showValue: true,
				wallet: true,
				value:"",
				show2: false,
				showImg:true,
				items:[
					{title:'BTC',value:1.005},
					{title:'ETH',value:586},
					{title:'XRP',value:120.584446},
					{title:'EOS',value:20.886},
					{title:'LTC',value:70.36},
					{title:'USDT',value:4.278},
				]			
			}
		},
		methods: {
			ShowValue() {
				this.showValue = !this.showValue;
//				alert(num.toFixed(2));
			},
			clickImg(){
				this.showImg = false;
				this.showTest = true
			}
		},
		components: {
			tabbar
		},
	}
</script>
<style>
	.yd-next-icon:before{
		display: none!important;
	}
	.yd-navbar:after{
	display: none!important;	
	}
</style>
<style lang="less" scoped>
	.wallet_windows {
		.right {
			float: right;
		}
		.left {
			float: left;
		}
		.wallet_one {
			.top-back {
				background: url('../../../static/img/assets_background.png') no-repeat;
				width: 100%;
				height: 207px;
				background-size: 100% 100%;
				.test_two {
					padding-top: 12px;
					color:#FFFFFF ;
					.topleft{
						overflow: hidden;
						font-size:16px;
						.leftSpan{
							padding-left: 15px;
							float: left;
						}
						.rightSpan{
							padding-right: 15px;
							float: right;
						}
					}
					.rigt_test {
						padding-top: 40px;
						text-align: center;
						.fourteen {
							font-size: .28rem;
							color: white;
							display: block;
							padding-bottom: .26rem;
							padding-top: .26rem;
						}
						.TwentyFour {
							font-size: 18px;
							color: white;
							display: block;
							padding-bottom: .22rem;
						}
					}
				}
				.Valuation {
					margin: 0 auto;
					width: 1.3rem;
					overflow: hidden;
					padding-bottom: 40px;
					span {
						font-size: .24rem;
						float: left;
						display: block;
						color: white;
						line-height: .34rem;
						padding-top: .04rem;
					}
					img {
						margin-left: .1rem;
						margin-top: .08rem;
						float: left;
						width: .36rem;
					}
				}
			}
			.Assets-content {
				padding-top: 30px;
				background: #FFFFFF;
				ul {
					padding: 0 .3rem;
					.Assets-li {
						background: #FFFFFF;
						height: .8rem!important;
						line-height: .8rem;		
						.big_sp {
							font-size: .28rem;
							display: block;
							color: #4E4E4E;
						}
						img{
							width: 8.4px;
							height: 5px;
						}
					}
					li {
						overflow: hidden;
						position: relative;
						background: #FFFFFF;
						height: 1rem;
						border-bottom: .01rem dashed  #ECECEC;
						.font-Fourteen{
							float: left;
							display: block;
							line-height: 50px;
						}
						.right-big {
							float: right;
							padding-right: .3rem;
						}
						img {
							width: .2rem;
							height: .2rem;
							position: absolute;
							top: 50%;
							transform: translateY(-50%);
							right: 0rem;
						}
					}
					.lin-height {
						line-height: 1rem;
					}
					.blue-span {
						color: #222222;
						font-size: .32rem;
						display: block;
					}
				}
			}
		}
	}
</style>