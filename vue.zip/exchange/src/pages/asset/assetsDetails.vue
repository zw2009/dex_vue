<template>
	<div class="assetsDetails">
	    <div class="top-back">
			<router-link to="assets">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>SWTC</span>
		</div>
	    <div class="card">
	    	<div class="round">
	    		<p>￥0.16</p>
	    		<ul>
	    			<li>
	    				<span class="onespan">总额</span>
	    				<span class="twospan">35.00000</span>
	    			</li>
	    			<li>
	    				<span class="onespan">可用</span>
	    				<span class="twospan">35.00000</span>
	    			</li>
	    			<li>
	    				<span class="onespan">冻结</span>
	    				<span class="twospan">35.00000</span>
	    			</li>
	    		</ul>
	    	</div>
	    </div>
	    <div class="record">
	    	<span @click="transaction" :class="{cur:shows==1}">交易记录</span>
	    	<span @click="charge" :class="{cur:shows==2}">充提记录</span>
	    </div>
	    <div class="recordJy" v-show="recordJy">
	    	<img src="../../../static/img/assets_picture.png"/>
	    	<span>暂无内容</span>
	    </div>
	    <div class="recordCt" v-show="recordCt">
	    	<img src="../../../static/img/assets_picture_two.png"/>
	    	<span>暂无内容</span>
	    </div>
	    <div class="recordCtsj" v-show="recordCtsj">
	    	<ul>
	    		<li v-for="item in items">
	    			<div class="leftRight">
	    				<span class="price">{{item.price}}</span>
	    				<span class="ceive">{{item.ceive}}</span>
	    			</div>
	    			<span class="time">{{item.time}}</span>
	    		</li>
	    	</ul>
	    </div>
	    <div class="posBottom">
	    	<button class="send">发送</button>
	    	<button class="receive">接收</button>
	    </div>
	    
	  
	</div>
</template>

<script>
		export default {
			data(){
				return{
					shows:1,
					recordJy:true,
					recordCt:false,
					recordCtsj:false,
					items:[
						{price:'111CNT',ceive:'接受',time:'2018-12-25 11:35:11'},
						{price:'111CNT',ceive:'接受',time:'2018-12-25 11:35:11'},
						{price:'111CNT',ceive:'接受',time:'2018-12-25 11:35:11'},
					]
				}
			},
			methods: {
				charge(){
					this.recordJy = false ;
					this.recordCt = true ;
					this.shows = 2 ;
				},
				transaction(){
					this.recordCt = false ;
					this.recordJy = true ;
					this.shows = 1 ;
				},
				
			}
		}
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.assetsDetails{
		.card{
			padding:15px;
			.round{
				color: white;
				border-radius: 10px;
				padding: 0 10px;
				background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
				box-shadow: 0 0 5px 0 rgba(192,192,192,0.50);
				p{
					text-align: center;
					font-size: 18px;
					line-height: 70px;
				}
				ul{
					padding-top: 5px;
					padding-bottom: 5px;
					border-top: 1px solid #ECECEC;
					li{
						line-height: 20px;
						overflow: hidden;
						.onespan{
							float: left;
						}
						.twospan{
							float: right;
						}
					}
				}
			}
		}
		.record{
			padding-left: 15px;
			line-height: 22px;
			overflow: hidden;
			span{
				float: left;
				display: block;
				font-size: 12px;
				color: #9A9A9C;
				margin-right: 10px;
			}
			.cur{
				color: #04555D;
				border-bottom: 1px solid #04555D;
			}
		}
		.recordJy{
			text-align: center;
			img{
				margin-top: 100px;
				width: 109px;
				height: 111px;
				margin-bottom: 10px;
			}
			span{
				display: block;
			}
		}
		.recordCt{
			text-align: center;
			img{
				margin-top: 40px;
				width: 131px;
				height: 158px;
				margin-bottom: 10px;
			}
			span{
				display: block;
			}
		}
		.recordCtsj{
			padding-left: 15px;
			padding-top: 20px;
			padding-bottom: 50px;
			ul{
				li{
					border-bottom:  1px solid #F6F6F6;
					.leftRight{
						overflow: hidden;
						line-height: 30px;
						.price{
							float: left;
							display: block;
							font-size: 12px;
							color: #4E4E4E;
						}
						.ceive{
							float: right;
							display: block;
							padding-right: 15px;
							font-size: 12px;
							color: #0FA170;
						}
					}
					.time{
						text-align: right;
						display: block;
						padding-right: 15px;
						font-size: 10px;
						color: #B8B8B8;
						padding-bottom: 5px;
					}
				}
			}
		}
		.posBottom{
			padding: 10px 15px;
			width: 100%;
			height: 50px;
			position: fixed;
			background: #FFFFff;
			bottom: 0;
			left: 0;
			z-index: 999;
			border-top: 1px solid #ECECEC;
			overflow: hidden;
			.send{
				display: block;
				float: left;
				width: 45%;
				line-height: 30px;
				border: none;
				background: #F4F4F4;
				box-shadow: inset 0 0 2px 0 #ECECEC;
				border-radius: 4px;
			}
			.receive{
				display: block;
				float: right;
				width: 45%;
				line-height: 30px;
				border: none;
				background: #F4F4F4;
				box-shadow: inset 0 0 2px 0 #D6D6D6;
				border-radius: 4px;
			}
		}
	}
</style>