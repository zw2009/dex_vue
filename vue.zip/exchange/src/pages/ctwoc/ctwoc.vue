<template>
	<div class="ctwoc">
		<div class="top-back">
			<router-link to="assets">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>C2C交易-TC</span>
			<router-link to="ctwocOrder">
				<span style="position: absolute;top: 50%;transform: translateY(-50%);right: 15px;display: block;">订单</span>
			</router-link>
		</div>
		<div class="contenttwo">
		<yd-tab v-model="tab1" color="#9A9A9C" active-color="#05535C">
			<yd-tab-panel label="购买">
				<div class="buy">
					<ul>
						<li>
							<span>数量</span>
							<input type="" name="" id="" value="" placeholder="最低100"/>
							<em>TC</em>
						</li>
						<li>
							<span>需支付</span>
							<input type="" name="" id="" value="" placeholder="0"/>
							<em>CNY</em>
						</li>
						<li>
							<span>+86 中国</span>
							<i class="rightBrackets"></i>
						</li>
						<li>
							<span>手机号</span>
							<input type="" name="" id="" value="" placeholder="手机号，选填"/>
							<i class="rightBrackets"></i>
						</li>
					</ul>
				</div>
				<div class="clickButton">
					<button>确认购买</button>
				</div>
				<p style="text-align: center;text-decoration: underline;">不知道如何C2C购买？</p>
			</yd-tab-panel>
			<yd-tab-panel label="出售">
				<div class="Sell buy">
				<ul>
					<li>
						<span>可出售</span>
						<input type="" name="" id="" value="- -"/>
						<em>TC</em>
					</li>
					<li>
						<span>数量</span>
						<input type="" name="" id="" value="" placeholder="最低100"/>
						<em>TC</em>
					</li>
					<li>
						<span>实际到账</span>
						<input type="" name="" id="" value="" placeholder="0"/>
						<em>CNY</em>
					</li>
					<li>
						<span>手续费</span>
						<input type="" name="" id="" value="" placeholder="1.0%，最低 5"/>
						<em>TC</em>
					</li>
					<li>
						<span>收款人</span>
						<em>张*</em>
					</li>
					<router-link to="ctwocBankcard">
						<li>
							<span>收款账户</span>
							<i class="rightBrackets"></i>
						</li>
					</router-link>
					<li>
						<div class="inputss">
						<yd-cell-item>
							<span slot="left">验证码</span>
							 
								<yd-input slot="right" v-model="code" ref="input10" placeholder="验证码"></yd-input>

							<yd-sendcode slot="right" v-model="start" @click.native="sendCode" init-str="发送" type="primary"></yd-sendcode>
						</yd-cell-item>
						</div>	
						
					</li>
					<li>
						<span>验证码</span>
						<input type="" name="" id="" value="" placeholder="输入资产密码"/>
						<i class="rightBrackets"></i>
					</li>
				</ul>
				<div class="clickButton">
					<button>确认出售</button>
				</div>
				</div>
			</yd-tab-panel>
			 <div class="title">
			 	<!--<img src="../../../static/img/c2c_attention.png"/>-->
			 	<svg-icon icon-class="c2c_attention" class='imgtwo'/></svg-icon>
			 	<span>交易须知</span>
			 </div>
			 <div class="contenText">
			 	<span>1、C2C商户均为认证商户，并已缴纳足够的保证金，请放心交易。</span>
			 	<span>2、输入购买TC数量、手机号、点击确认购买；</span>
			 	<span>3、按要求给指定商户付款、只接收网银或手机银行转账，不接受ATM、微信、支付宝等转账，到账后由商户办理购买；</span>
			 	<span>4、如有问题，请联系系统客服。</span>
			 </div>
			 <div class="title">
			 	<span>咨询与反馈</span>
			 </div>
			 <div class="service" style="position: relative;line-height: 53px;">
			 	<span style="display: block;padding-left: 15px;">客服中心</span>
			 	<em  class="rightBrackets"></em>
			 </div>
		</yd-tab>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				tab1:0,
				start: false,
				code:''
			}
		},
		methods: {
			sendCode(){
//				let reg=/^1[3456789]\d{9}$/;
//              if(!this.phone){
//                  this.$dialog.toast({mes:'请输入手机号',timeout: 1000})
//                  return;
//              }
//              if(!reg.test(this.phone)){
//              	this.$dialog.toast({mes:'请输入正确手机号',timeout: 1000})
//              	return;
//              }
                this.$dialog.loading.open('发送中...');
               
                setTimeout(() => {
					this.$dialog.loading.close();
//                  this.$api.checkSms({
//                  	account:this.phone, 
//                  	operation:'reg',
//                  	type:1,
//                  	country:this.issue,
//                  	code:this.code,
//                  	}, res =>{
//                          
//                              if(!res.status){
//                                  this.$dialog.toast({mes:res.msg, timeout:1000})
//                                  this.phone =""
//                              }else{
//                                  this.$dialog.toast({mes:'已发送',icon: 'success', timeout: 1500})
//                                  this.start = true;
//                              }
//                          })
				}, 1000);
			},
		}	
	}
</script>
<style type="text/css">
	.inputss .yd-cell-right input{
		text-align: right!important;
		padding-right: 20px;
	}
	.inputss .yd-cell-item{
		padding-left: 0!important;
	}
	.contenttwo .yd-tab-active:before{
		/*left: 77%!important;*/
		/*width: 15%!important;*/
	}
	.inputss .yd-btn-primary:not(.yd-btn-loading){
		background-color:#fff!important;	
		color: #05535C;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.ctwoc{
		.contenText{
			padding: 10px 15px 25px 15px;
			span{
				display: block;
				line-height: 18px;
			}
		}
		.title{
			padding-left: 15px;
			background: #FAFAFA;
			margin-top: 24px;
			line-height: 25px;
			overflow: hidden;
			.imgtwo{
				float: left;
				width: 15px;
				height: 15px;
				margin: 5px 5px 5px 0px;
			}
			span{
				display: block;
				font-size: 14px;
				color: #222222;
			}
		}
		.buy{
			ul{
				li{
					line-height: 50px;
					overflow: hidden;
					margin-left: 15px;
					border-bottom: 1px solid #F6F6F6;
					position: relative;
					span{
						float: left;
						display: block;
						width: 30%;
					}
					input{
						width: 55%;
						border: none;
						line-height: 50px;
						float: left;
						text-align: right;
						font-size: 14px;
					}
					::-webkit-input-placeholder { /* WebKit browsers */
						    color:  #B8B8B8;
					}
					em{
						width: 13%;
						float: right;
						padding-right: 15px;
					}
				}
			}
		}
	}
</style>