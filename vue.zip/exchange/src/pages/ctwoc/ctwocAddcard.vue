<template>
	<div class="ctwocAddcard">
		<div class="top-back">
			<router-link to="ctwocBankcard">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>添加银行卡</span>
		</div>
		<ul>
			<li>
				<span>省份</span>
				<input type="" name="" id="" value="" placeholder="省份"/>
				<i class="rightBrackets"></i>
			</li>
			<li>
				<span>城市</span>
				<input type="" name="" id="" value="" placeholder="城市"/>
				<i class="rightBrackets"></i>
			</li>
			<li>
				<span>开户银行</span>
				<input type="" name="" id="" value="" placeholder="开户银行"/>
				<i class="rightBrackets"></i>
			</li>
			<li>
				<span>支行名称</span>
				<input type="" name="" id="" value="" placeholder="支行名称"/>
				<i class="rightBrackets"></i>
			</li>
			<li>
				<span>银行卡号</span>
				<input type="" name="" id="" value="" placeholder="银行卡号"/>
				<i class="rightBrackets"></i>
			</li>
		</ul>
		<div class="clickButton" style="padding-top: 73px;" @click="confirm">
			<button>确认</button>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				tab1:0,
				start: false,
				code:''
			}
		},
		methods: {
			confirm(){
				this.$router.replace('/ctwocBankcard')
			}
		}
	}	
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.ctwocAddcard{
		ul{
			li{
				line-height: 50px;
				overflow: hidden;
				margin-left: 15px;
				border-bottom: 1px solid #F6F6F6;
				position: relative;
				span{
					float: left;
					display: block;
					width: 30%;
				}
				input{
					width: 60%;
					border: none;
					line-height: 50px;
					float: left;
					text-align: right;
					font-size: 14px;
				}
				::-webkit-input-placeholder { /* WebKit browsers */
					    color:  #B8B8B8;
				}
			}
		}
	}			
</style>