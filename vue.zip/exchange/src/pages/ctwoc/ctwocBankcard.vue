<template>
	<div class="ctwocBankcard">
		<div class="top-back">
			<router-link to="ctwoc">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>银行卡</span>
			<router-link to="ctwocAddcard">
				<span style="position: absolute;top: 50%;transform: translateY(-50%);right: 15px;display: block;">添加</span>
			</router-link>
		</div>
		<ul>
			<li>
				<span class="leftsPan">招商储蓄卡</span>
				<span class="rightsPan">**** **** **** 7611</span>
			</li>
		</ul>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				tab1:0,
				start: false,
				code:''
			}
		},
		methods: {
			
		}
	}	
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.ctwocBankcard{
		ul{
			li{
				line-height: 50px;
				overflow: hidden;
				margin-left: 15px;
				padding-right: 15px;
				border-bottom: 1px solid #F6F6F6;
				.leftsPan{
					float: left;
					display: block;
					font-size: 12px;
					color: #4E4E4E;
				}
				.rightsPan{
					float: right;
					display: block;
					font-size: 12px;
					color: #4E4E4E;
				}
			}
		}
	}
</style>