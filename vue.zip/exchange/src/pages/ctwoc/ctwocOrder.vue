<template>
	<div class="ctwocOrder">
		<div class="top-back">
			<router-link to="ctwoc">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>订单-CNT</span>
			<span style="position: absolute;top: 50%;transform: translateY(-50%);right: 15px;display: block;color: #434A59;font-size: 12px;"  @click="show4 = true">筛选</span>
		</div>
		<ul>
			<router-link to="ctwocOrderdedetails">
			<li>
				<div class="leftCt">
					<div class="oneThat">
						<span class="buyspan">买</span>
						<span style="color: #4E4E4E;font-size: 12px;">111</span>
						<span style="color: #4E4E4E;font-size: 12px;">CNT</span>
					</div>
					<div class="twoThat">
						<span style="display: inline-block;">需支付<span>111</span>CNY</span>
					</div>
					<div class="threeThat">
						<span>备注 <span>B780QA</span></span>
					</div>
				</div>
				<div class="tightCt">
					<span style="display: block;padding-right: 15px;padding-top: 13px;">2018-12-25 11:35:11</span>
					<div class="handle" style="position: relative;margin-top: 8px;">
						<span style="display: block;padding-right: 32px;line-height: 43px;">等待处理</span>
						<i class="rightBrackets"></i>
					</div>
				</div>
			</li>
			</router-link>
			<li>
				<div class="leftCt">
					<div class="oneThat">
						<span class="buyspan sellspan">卖</span>
						<span style="color: #4E4E4E;font-size: 12px;">111</span>
						<span style="color: #4E4E4E;font-size: 12px;">CNT</span>
					</div>
					<div class="twoThat">
						<span style="display: inline-block;">需支付<span>111</span>CNY</span>
					</div>
					<div class="threeThat">
						<span>备注 <span>B780QA</span></span>
					</div>
				</div>
				<div class="tightCt">
					<span style="display: block;padding-right: 15px;padding-top: 13px;">2018-12-25 11:35:11</span>
					<div class="handle" style="position: relative;margin-top: 8px;">
						<span style="display: block;padding-right: 32px;line-height: 43px;">等待处理</span>
						<i class="rightBrackets"></i>
					</div>
				</div>
			</li>
		</ul>
		<p style="text-align: center;padding-top: 100px;">没有更多数据</p>
		<yd-popup v-model="show4" position="right">
           <!--<yd-button type="danger" style="margin: 30px;" @click.native="show4 = false">Close Right Popup</yd-button>-->
            <div class="screen">
          		<p>筛选条件</p>
          		<div class="type">
          			<span style="display: block;">类型</span>
          			<div class="detailed" @click="clickclos">
          				<span class="cur">全部</span>
          				<span>购买</span>
          				<span>出售</span>
          			</div>
          		</div>
          		<div class="type">
          			<span style="display: block;">类型</span>
          			<div class="detailed">
          				<span class="cur">全部</span>
          				<span>等待处理</span>
          				<span>处理中</span>
          				<span>成功</span>
          				<span>失败</span>
          				<span>取消</span>
          			</div>
          		</div>
            </div>
          
           
        </yd-popup>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				 show4: false
			}
		},
		methods: {
			clickclos(){
				this.show4 = false 
			}
		}
	}	
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.ctwocOrder{
		.screen{
			width: 235px;
			p{
				font-size: 14px;
				color: #222222;
				text-align: center;
				padding-top: 16px;
				padding-bottom: 15px;
			}
			.type{
				padding-left: 15px;padding-right: 15px;
				border-bottom: 10px solid #FAFAFA;
				.detailed{
					padding-bottom: 5px;
					padding-top:15px;
					.cur{
						color: #05535C;
						border: 1px solid #05535C;
						background: #FFFFFF;
					}
					span{
						text-align: center;
						margin-right: 4px;
						display: inline-block;
						width: 62px;
						line-height: 26px;
						background: #F6F6F6;
						border-radius: 3px;
						color: #222222;
						margin-bottom: 10px;
					}
				}
			}
		}
		ul{
			padding-left: 15px;
			li{
				border-bottom: 1px solid #F6F6F6;
				overflow: hidden;
				.leftCt{
					float: left;
					width:50%;
					
					.oneThat{
						padding-top: 10px;
						padding-bottom: 7px;
						.buyspan{
							width: 16px;height: 17px;background: green;color: white;display: inline-block;text-align: center;
							border-radius: 4px;
						}
						.sellspan{
							background: red;
						}
					}
					.twoThat{
						padding-bottom: 5px;
						font-size: 10px;
						color: #9F9F9F;
					}
					.threeThat{
						font-size: 10px;
						color: #9F9F9F;
						padding-bottom: 9px;
					}
				}
				.tightCt{
					float: right;
					width: 50%;
					text-align: right;
				}
			}
		}
	}
</style>