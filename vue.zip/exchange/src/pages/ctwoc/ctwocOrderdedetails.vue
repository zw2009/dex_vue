<template>
	<div class="ctwocOrderdedetails">
		<div class="top-back">
			<router-link to="ctwocOrder">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>订单详情</span>
		</div>
		<div class="topTt">
			<div class="oneThat">
				<span class="buyspan sellspan">卖</span>
				<span style="color: #4E4E4E;font-size: 12px;">111</span>
				<span style="color: #4E4E4E;font-size: 12px;">CNT</span>
			</div>
			<p>等待处理</p>
		</div>
		<div class="contenCt">
			<div class="titleP">
				<span>出售订单信息</span>
			</div>
			<ul>
				<li>
					<span class="leftSp">数量</span>
					<span class="rightSp">111 CNY</span>
				</li>
				<li>
					<span class="leftSp">代收款</span>
					<span class="rightSp">111 CNY</span>
				</li>
				<li>
					<span class="leftSp">订单号</span>
					<span class="rightSp">D1864135465453465453484517</span>
				</li>
				<li>
					<span class="leftSp">状态</span>
					<span class="rightSp">等待处理</span>
				</li>
				<li>
					<span class="leftSp">创建时间</span>
					<span class="rightSp">2018-12-25 11:35:11</span>
				</li>
				<li>
					<span class="leftSp">更新时间</span>
					<span class="rightSp">2018-12-25 11:35:11</span>
				</li>
			</ul>
			<div class="titleP">
				<span>收款方式提示</span>
			</div>
			<ul>
				<li>
					<span class="leftSp">收款人</span>
					<span class="rightSp">冯圣</span>
				</li>
				<li>
					<span class="leftSp">银行</span>
					<span class="rightSp">中国银行</span>
				</li>
				<li>
					<span class="leftSp">支行</span>
					<span class="rightSp">中国银行股份有限公司长沙市左家塘支行</span>
				</li>
				<li>
					<span class="leftSp">银行卡号</span>
					<span class="rightSp">654894120026649648631553</span>
				</li>
				<li>
					<span class="leftSp">金额</span>
					<span class="rightSp">111 CNY</span>
				</li>
				<li>
					<span class="leftSp">备注/附言</span>
					<input type="" name="" id="" value="" placeholder="B780QA(必须填写)"/>
				</li>
			</ul>
			<div class="title">
			 	<img src="../../../static/img/c2c_attention.png"/>
			 	<span>交易须知</span>
			 </div>
			 <div class="contenText">
			 	<span>1、请按要求向商户付款，必须使用已选择的付款银行卡转账；</span>
			 	<span>2、付款时必须在<span style="color: #C91929;display: inline-block;">[备注/附言]</span>中填写6位字符: <span style="color: #C91929;display: inline-block;">B780QA</span>，不能填写其他内容；</span>
			 	<span>3、商户收到付款后，会在2~24小时办理，如超过24小时未处理，请联系系统客服。</span>
			 </div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		methods: {
		}
	}	
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.ctwocOrderdedetails{
		.contenCt{
			.contenText{
				padding: 10px 15px 25px 15px;
				span{
					display: block;
					line-height: 18px;
				}
			}
			.title{
			padding-left: 15px;
			background: #FAFAFA;
			/*margin-top: 14px;*/
			line-height: 25px;
			overflow: hidden;
			img{
				float: left;
				width: 15px;
				height: 15px;
				margin: 5px 5px 5px 0px;
			}
			span{
				display: block;
				font-size: 14px;
				color: #222222;
			}
		}
			.titleP{
				font-size: 12px;
				color: #222222;
				padding-left: 15px;
				background: #FAFAFA ;
				line-height: 30px;
			}
			ul{
				li{
					padding-left: 15px;
					padding-right: 15px;
					overflow: hidden;
					line-height: 26px;
					.leftSp{
						display: block;
						float: left;
						font-size: 10px;
						color: #9F9F9F;
					}
					.rightSp{
						float: right;
						display: block;
						font-size: 10px;
						color:  #222222;
					}
					input{
						float: right;
						display: block;
						text-align: right;
						border: none;
					}
					::-webkit-input-placeholder { /* WebKit browsers */
						    color: #C91929;
					}
				}
			}
		}
		.topTt{
			text-align: center;
			padding-bottom: 20px;
			.oneThat{
				padding-top: 16px;
				padding-bottom: 7px;
				.buyspan{
					width: 16px;height: 17px;background: green;color: white;display: inline-block;text-align: center;
					border-radius: 4px;
				}
				.sellspan{
					background: red;
				}
			}
		}
	}
</style>