<template>
	<div class="dynamic">
		<div class="topTitle" style="padding:23px 0px 0px 15px; ">
			<span style="font-size: 20px;color: #434A59;">动态</span>
		</div>
		<div class="top_nav">
			<div class="borderf">
				<svg-icon icon-class="dynamic_picture" class='dynamic_copy'/></svg-icon>
				<div class="mid_infor">
					<span class="titleBt">OTC交易</span>
					<span class="textBt">支持CNT/CNY交易 更多资产即将上线</span>
				</div>
				<svg-icon icon-class="dynamic_right" class='imgtwo'/></svg-icon>
			</div>
		</div>	
		<div class="information">
			<p>资讯</p>
			<ul>
				 <!--<router-link to="/dynamicsDetails">-->
					<li v-for="(item,index) in list" :key="index" @click="Jump(item)"> 
						<span class="dedail">{{item.title}}</span>
						<div class="dataoll">
							<span class="leftType">TC</span>
							<span class="rightTime">{{item.day}}-{{item.month}}</span>
						</div>
					</li>
				<!--</router-link>-->
			</ul>
		</div>
		<tabbar></tabbar>
	</div>
</template>

<script>
	import tabbar from '@/components/TabBar'
	export default {
		created(){
			 this.getinfor()
		},
		data() {
			return {
				list:[
//					{title:'井通科技助力打造大型物联网场景应用——服务海能达股份、中移物联、火币中国、世纪乾金联核云项目',typee:'SWTC',time:'12-03'},
//					{title:'井通科技助力打造大型物联网场景应用—',typee:'SWTC',time:'12-03'},
//					{title:'SWTC钱包新版公测-iOS',typee:'SWTC',time:'12-03'},
//					{title:'井通科技助力打造大型物联网场景应用——服务海能达股份、中移物联、火币中国、世纪乾金联核云项目',typee:'SWTC',time:'12-03'},
//					{title:'井通科技助力打造大型物联网场景应用—',typee:'SWTC',time:'12-03'},
				]
			}
		},
		methods: {
			getinfor(){
				this.$api.newindex({}, res =>{
//					this.list = res.data.newsTitle
//					console.log(res.data.newsTitle)
					console.log(res,123331236666666666666)
					if(res.data.newsTitle.length) {
						console.log(res,12333123)
						
						this.list = res.data.newsTitle
						console.log(this.list)
					}
                })
			},
			Jump(item){
				this.$router.push({path: '/dynamicsDetails',query: {editId:item.id,type:this.$route.query.type}})
				console.log(item.id,123)
			}
		},
		components: {
			tabbar
		}
	}
</script>

<style>
	.yd-navbar {
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%)!important;
	}
</style>
<style lang="less" scoped>
	.dynamic{
		background: #FFFFFF;
		.top_nav{
			padding: 15px;
			.borderf{
				position: relative;
				overflow: hidden;
				width: 100%;
				height: 65px;
				box-shadow: 0 0 5px 0 rgba(170,170,170,0.50);
				.dynamic_copy{
					float: left;
					width: 65px;
					height: 60px;
					margin-left: 13px;
				}
				.imgtwo{
					width: 15px;
					height: 17px;
					position: absolute;
					top: 50%;
					transform: translateY(-50%);
					right: 10px;
				}
				.mid_infor{
					padding-left: 10px;
					float: left;
					.titleBt{
						padding-top: 15px;
						padding-bottom: 5px;
						display: block;
						font-size: 12px;
						color: #05535C;
					}
					.textBt{
						display: block;
						font-size: 10px;
						color: #9A9A9A;
					}
				}
			}
		}
		.information{
			padding: 10px 15px 50px 15px;
			p{
				padding-bottom: 15px;
				font-size: 12px;
				color: #9A9A9A;
			}
			ul{
				li{
					margin-bottom: 10px;
					border-bottom: 1px solid #ECECEC;;
					.dedail{
						display: block;
						font-size: 12px;
						color: #333333;
						height: 34px;
					}
					.dataoll{
						width: 100%;
						padding-top: 15px;
						padding-bottom: 10px;
						overflow: hidden;
						.leftType{
							float: left;
							display: block;
						}
						.rightTime{
							display: block;
							float: right;
						}
					}
					
				}
			}
		}
	}
</style>