<template>
	<div class="dynamicsDetails">
	   <div class="top-back">
			<router-link to="dynamics">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>{{title}}</span>
			<img @click="toggle" src="../../../static/img/dynamic_more.png" width="20" height="4" />
			
		</div>
	    <div class="topNav">
	    	<p style="font-size: 16px;color: #222222;line-height: 42px;">{{title}}</p>
	    	<span style="display: block;line-height: 27px;font-size: 12px;color: #333333;">TC</span>
	    	<span style="font-size: 10px;color: #9A9A9A;">{{created_at}}</span>
	    </div>
	    <div class="content">
	    	<p style="font-size: 12px;color: #333333;line-height: 43px;font-size: 12px;">SWTC钱包升级啦，现开放iOS版测试，欢迎大家体验！</p>
	   		<div class="listct">
	   			<span>{{content}}</span>
	   			<!--<span>1、界面全新改版升级；</span>
	   			<span>2、多语言适配，增加英文版；</span>
	   			<span>3、行情、交易、K线、深度图优化；</span>
	   			<span>4、开放国际手机号注册；</span>
	   			<span>5、bug修复。</span>
	   			<span>6、下载地址：https://fir.im/swtcwalletiosbeta</span>-->
	   		</div>
	    </div>
	    <div class="content">
	   		<div class="listct">
	   			<span>安装提示：</span>
	   			<span>1、版本安装好后，如果不能正常打开，要在“设置-通用-设备管理”里面点信任，才可以正常使用。</span>
	   			<span>2、如果A安装失败，请先卸载旧版本。</span>
	   		</div>
	    </div>
	    <div class="content">
	   		<div class="listct">
	   			<span>公测QQ群：</span>
	   			<span>1、1008611256（发现问题可以到这里反馈）</span>
	   		</div>
	    </div>
	    <div class="content">
	   		<div class="listct">
	   			<span>欢迎大家使用！</span>
	   		</div>
	    </div>
	   <yd-popup v-model="show" position="bottom" width="95%">
       <div class="popup">
      	 	<div class="round">
       		<ul>
       			<li>
       				<svg-icon icon-class="dynamic_refresh" class='imgtwo'/></svg-icon>
       				<span>刷新</span>
       			</li>
       			<li>
       				<svg-icon icon-class="dynamic_share" class='imgtwo'/></svg-icon>
       				<span>分享</span>
       			</li>
       			<li>
       				<svg-icon icon-class="dynamic_copy" class='imgtwo'/></svg-icon>
       				<span>复制</span>
       			</li>
       			<li>
       				<svg-icon icon-class="dynamic_browser" class='imgtwo'/></svg-icon>
       				<span>浏览器中打开</span>
       			</li>
       		</ul>
       		<span style="display: block;line-height: 40px;color: #888888;text-align: center;" @click="show = false">取消</span>
       		</div>
       </div>
       </yd-popup>
	</div>
</template>

<script>
	import tabbar from '@/components/TabBar'
	export default {
		created() {
			const notice_id = this.$route.query.editId
			console.log(notice_id)
			if (notice_id) {
				this.$api.newsinfor({
					notice_id: notice_id,
				}, res => {
					console.log(res,123)
					if(res.status) {
						let data = res.data
						this.title = data.news.title
						this.created_at = data.news.created_at
						this.content = data.news.content
					}
			})
			}	
		},	
		data() {
			return {
				show:false,
				title:'',
				created_at:'',
				content:'',
				
			}
		},
		methods: {
			toggle(){
				this.show = !this.show;
			},
			cancel(){
				this.show = false
			}
			
		}
	}
</script>
<style type="text/css">
	.dynamicsDetails .yd-popup{
		width: 94%!important;
	    margin-left: 3%;
	    margin-right: 3%;
	    margin-bottom: 3%;
	    border-radius: 12px;
	    height: auto;
	}
	
</style>
<style lang="less" scoped>
	.dynamicsDetails{
		background: #FFFFFF;
				.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			img{
				position: absolute;
				right: 15px;
				top: 50%;
				transform: translateY(-50%);
			}
			span{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
		}
		.topNav{
			padding-left: 15px;
			padding-right: 15px;
			border-bottom: 1px solid  #ECECEC;
			padding-bottom: 10px;
		}
		.content{
			padding-left: 15px;
			.listct{
				padding-bottom:20px;
				padding-right:23px;
				span{
					font-size: 12px;
					color: #333333;
					line-height: 18px;
					display: block;
				}
			}
		}
		.popup{
			/*margin: 0 8px;*/
			.round{
				height: 140px;
				background: rgba(248,248,248,0.82);
				border-radius: 14px;
				ul{
					border-bottom: 1px solid  #3F3F3F;
					overflow: hidden;
					li{
					float: left;
					width: 25%;
					text-align: center;
					.imgtwo{
						width: 40px;
						height: 40px;
						margin-top: 20px;
						margin-bottom: 5px;
					}
					span{
						display: block;
						padding-bottom: 12px;
					}
				}
			}
			p{
				padding-top: 12px;
				font-size: 17px;
				color: #828282;
				text-align: center;
			}
			}

		}
	}
</style>