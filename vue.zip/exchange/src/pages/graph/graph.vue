<template>
	<div class="graph">
		<!--<yd-navbar color="#fff" title="SWTC / CNT">
			<router-link to="/user" slot="left">
				<img src="../../../static/img/trading_market.png" width="19" height="17"/>
			</router-link>
		</yd-navbar>-->
		<div class="topposNav">
			<router-link to="transactions">
				<img class="logo" src="../../../static/img/trading_market.png" width="19" height="17" />
			</router-link>
			<span>TC / CNT</span>
			<img class="midimg" src="../../../static/img/market_Under_white.png" />
		</div>
		<!--<div id="main" style="width:100%;height:500px;"></div>-->
		<div class="bodyCont">
			<yd-tab v-model="tab1">
				<yd-tab-panel label="市场委托">
					<div class="entrust">
						<ul>
							<li class="firstLis">
								<span style="text-align: left;">数量</span>
								<span>买盘</span>
								<span>价格</span>
								<span style="text-align: left;">价格</span>
								<span>卖盘</span>
								<span style="text-align: right;">数量</span>
							</li>
							<li class="lastLis" v-for="list in lists">
								<span style="text-align: left;">{{list.num}}</span>
								<span style="color: #07AC71;">{{list.price}}</span>
								<span style="text-align: left;color: #E85353;">{{list.pricess}}</span>
								<span style="text-align: right;">{{list.number}}</span>
							</li>
						</ul>
					</div>
				</yd-tab-panel>
				<yd-tab-panel label="最新成交">
					<div class="deal">
						<ul>
							<li class="firstLiss">
								<span style="text-align: left;">时间</span>
								<span>价格</span>
								<span style="text-align: right;">数量</span>
							</li>
							<li v-for="item in items">
								<span style="text-align: left;">{{item.time}}</span>
								<span style="color: #E85353;">{{item.pricel}}</span>
								<span style="text-align: right;">{{item.nums}}</span>
							</li>
						</ul>
					</div>
				</yd-tab-panel>
				<yd-tab-panel label="介绍">
					<div class="introduce">
						<p>TC (System Working Token China)</p>
						<ul>
							<li>
								<span class="leftSpan">发行时间</span>
								<span class="rightSpan black">暂无数据</span>
							</li>
							<li>
								<span class="leftSpan">发行总量</span>
								<span class="rightSpan black">600,000,000,000</span>
							</li>
							<li>
								<span class="leftSpan">流通总量</span>
								<span class="rightSpan black">100,000,000,000</span>
							</li>
							<li>
								<span class="leftSpan">发行价格</span>
								<span class="rightSpan black">暂无数据</span>
							</li>
							<li>
								<span class="leftSpan">白皮书</span>
								<span class="rightSpan blue">http://tc.top/a/paper/</span>
							</li>
							<li>
								<span class="leftSpan">官网</span>
								<span class="rightSpan blue">http://tc.top/a/paper/</span>
							</li>
						</ul>
						<span class="content">TC (System Working Token China) Token是TC公链接的原声数字资产，由TC基金会（新加坡）发行并负责运营。其作用类似于比特币系统中的BTC或以太坊中的ETH，是TC公链上的底层燃料和通用通证。除了作用SETC公链系统中交易费用的消费手段、信用质押、跨链跨通证计价单位。同时，SETC Token可以保障系统运行的稳定和安全，提高恶意攻击的成本。
TC公链采用自有知识产权的RBFT共识算法，耗时5年研发，充分考虑了大规模商用化要求，支持高速的交易并发量、区块生成时间10秒、实现全球首个异步合约调用以及亚秒级拜占庭容错的快速合约调用，是国际上为数不多的，能够支撑大规模商用化、以及复杂业务场景的区块链底层公链。</span>
					</div>
				</yd-tab-panel>
			</yd-tab>
		</div>
		<div class="posBotoom">
			<div class="borderTwo">
				<span class="borderbuy">买入</span>
				<span class="bordersell">卖出</span>
			</div>
		</div>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				tab1: 0,
				lists: [{
						num: '328,258',
						price: 0.00586,
						pricess: 0.00589,
						number: '328,258'
					},
					{
						num: '328,258',
						price: 0.00586,
						pricess: 0.00589,
						number: '328,258'
					},
					{
						num: '328,258',
						price: 0.00586,
						pricess: 0.00589,
						number: '328,258'
					},
				],
				items: [{
						time: '14:03:50',
						pricel: 0.00589,
						nums: '1,089,970'
					},
					{
						time: '14:03:50',
						pricel: 0.00589,
						nums: '1,089,970'
					},
				]
			}
		}
	}
</script>

<style lang="less" scoped>
	.graph {
		.topposNav {
			position: fixed;
			width: 100%;
			height: 50px;
			line-height: 50px;
			background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
			z-index: 999;
			.logo {
				margin-left: 15px;
				margin-top: 15px;
			}
			.midimg {
				width: 9px;
				height: 6px;
				display: block;
				position: absolute;
				top: 50%;
				left: 62%;
				transform: translateY(-50%);
			}
			span {
				position: absolute;
				font-size: 14px;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				color: white;
			}
		}
		.posBotoom {
			width: 100%;
			padding: 0 15px 10px 15px;
			.borderTwo {
				width: 100%;
				margin: 0 auto;
				overflow: hidden;
				text-align: center;
				line-height: 35px;
				.borderbuy {
					float: left;
					display: block;
					width: 49%;
					background: #00A96C;
					border-radius: 3px;
					color: white;
				}
				.bordersell {
					width: 49%;
					float: right;
					display: block;
					background: #E85353;
					border-radius: 3px;
					color: white;
				}
			}
		}
		.bodyCont {
			padding-top: 50px;
			padding-bottom: 50px;
			.entrust {
				padding-left: 10px;
				padding-right: 10px;
				ul {
					.firstLis {
						overflow: hidden;
						text-align: center;
						span {
							display: block;
							width: 16.5%;
							line-height: 30px;
							color: #9A9A9A;
							float: left;
						}
					}
					.lastLis {
						overflow: hidden;
						span {
							text-align: center;
							display: block;
							float: left;
							line-height: 20px;
							width: 25%;
						}
					}
				}
			}
			.deal {
				padding-left: 10px;
				padding-right: 10px;
				ul {
					.firstLiss {
						line-height: 30px;
						span {
							display: block;
							color: #9A9A9A;
						}
					}
					li {
						overflow: hidden;
						text-align: center;
						span {
							float: left;
							width: 33%;
							line-height: 22px;
						}
					}
				}
			}
			.introduce {
				padding-left: 10px;
				padding-right: 10px;
				p {
					font-size: 14px;
					color: #222222;
					line-height: 40px;
				}
				.content {
					display: block;
					font-size: 11px;
					color: #000000;
					line-height: 20px;
				}
				ul {
					padding-bottom: 30px;
					li {
						overflow: hidden;
						line-height: 40px;
						border-bottom: 1px solid #ECECEC;
						span {
							color: #B8B8B8;
							font-size: 12px;
						}
						.black {
							color: #000000;
						}
						.blue {
							color: #3E63FD;
						}
						.leftSpan {
							display: block;
							float: left;
						}
						.rightSpan {
							float: right;
							display: block;
						}
					}
				}
			}
		}
	}
</style>