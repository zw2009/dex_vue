<template>
	<div class="login">
		<!--<div class="topNav" style="height: 50px;background: #FFF;">
			<img src="../../../static/img/top_wrong.png"/>
		</div>-->
		<span style="font-size: 20px;color: #434A59;padding:20px 0px 40px 15px;display: block;">登录</span>
		<div class="contentLogin">
		<yd-tab v-model="tab1">
			<yd-tab-panel label="手机">
				<div class="phone">
					<ul>
						<!--<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="phone" ref="phone" placeholder="手机号"></yd-input>
							</yd-cell-item>
						</li>-->
						<li>
							<em></em>
						<!-- 	<select id="sss" v-model='issue'>
                    <option v-for="(item,index) in issues" :value='index' :key='index'>+{{index}}</option>
              </select> -->
              <input  class="code"  v-model="issue" @click="selectCode" readonly="readonly">
                <em></em>
							<yd-cell-item>
								<yd-input  slot="right" v-model="phone"  placeholder="手机号"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="code"  placeholder="验证码"></yd-input>
				           		<yd-sendcode class="sendsms" slot="right" v-model="start" init-str="发送" @click.native="sendCode" type="warning"></yd-sendcode>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="password" placeholder="请输入密码"></yd-input>
							</yd-cell-item>
						</li>
					</ul>
				</div>
			</yd-tab-panel>
			<yd-tab-panel label="邮箱">
				<div class="phone">
					<ul>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="email" ref="email" placeholder="邮箱"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="emailCode" ref="emailCode" placeholder="验证码"></yd-input>
								<yd-sendcode class="sendsms" slot="right" v-model="starttwo" init-str="发送" @click.native="emailsendCode" type="warning"></yd-sendcode>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="passwordEmail" placeholder="请输入密码"></yd-input>
							</yd-cell-item>
						</li>
					</ul>

				</div>
			</yd-tab-panel>
		</yd-tab>
		</div>
		<div class="buttonds" @click="login">
			<button>立即登录</button>
		</div>
		<div class="bottonnav">
			<router-link to="/register">
				<span class="register">立即注册</span>
			</router-link>
			<router-link to="/retrieve">
				<span class="retrieve">忘记密码?</span>
			</router-link>
		</div>
		<div class="posBotooms">
			<span>不能登录？联系客服</span>
		</div>
	</div>
</template>

<script>
	import {setStore,removeStore} from '@/common/storage.js'
	export default {
	created(){
		 if(this.$route.query.issue){
            this.issue = this.$route.query.issue
         }
		
        this.getinfor()
    },
		data() {
			return {
				tab1: 0,	//手机块
				code: '',	//手机块验证码
				issue: 86,	//国家地区
				phone: '',		//手机号码
				email: '',		//邮箱
				emailCode: '',	//邮箱验证码
				passwordEmail: '',	//邮箱密码
				operation:2,		//发送的短信的场景
				start: false,		
				starttwo:false,
				password: '',		//手机密码
				issues:[],
			}
		},
		methods: {
			selectCode(){
		       this.$router.push('/countryCode')
		    },
			
			
			getinfor(){
                this.$api.indexs({}, res =>{
                	this.issues = res.data
					console.log(res.data)
                })
            },
			sendCode() {
				let reg=/^1[3456789]\d{9}$/;
                if(!this.phone){
                    this.$dialog.toast({mes:'请输入手机号',timeout: 1000})
                    return;
                }
                if(!reg.test(this.phone)){
                	this.$dialog.toast({mes:'请输入正确手机号',timeout: 1000})
                }
                this.$dialog.loading.open('发送中...');
                setTimeout(() => {
					this.$dialog.loading.close();
                    this.$api.checkSms({
                    	account:this.phone, 
                    	scene:'login',
                    	country:this.issue,
                    	type:1,
                    	}, res =>{
                                console.log(res)
                                if(!res.status){
                                    this.$dialog.toast({mes:res.msg, timeout:1000})
                                    this.phone =""
                                }else{
                                	console.log(123)
                                	this.start = true;
                                    this.$dialog.toast({mes:'已发送',icon: 'success', timeout: 1500})
                                    
                                }
                            })
				}, 1000);
			},
			emailsendCode(){
				 if(!this.email){
                    this.$dialog.toast({mes:'请输入邮箱号',timeout: 1000})
                    return;
                }
				this.$dialog.loading.open('发送中...');
                setTimeout(() => {
					this.$dialog.loading.close();
                    this.$api.checkSms({
                    	account:this.email, 
                    	scene:'login ',
//                  	operation:'reg',
                    	type:2,
                    	country:this.issue,
//                  	code:this.code,
                    	}, res =>{
                            if(!res.status){
                                this.$dialog.toast({mes:res.msg, timeout:1000})
                                this.email =""
                            }else{
                                this.$dialog.toast({mes:'已发送',icon: 'success', timeout: 1500})
                                this.start = true;
                            }
                        })
				}, 1000);
			},
			login(){
				this.$router.replace('/index')
			},
			
			
//			login(){
//				let reg=/^1[3456789]\d{9}$/;
//				if(!this.phone){
//                  this.$dialog.toast({mes:'请输入手机号',timeout: 1000})
//                  return;
//              }
//				if(!reg.test(this.phone)){
//              	this.$dialog.toast({mes:'请输入正确手机号',timeout: 1000})
//              }
//				if (!this.code) {
//					this.$dialog.toast({mes:'请输入正确的验证码',timeout: 1000})
//					return;
//				} 
//				if (!this.password) {
//					this.$dialog.toast({mes:'请输入正确的密码',timeout:1000})
//					return;
//				}
//				else{
//					this.$dialog.loading.open('登录中...');
//					setTimeout(() => {
//					this.$api.login({
//						account:this.phone,
//						password:this.password,
//						code:this.code,
//						scene:'login',
//						country:this.issue,
//						type:1,
//					}, res =>{
//						this.$dialog.loading.close();
//		                if(res.status){
//                      	this.$dialog.toast({mes:'登录成功',timeout:700,callback:()=>{
//                      		console.log(res)
//                      		setStore('user_token',res.data)
//                      		this.$router.replace('/index')
//								console.log(res.data)
//                      	}})
//	                    }else{
//	                    	if(res.msg == '此用户不存在'){
//	                    		this.$dialog.toast({mes:res.msg,timeout:700})
//	                    }else{
//	                    	this.$dialog.toast({mes:res.msg,timeout:700})
//	                	}
//						}
//						})
//					}, 1000);
//				}
//			}
			
		}
		}
</script>

<style type="text/css">
	.contentLogin .yd-navbar:after{
		display: none!important;
	}
	.contentLogin .yd-tab-nav-nomal .yd-tab-nav .yd-tab-nav-item{
		width: 15%!important;
		flex: inherit
	}
	.contentLogin .yd-tab-nav:after{
		display: none!important;
	}
	
	.contentLogin .yd-tab-panel-item.yd-tab-active{
		padding-top: 30px!important;
	}
	
	
	.contentLogin .yd-btn-warning:not(.yd-btn-loading){
		background: #FFFFFF!important;
		color: #05535C;
	}  
	.contentLogin .yd-input-password:after {
		color: #05535C;
	}
	
	.contentLogin .yd-btn-primary:not(.yd-btn-loading):active {
		background: #FFFFFF;
	}
	
	.contentLogin .yd-btn-primary:not(.yd-btn-loading) {
		width: 100px;
		text-align: right;
		font-size: 14px;
		color: #05535C;
		background: #FFFFFF;
	}
	
	.contentLogin .yd-cell-item {
		padding-left: 15px !important;
	}
	
	.contentLogin .yd-tab-nav-item {
		color: #05535C !important;
	}
	
	.contentLogin .yd-tab-active {
		color: #05535C !important;
	}
	
	.contentLogin .yd-tab-active:before {
		width: 30% !important;
		margin-left: -15% !important;
	}
	
	.contentLogin .yd-btn-disabled{
		background-color:white!important;
		color: #05535C!important;
	}
</style>
<style lang="less" scoped>
	.login {
		background: #FFFFFF;
		padding-bottom: 200px;
		.topNav{
			position: relative;
			img{
				position: absolute;
				margin-top: 16px;
				margin-left: 15px;
				width: 13px;
				height: 13px;
			}
		}
		.posBotooms{
			left: 50%;
			transform: translateX(-50%);
			position: absolute;
			bottom: 20px;
			font-size: 12px;
			color: #7B808A;
		}
		.phone {
			background: #FFFFFF;
			li {
				height: 50px;
				border-bottom: 1px solid #ECECEC;
				line-height: 50px;
				position: relative;
				em{
					display: block;
					width: .18rem;
					height: .18rem;
					border-left: .02rem solid #000000;
					border-bottom: .02rem solid #000000;
					position: absolute;
					top: 50%;
					left:1.3rem;
					transform: translate(0,-50%) rotate(315deg) ;

				}
				.code{
		            width: 15%;
		            display: block;
		            float: left;
		            margin-left: 15px;
		            line-height: 50px;
		            border: none;
		        }
			}
		}
		.buttonds {
			padding: 30px 15px 20px 15px;
			button {
				width: 100%;
				margin: 0 auto;
				border: none;
				color: white;
				font-size: 14px;
				line-height: 35px;
				background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
			}
		}
		.bottonnav {
			overflow: hidden;
			padding: 0 15px;
			.register {
				float: left;
				font-size: 12px;
				color: #05535C;
			}
			.retrieve {
				float: right;
				font-size: 12px;
				color: #05535C;
			}
		}
	}
</style>