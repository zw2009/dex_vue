<template>
	<div class="otc">
		<div class="top-back" style="line-height: 35px;">
			<router-link to="assets">
				<div class="click"></div>
				<em style="top: 70%;"></em>
			</router-link>
			<span style="display: block;text-align: center;padding-left: 0;">TC/CNY</span>
			<span style="display: block;line-height: 0;text-align: center;font-size: 10px;padding-left: 0;">参考价格 1TC≈1CNY</span>
			<div class="clickss" @click="showNoes"  style="right: 0; top: 0;position: absolute;width: 40px;height: 40px;">
				<img style="width: 20px;height: 20px;margin-top: 15px;margin-left: 2px;" src="../../../static/img/mall_addss_.png"/>
			</div>
		</div>
		<div class="showNoe" v-show="showNoe">
    			<em></em>
    			<ul>
    				<router-link to="otcPublish">
	    				<li>
	                        <svg-icon icon-class="otc_release" class="icon-pay"></svg-icon>
	    					<span>发布广告</span>
	    				</li>
    				</router-link>
    				<router-link to="otcPoster">
	    				<li>
	                        <svg-icon icon-class="otc_ggrun" class="icon-pay"></svg-icon>
	    					<span>广告管理</span>
	    				</li>
    				</router-link>
    				<router-link to="otcTrust">
	    				<li>
	                        <svg-icon icon-class="otc_trust" class="icon-pay"></svg-icon>
	    					<span>信任管理</span>
	    				</li>
    				</router-link>
    			</ul>
    		</div>
		<div class="contenttwo">
			<yd-tab v-model="tab1" color="#000" active-color="#05535C">
				<yd-tab-panel label="购买">
					<div class="buy">
						<ul>
							<li v-for="item in list">
								<div class="topnav">
									<div class="leftSp">
										<img src="../../../static/img/toux2.png"/>
										<span>{{item.name}}</span>
									</div>
									<span class="rightSp">交易{{item.deal}} | 好评率{{item.praise}} | 信任{{item.trust}}</span>
								</div>
								<div class="bodyCt">
									<div class="leftCc">
										<span>数量&nbsp;&nbsp;{{item.number}}CNT</span>
										<span>限额&nbsp;&nbsp;{{item.quota}}CNY</span>
										<img src="../../../static/img/zfb.png"/>
										<img src="../../../static/img/yhcard.png"/>
									</div>
									<div class="rightCc">
										<span>0.9807 CNY</span>
										<router-link to="otcBuy">
											<button>购买</button>
										</router-link>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</yd-tab-panel>
				<yd-tab-panel label="出售">
					<div class="Sell buy">
						<ul>
							<li v-for="item in list">
								<div class="topnav">
									<div class="leftSp">
										<img src="../../../static/img/toux2.png"/>
										<span>{{item.name}}</span>
									</div>
									<span class="rightSp">交易{{item.deal}} | 好评率{{item.praise}} | 信任{{item.trust}}</span>
								</div>
								<div class="bodyCt">
									<div class="leftCc">
										<span>数量&nbsp;&nbsp;{{item.number}}CNT</span>
										<span>限额&nbsp;&nbsp;{{item.quota}}CNY</span>
										<img src="../../../static/img/wx.png"/>
										<img src="../../../static/img/zfb.png"/>
										<img src="../../../static/img/yhcard.png"/>
									</div>
									<div class="rightCc">
										<span>0.9807 CNY</span>
										<router-link to="otcSell">
											<button>出售</button>
										</router-link>
									</div>
								</div>
							</li>
						</ul>
					</div>
				</yd-tab-panel>
			</yd-tab>
		</div>
		<otcTab></otcTab>
	</div>
	

	
</template>

<script>
	
	import otcTab from '@/components/otcTab'
	
	export default {
		data() {
			return {
				tab1 : 0 ,
				showNoe:false,
				list : [
					{name:'Sunny609',deal:1435,praise:'100%',trust:142,number:'2862,00',quota:'100-50000,00'},
					{name:'Sunny609',deal:1435,praise:'100%',trust:142,number:'2862,00',quota:'100-50000,00'},
				]
			}
		},
		methods: {
			showNoes(){
				if (!this.showNoe) {
					this.showNoe = true
				} else{
					this.showNoe = false
				}

			},
		},
		components: {
			otcTab
		},
	}
</script>
<style type="text/css">
	.otc .yd-tab-nav-nomal .yd-tab-nav{
		border-bottom: 10px solid #F1F1F1;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.otc{
		.showNoe{
			background: #fff;width: 108px;height: 120px;
			z-index: 999;
			box-shadow: 2px 2px 20px 2px rgba(221,221,221,0.50);
			position: absolute;top: 50px;right: 10px;border-radius: 5px;
			em{
				box-shadow: 1px 1px 1px rgba(221,221,221,0.50);
				display: block;
				width: 12px;
				height: 12px;
				border-left: .2rem solid #fff;
				border-bottom: .2rem solid  #fff;
				position: absolute;
				top: 0px;
				right: 12px;
				transform: translate(0, -50%) rotate(225deg);
			}
			ul{
				li{
					overflow: hidden;
					margin-top: 5px;
					.icon-pay{
						float: left;
						margin: 7px 12px 10px 10px;
						font-size: 20px;
					}
					span{
						padding-top: 5px;
						display: block;
						font-size: 14px;
						color: #494949;
					}
				}
			}
		}
		.contenttwo{
			.buy{
				ul{
					li{
						border-bottom: 10px solid #f1f1f1;
						padding-left: 10px;
						padding-right: 10px;
						.topnav{
							padding-top: 10px;
							overflow: hidden;
							.leftSp{
								float: left;
								overflow: hidden;
								img{
									margin-top: 6px;
									float: left;
									margin-right: 10px;
									width: 24px;
									height: 24px;
									margin-bottom: 16px;
								}
								span{
									padding-top: 10px;
									font-size: 14px;
									float: left;
									display: inline-block;
								}
							}
							.rightSp{
								display:block;
								font-size: 10px;
								float: right;
								padding-top: 10px;
							}
						}
						.bodyCt{
							padding-bottom: 16px;
							overflow: hidden;
							.leftCc{
								float: left;
								span{
									display: block;
									padding-left: 5px;
									font-size: 12px;
									padding-bottom: 3px;
									color: rgb(153,153,153);
								}
								img{
									margin-top: 13px;
									width: 20px;
									height: 20px;
									margin-right: 10px;
								}
							}
							.rightCc{
								float: right;
								span{
									font-size: 18px;
									color: rgb(73,73,73);
								}
								button{
									margin-top: 30px;
									outline: none;
									border: none;
									color: white;
									font-size: 14px;
									display: block;
									width: 90px;
									line-height: 30px;
									background: rgb(34,116,123);
									border-radius: 4px;
								}
							}
						}
					}
				}
			}
		}
	}
</style>