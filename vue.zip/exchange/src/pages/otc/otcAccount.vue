<template>
	<div class="otcAccount">
		<div class="top-back" style="    box-shadow: 0px 3px 4px #f1f1f1;">
			<router-link to="otc">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">账户</span>
		</div>
		<div class="infor">
			<div class="topinfor">
				<img src="../../../static/img/toux.png"/>
				<span>Sunny609</span>
			</div>
			<div class="botinfor">
				<span>交易量-</span>
				<span>好评-</span>
				<span>信任-</span>
			</div>
		</div>
		<ul>
			<li style="border-bottom: 10px solid #F7F7F7;">
				<span class="leftspan">交易统计</span>
				<em></em>
			</li>
			<router-link to="otcWechat">
				<li>
					<img src="../../../static/img/wx.png"/>
					<span class="leftspan">微信</span>
					<span class="rightspan">18588432006</span>	
					<em></em>
				</li>
			</router-link>	
			<router-link to="otcAlipay">
				<li>
					<img src="../../../static/img/zfb.png"/>
					<span class="leftspan">支付宝</span>
					<span class="rightspan">设置</span>	
					<em></em>
				</li>
			</router-link>
			<router-link to="otcAddcard">
				<li>
					<img src="../../../static/img/yhcard.png"/>
					<span class="leftspan">银行卡</span>
					<span class="rightspan">设置</span>	
					<em></em>
				</li>
			</router-link>		
			<li>
				<img src="../../../static/img/kfotc.png"/>
				<span class="leftspan">OTC客服</span>
				<em></em>
			</li>
		</ul>
		
		<otcTab></otcTab>
	</div>
</template>

<script>
	import otcTab from '@/components/otcTab'
	export default {
		data() {
			return {
				
			}
		},
		methods:{
			
		},
		components: {
			otcTab
		},
	}
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.otcAccount{
		.infor{
			border-bottom:10px solid #F7F7F7;
			.topinfor{
				padding-left: 20px;
				overflow: hidden;
				img{
					float: left;
					margin: 14px 10px 14px 0;
					width: 24px;
					height: 24px;
				}
				span{
					display: block;
					padding-top: 20px;
					float: left;
				}
			}
			.botinfor{
				padding-left: 20px;
				overflow: hidden;
				span{
					width: 30%;
					float: left;
					display: block;
					padding-bottom: 14px;
				}
			}
		}
		ul{
			li{
				overflow: hidden;
				position: relative;
				line-height: 50px;
				padding-left: 20px;
				.leftspan{
					display: block;
					float: left;
					color: #494949;
					font-size: 14px;
				}
				img{
					float: left;
					width: 20px;
					height: 20px;
					margin-top: 15px;
					margin-right: 10px;
				}
				.rightspan{
					float: right;
					display: block;
					padding-right: 40px;
				}
				em{
					display: block;
					width: .18rem;
					height: .18rem;
					border-left: 2px solid #979797;
					border-bottom: 2px solid #979797;
					position: absolute;
					top: 50%;
					right:20px;
					transform: translate(0,-50%) rotate(225deg) ;
				}
			}
		}
	}
</style>