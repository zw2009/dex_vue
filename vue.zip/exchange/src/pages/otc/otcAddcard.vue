<template>
	<div class="otcAddcard">
		<div class="top-back" style="    box-shadow: 0px 3px 4px #f1f1f1;">
			<router-link to="otcAccount">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">添加银行卡</span>
		</div>
		<ul>
			<li>
				<span>省份</span>
				<select name="" >
					<option value="">123</option>
					<option value="">1234</option>
				</select>
				<em></em>
			</li>
			<li>
				<span>城市</span>
				<select name="" >
					<option value="">123</option>
					<option value="">1234</option>
				</select>
				<em></em>
			</li>
			<li>
				<span>开户银行</span>
				<select name="" >
					<option value="">123</option>
					<option value="">1234</option>
				</select>
				<em></em>
			</li>
			<li>
				<span>支行名称</span>
				<select name="" >
					<option value="">123</option>
					<option value="">1234</option>
				</select>
				<em></em>
			</li>
			<li>
				<span>银行卡号</span>
				<input type="" name="" id="" value="" />
			</li>
		</ul>
		<button>确认</button>
	</div>
</template>


<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
		}	
	}
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.otcAddcard{
		button{
			margin: 36px auto;
			outline: none;
			border: none;
			color: white;
			font-size: 14px;
			display: block;
			width: 90%;
			line-height: 36px;
			background: rgb(34,116,123);
			border-radius: 4px;
		}
		ul{
			li{
				height: 68px;
				position: relative;
				border-bottom: 1px solid #E3E3E3;
				padding-left: 20px;
				span{
					display: block;
					padding-top: 16px;
					padding-bottom: 8px;
					font-size: 14px;
				}
				select{
					width: 100%;
					border: none;
					font-size: 14px;
				}
				input{
					width: 100%;
					font-size: 14px;
					border: none;
				}
				em{
					display: block;
					width: .18rem;
					height: .18rem;
					border-left: 2px solid #979797;
					border-bottom: 2px solid #979797;
					position: absolute;
					top: 50%;
					right:20px;
					transform: translate(0,-50%) rotate(225deg) ;
				}
			}
		}
		
	}
		
</style>