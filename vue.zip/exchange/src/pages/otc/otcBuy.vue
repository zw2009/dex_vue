<template>
	<div class="otcSell">
		<div class="top-back">
			<router-link to="otc">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">购买CNT</span>
		</div>
		<ul>
			<li>
				<span class="leftspp">价格</span>
				<div class="rightspp">
					<span>0.9803CNY</span>
				</div>
			</li>
			<li>
				<span class="leftspp">数量</span>
				<div class="rightspp">
					<span>29，892CNY</span>
				</div>
			</li>
			<li>
				<span class="leftspp">限额</span>
				<div class="rightspp">
					<span>100-30,000CNY</span>
				</div>
			</li>
			<li @click="show1 = true">
				<span class="leftspp">付款方式</span>
				<div class="rightspp">
					<img src="../../../static/img/zfb.png"/>
					<img src="../../../static/img/yhcard.png"/>
				</div>
			</li>
			<li style="border-bottom: 10px solid  #E3E3E3;">
				<span class="leftspp">交易期限</span>
				<div class="rightspp">
					<span>60分钟</span>
				</div>
			</li>
			<li>
				<span class="leftspp">出售数量</span>
				<div class="rightspp">
					<input type="" name="" id="" value="0" />
					CNY
				</div>
			</li>
			<li>
				<span class="leftspp">出售金额</span>
				<div class="rightspp">
					<input type="" name="" id="" value="0" />
					CNY
				</div>
			</li>
			<!--<li>
				<span class="leftspp">收款方式</span>
				<div class="rightspp">
					<select name="">
						<option value="">支付宝</option>
						<option value="">微信</option>
						<option value="">银行卡</option>
					</select>
					<em></em>
				</div>
			</li>-->
		</ul>
		<div class="agree">
			<em @click="clickimg">
				<img v-show="imggou" src="../../../static/img/gougou.png"/>
			</em>
			<span>同意 <span style="color:#16686F;">OTC用户交易协议</span></span>
		</div>
		<div class="confirm"  style="border-bottom: 10px solid  #E3E3E3;">
			<yd-button size="large" type="primary" @click.native="out" shape="angle">确认购买</yd-button>
		</div>
		<div class="infor" style="border-bottom: 10px solid  #E3E3E3;">
			<p>买方信息</p>
			<div class="ovfloo">
				<img src="../../../static/img/toux.png"/>
				<span>溜滴滑</span>
			</div>
			<div class="detail">
				<span>交易量 669</span>
				<span>好评 92%</span>
				<span>信任 30</span>
			</div>
		</div>
		<div class="tips">
			<p>交易提示</p>
			<span>1、买方需在规定时间内支付订单，并确认付款；</span>
			<span>2、您的汇款将直接进入卖方账户，交易过程中卖方出售的数字资产由平台委托保护；</span>
			<span>3、买方当日累计三笔订单取消，买方当日不可买入。</span>
			<span style="display: block;color: #287A81;padding-top: 10px;padding-bottom: 10px;">查看详细交易规则</span>
		</div>
		
		<!--支付宝和银行点击-->
		 <!--<yd-popup v-model="show2" position="center" width="75%">
            <div class="Popup">
            	<div class="titletc">
            		<img src="../../../static/img/yhcard.png"/>
            		<span>银行卡</span>
            	</div>
            	<ul>
            		<li>
            			<span class="leftssp">19052210306157</span>
            			<span class="rightsp">复制</span>
            		</li>
            		<li>
            			<span class="leftssp">兴业银行</span>
            			<span class="rightsp">复制</span>
            		</li>
            		<li>
            			<span class="leftssp">兴业银行股份有限公司惠州分行</span>
            			<span class="rightsp">复制</span>
            		</li>
            		<li>
            			<span class="leftssp">杨伟霞</span>
            			<span class="rightsp">复制</span>
            		</li>
            	</ul>
            </div>
        </yd-popup>
        <yd-popup v-model="show1" position="center" width="75%">
        	<div class="Popup">
        		<img src="../../../build/logo.png"/>
        		<div class="copy">
        			<span>xxxxxxxxxxxx.com</span>
        			<img src="../../../static/img/copyfz.png"/>
        		</div>
        		<p>刘德华</p>
        	</div>
    	</yd-popup>-->
	</div>
</template>

<script>
	export default {
		data() {
			return {
				imggou:false,
//				show1: false,
//				show2: false,
			}
		},
		methods: {
			clickimg(){
				this.imggou = !this.imggou
			},
			out(){
				console.log(123)
			}
		}	
	}
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>

	.otcSell{
		.yd-btn-primary:not(.yd-btn-loading){
			margin: 20px auto;
			text-align: center;
			width: 90%;
			background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
			border: 1px solid  #05535C ;
			color: #FFFFFF ;
			height: 45px;
			line-height: 45px;
			border-radius: 6px;
		}
		ul{
			li{
				overflow: hidden;
				line-height: 46px;
				font-size: 14px;
				position: relative;
				border-bottom: 1px solid #E3E3E3;
				.leftspp{
					float: left;
					display: block;
					padding-left: 20px;
				}
				.rightspp{
					padding-right: 20px;
					display: block;
					float: right;
					overflow: hidden;
					img{
						float: left;
						display: block;
						width: 24px;
						height: 24px;
						margin-left: 6px;
						margin-top: 12px;
					}
					input{
						padding-right: 10px;
						border: none;
						text-align: right;
						font-size: 14px;
					}
					/*select{
						border: none;
						padding-right: 10px;
					}
					em{
						display: block;
						width: 10px;
						height: 10px;
						border-left: 2px solid #979797;
						border-bottom: 2px solid #979797;
						position: absolute;
						top: 50%;
						right:20px;
						transform: translate(0,-50%) rotate(-135deg) ;
					}*/
						
				}
			}
		}
		.agree{
			padding-top: 20px;
			padding-left: 20px;
			overflow: hidden;
			em{
				float: left;
				margin-right: 10px;
				display: inline-block;
				width: 20px;
				height: 20px;
				background: #EFEFEF;
				img{
					width: 18px;
					height: 18px;
				}
			}
		}
		.infor{
			padding-left: 20px;
			p{
				color: #494949;
				font-size: 14px;
				padding-top: 16px;
				padding-bottom: 12px;
			}
			.ovfloo{
				overflow: hidden;
				img{
					float: left;
					width: 20px;
					height: 20px;
					margin-right: 10px;
					
				}
				span{
					display: block;
					float: left;
					font-size: 14px;
					color: #494949;
				}
			}
			.detail{
				overflow: hidden;
				padding-top: 12px;
				padding-bottom: 20px;
				span{
					width: 25%;
					display: block;
					float: left;
				}
			}
		}
		.tips{
				padding-left: 20px;
				padding-right: 20px;
				p{
					color: #494949;
					font-size: 14px;
					padding-top: 16px;
					padding-bottom: 12px;
				}
				span{
					display: block;
					line-height: 20px;
				}
			}
		/*.Popup{
			background-color:#FFFFFF;
			padding-left: 28px;
			padding-right: 20px;
			.titletc{
				padding-top: 34px;
				overflow: hidden;
				
				img{
					float: left;
					margin: 0px 12px 20px 0px;
				}
				span{
					display: block;
					font-size: 14px;padding-top: 10px;
					color: #494949;
					float: left;
				}
			}
			ul{
				padding-bottom: 40px;
				li{
					border-bottom: 1px solid #979797;
					line-height: 52px;
					overflow: hidden;
					.leftssp{
						display: block;
						float: left;
						font-size: 14px;
						color: #494949;
					}
					.rightsp{
						margin-top: 16px;
						display: block;
						float: right;
						width: 38px;
						line-height: 20px;
						background: #EEEEEE;
						color: #B2B2B2;
						text-align: center;
					}
				}
			}
			.copy{
				overflow: hidden;
				text-align: center;
				padding: 20px;
				span{
					float: left;
					display: block;
				}
				img{
					float: left;
					width: 20px;
					height: 20px;
					margin-left: 20px;
				}
			}
			p{
				text-align: center;padding-bottom: 20px;
			}
		}*/
	}
</style>