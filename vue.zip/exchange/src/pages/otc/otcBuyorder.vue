<template>
	<div class="otcBuyorder">
		<div class="top-back" style="    box-shadow: 0px 3px 4px #f1f1f1;position: relative;">
			<router-link to="otcOrder">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">购买订单</span>
			<span class="rightSpan" style="position: absolute;top: 2px;right: 20px;">申诉</span>
		</div>
		<div class="topTitle">
			<ul>
				<li>
					<span class="floleft">订单号</span>
					<span class="floright">19052210306157</span>
				</li>
				<li>
					<span class="floleft">状态</span>
					<span class="floright" style="color: #0D5F66;">已取消</span>
				</li>
			</ul>
		</div>
		<div class="ctcontent">
			<ul>
				<li>
					<span class="leftspp">价格</span>
					<div class="rightspp">
						<span>0.9803CNY</span>
					</div>
				</li>
				<li>
					<span class="leftspp">数量</span>
					<div class="rightspp">
						<span>29，892CNY</span>
					</div>
				</li>
				<li>
					<span class="leftspp">限额</span>
					<div class="rightspp">
						<span>100-30,000CNY</span>
					</div>
				</li>
				<li @click="show2 = true">
					<span class="leftspp">付款方式</span>
					<div class="rightspp">
						<img src="../../../static/img/yhcard.png"/>
					</div>
				</li>
				<li>
					<span class="leftspp">付款备注</span>
					<div class="rightspp">
						<span style="color: #D60A20;">#D60A20</span>
					</div>
				</li>
			</ul>
		</div>
		<div class="Tips">
			<span>提示：转账时请在留言中填写付款备注后的数字，便于卖家确人到账。除付款备注外，留言中请不要填写任何其他内容。</span>
		</div>
		<div class="infor" style="border-bottom: 10px solid  #E3E3E3;">
			<p>买方信息</p>
			<div class="ovfloo">
				<img src="../../../static/img/toux.png"/>
				<span>溜滴滑</span>
			</div>
			<div class="detail">
				<span>交易量 669</span>
				<span>好评 92%</span>
				<span>信任 30</span>
			</div>
		</div>
		<div class="tipstwo" @click="aaaa">
			<p>交易提示</p>
			<span>1、买方需在规定时间内支付订单，并确认付款；</span>
		</div>
		
		<yd-popup v-model="show2" position="center" width="85%">
            <div class="Popup">
            	<div class="titletc">
            		<img src="../../../static/img/yhcard.png"/>
            		<span>银行卡</span>
            	</div>
            	<ul>
            		<li>
            			<span class="leftssp">19052210306157</span>
            			<span class="rightsp">复制</span>
            		</li>
            		<li>
            			<span class="leftssp">兴业银行</span>
            			<span class="rightsp">复制</span>
            		</li>
            		<li>
            			<span class="leftssp">兴业银行股份有限公司惠州分行</span>
            			<span class="rightsp">复制</span>
            		</li>
            		<li>
            			<span class="leftssp">杨伟霞</span>
            			<span class="rightsp">复制</span>
            		</li>
            	</ul>
            </div>
        </yd-popup>
	</div>
</template>

<script>
	export default {
		created(){
//			var time = this.$route.query.editId
			console.log(this.asdh)
//			console.log(this.asdh)
			this.asdh = this.$route.query.editId
		},
		data() {
			return {
				show2: false,
//				timess : this.$route.query.editId,
				asdh: ''
			}
		},
		methods: {
			aaaa(){
				console.log(this.asdh)
			},
		}	
	}
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.otcBuyorder{
		.topTitle{
			border-bottom: 10px solid #F7F7F7;
			padding:2px 20px 16px 20px;
			ul{
				li{
					padding-top: 26px;
					overflow: hidden;
					.floleft{
						float: left;
						display: block;
						font-size: 14px;
						width: 25%;
						color: #494949;
					}
					.floright{
						font-size: 14px;
						float: left;
						display: block;
					}
				}
			}
		}
		.ctcontent{
			ul{
				li{
					overflow: hidden;
					line-height: 46px;
					font-size: 14px;
					position: relative;
					border-bottom: 1px solid #E3E3E3;
					.leftspp{
						float: left;
						display: block;
						padding-left: 20px;
					}
					.rightspp{
						padding-right: 20px;
						display: block;
						float: right;
						overflow: hidden;
						img{
							float: left;
							display: block;
							width: 24px;
							height: 24px;
							margin-left: 6px;
							margin-top: 12px;
						}
						input{
							padding-right: 10px;
							border: none;
							text-align: right;
							font-size: 14px;
						}
					}
				}
			}
		}
		.Tips{
			background: #FCFCFC;
			padding:8px 20px;
			span{
				display: block;
			}
		}
		.infor{
			padding-left: 20px;
			p{
				color: #494949;
				font-size: 14px;
				padding-top: 16px;
				padding-bottom: 12px;
			}
			.ovfloo{
				overflow: hidden;
				img{
					float: left;
					width: 20px;
					height: 20px;
					margin-right: 10px;
					
				}
				span{
					display: block;
					float: left;
					font-size: 14px;
					color: #494949;
				}
			}
			.detail{
				overflow: hidden;
				padding-top: 12px;
				padding-bottom: 20px;
				span{
					width: 25%;
					display: block;
					float: left;
				}
			}
		}
		.tipstwo{
				padding-left: 20px;
				padding-right: 20px;
				p{
					color: #494949;
					font-size: 14px;
					padding-top: 16px;
					padding-bottom: 12px;
				}
				span{
					display: block;
					line-height: 20px;
				}
			}
				.Popup{
			background-color:#FFFFFF;
			padding-left: 28px;
			padding-right: 20px;
			.titletc{
				padding-top: 34px;
				overflow: hidden;
				
				img{
					float: left;
					margin: 0px 12px 20px 0px;
				}
				span{
					display: block;
					font-size: 14px;padding-top: 10px;
					color: #494949;
					float: left;
				}
			}
			ul{
				padding-bottom: 40px;
				li{
					border-bottom: 1px solid #979797;
					line-height: 52px;
					overflow: hidden;
					.leftssp{
						display: block;
						float: left;
						font-size: 14px;
						color: #494949;
					}
					.rightsp{
						margin-top: 16px;
						display: block;
						float: right;
						width: 38px;
						line-height: 20px;
						background: #EEEEEE;
						color: #B2B2B2;
						text-align: center;
					}
				}
			}
		}
		
	}
</style>