<template>
	<div class="otcBuy">
		<div class="top-back">
			<router-link to="otc">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan">购买TC</span>
			<router-link to="userAddcontacts">
				<span class="rigtSpan">申诉</span>
			</router-link>
		</div>
		
	</div>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		methods: {
			
		}	
	}
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
.otcBuy{
	.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			.leftSpan{
				text-align: center;
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 0;
			}
			.rigtSpan{
				position: absolute;
				right: 15px;
				top: 50%;
				transform: translateY(-50%);
			}
			
		}
	
}		
</style>