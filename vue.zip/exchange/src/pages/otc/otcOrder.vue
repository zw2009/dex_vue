<template>
	<div class="otcOrder">
		<div class="top-back" style="    box-shadow: 0px 3px 4px #f1f1f1;">
			<router-link to="otcAccount">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">CT/CNY</span>
		</div>
		<div class="orderotc">
			<yd-tab color="#000" active-color="#05535C">
		        <yd-tab-panel label="进行中">
		        	<div class="hand">
		        		<img src="../../../static/img/kongkong.png"/>
		        		<span>空空如也</span>
		        	</div>
		        </yd-tab-panel>
		        <yd-tab-panel label="已完成">
		        	<div class="hand">
		        		<img src="../../../static/img/kongkong.png"/>
		        		<span>空空如也</span>
		        	</div>
		        </yd-tab-panel>
		        <yd-tab-panel label="已取消">
		        	
		        	<div  v-if='loading'>
			        	<div class="cancel">
			        		<ul>
			        			<!--<router-link to="otcBuyorder">-->
				        			<li v-for="(item,index) in list" :key="index" @click="edit(item)">
						        		<div class="title">
						        			<span class="lleft">购买<span class="black" style="color: #494949;font-size: 14px;padding-left: 10px;">TC/CNY</span></span>
						        			<span class="rright">{{item.time}}</span>
						        		</div>
						        		<div class="orderct">
						        			<div class="leftct">
						        				<span class="ordermum" style="display: block;">订单号&nbsp;&nbsp;&nbsp;19052210306157</span>
						        				<span class="remarks">备注<span style="color: #D60A20;">61819</span></span>
						        			</div>
						        			<div class="rightct">
						        				<span class="price">价格 1 CNY</span>
						        				<span class="number">数量 101 CNT</span>
						        				<span class="money">金额 <span style="color: #287A81;">101 CNY</span></span>
						        			</div>
						        		</div>
				        			</li>
			        			<!--</router-link>-->
			        		</ul>
			        	</div>
		        	</div>
		        	<div v-else><img src="../../../build/logo.png"/></div>
		        	
		        </yd-tab-panel>
		    </yd-tab>
		</div>
		
		<otcTab></otcTab>
	</div>
</template>

<script>
	import otcTab from '@/components/otcTab'
	export default {
		data() {
			return {
				list:[
				   {time:'2019-05-22  10:21:40'},
				   {time:'2018-05-20  10:21:40'},
				],
				loading:true
			}
		},
		methods: {
			edit(item){
				console.log(item)
				this.$router.push({path:'otcBuyorder',query:{editId:item.time,type:this.$route.query.type}})
			}
		},
		components: {
			otcTab
		},
	}
</script>
<style type="text/css">
	.otcOrder .yd-tab-nav-nomal .yd-tab-nav{
		border-bottom: 10px solid #F1F1F1;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.otcOrder{
		.orderotc{
			.hand{
				padding-top: 140px;
				text-align: center;
				img{
					height: 82px;
					width: 64px;
				}
				span{
					display: block;
					font-size: 14px;
					color: #D3D3D3;
					padding-top: 6px;
				}
			}
			.cancel{
				ul{
					li{
						border-bottom: 10px solid #F7F7F7;
						padding-bottom: 20px;
						.title{
							padding:10px 20px;
							overflow: hidden;
							border-bottom: 1px solid #E3E3E3;
							.lleft{
								float: left;
								color: #287A81;
								font-size: 14px;
							}
							.rright{
								float: right;
								color: #8A8A8A;
								font-size: 10px;
							}
						}
						.orderct{
							padding: 0 20px;
							overflow: hidden;
							.leftct{
								float: left;
								.ordermum{
									display: block;
									padding-top: 14px;
									padding-bottom: 10px;
									color: #8A8A8A;
								}
								.remarks{
									color: #8A8A8A;
								}
							}
							.rightct{
								float: right;
								font-size: 14px;
								color: #494949;
								text-align: right;
								.price{
									display: block;
									padding-top: 16px;
									padding-bottom: 10px;
								}
								.number{
									display: block;
									padding-bottom: 10px;
								}
								.money{
									color: #8A8A8A;
								}
							}
						}
					}
				}
				
			}
		}
	}
</style>