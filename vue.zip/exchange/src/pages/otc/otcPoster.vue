<template>
	<div class="otcPoster">
		<div class="top-back" style="box-shadow: 0px 3px 4px #f1f1f1;">
			<router-link to="otcAccount">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">CT/CNY</span>
		</div>
		<div class="orderotc">
			<yd-tab color="#000" active-color="#05535C" :item-click="itemClick" v-model="intTab" :prevent-default="false"> 
		        <yd-tab-panel v-for='(tab,index) in list' :label="tab.title" :key="index" >
		        	<div class="cancel">
		        		<ul>
		        			<li v-for="(item,index) in tab.items" :key="index"> 
				        		<div class="title">
				        			<span class="lleft">TC/CNY购买广告20354</span>
				        			<span class="rright">{{tab.title}}</span>
				        		</div>
				        		<div class="orderct">
				        			<div class="leftct">
				        				<span style="color: #494949; font-size: 14px;padding-top: 12px;padding-bottom: 8px;">单价：{{item.price}}CNY</span>
				        				<span>交易限额：{{item.min_grand_total}}-{{item.max_grand_total}}CNT</span>
				        				<span>创建时间：{{item.created_at}}</span>
				        				<span>广告费率：0.7%</span>
				        			</div>
				        			<div class="rightct">
				        				<div class="img_three">
				        					<img src="../../../static/img/wx.png"/>
				        					<img src="../../../static/img/zfb.png"/>
				        					<img src="../../../static/img/yhcard.png"/>
				        				</div>
				        				<div class="twobutton" v-if="item.status==0">
				        				</div>
				        				<div class="twobutton" v-if="item.status==1">
				        					<button class="onebt" @click="edit(item)">编辑</button>
				        					<button class="twobt" @click="hide(item)">隐藏</button>
				        				</div>
				        				<div class="twobutton" v-if="item.status==2">
				        					<button class="onebt" @click="edit(item)">编辑</button>
				        					<button class="twobt" @click="hide(item)">开放</button>
				        				</div>
				        			</div>
				        		</div>
		        			</li>
		        			<!--<div v-else>
		        				<img src="../../../static/img/kongkong.png"/>
		        			</div>-->
		        		</ul>
		        	</div>
		        </yd-tab-panel>

		    </yd-tab>
		</div>
		
		<otcTab></otcTab>
	</div>
		
		
		
</template>

<script>
	import otcTab from '@/components/otcTab'
	import { removeStore,getStore } from '@/common/storage'
	export default {
		created(){
			this.getList()
		},
		data() {
			return {
				intTab:0 ,
				list:[
					{
						title:'关闭中',
						items:[]
					},
					{
						title:'开放中',
						items:[]
					},
					{
						title:'隐藏中',
						items:[]
					},
				]
			}
		},
		methods: {
			getList(index){
				this.$api.releaseIndex({status:this.intTab}, res => {
					console.log(res)
//					console.log(status,111111111)
					if(res.data.length) {
						this.list[this.intTab].items = res.data
					}
//					if(res.data[0].status==0){
//						res.data[0].status = 1
//					}
//					if(res.data[0].status==1){
//						res.data[0].status= 0
//					}
//					console.log(res.data[0].status,9999)
//					if(res.status==0){
//						this.status = 1
//					}
//					if(res.status==1){
//						this.status = 0
//					}
//					console.log(this.list[1].items[0].status,78787878)
				})
			},
			itemClick(index){
				this.intTab = index
				console.log(this.intTab,123123)
				this.getList(index+1)
			},

//			itemClick(key) {
//				this.intTab = key
//				console.log(key)
//				this.getList(this.intTab)
//			},
//			编辑  点击id跳转至发布广告
			edit(item){
				this.$router.push({path:'/otcPublish',query: {editId:item.id}})
			},
//			隐藏   
			hide(item){
				console.log(item.status,19191911919)
				this.$api.changeStatus({id:item.id,status:this.status}, res => {
					
				})
				
			}
		},
		components: {
			otcTab
		},
	}
</script>
<style type="text/css">
	.otcPoster .yd-tab-nav-nomal .yd-tab-nav{
		border-bottom: 10px solid #F1F1F1;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.otcPoster{
		.orderotc{
			.hand{
				padding-top: 140px;
				text-align: center;
				img{
					height: 82px;
					width: 64px;
				}
				span{
					display: block;
					font-size: 14px;
					color: #D3D3D3;
					padding-top: 6px;
				}
			}
			.cancel{
				padding-bottom: 60px;
				ul{
					li{
						border-bottom: 10px solid #F7F7F7;
						padding-bottom: 20px;
						.title{
							padding:10px 20px;
							overflow: hidden;
							border-bottom: 1px solid #E3E3E3;
							.lleft{
								float: left;
								color: #494949;
								font-size: 14px;
							}
							.rright{
								float: right;
								color: #287A81;
								font-size: 14px;
							}
						}
						.orderct{
							padding: 0 20px;
							overflow: hidden;
							.leftct{
								float: left;
								span{
									display: block;
									line-height: 20px;
									color: #494949;
								}
							}
							.rightct{
								float: right;
								.img_three{
									overflow: hidden;
									img{
										margin: 14px 0px 40px 12px;
										float: right;
										width: 20px;
										height: 20px;
									}
								}
								.twobutton{
									overflow: hidden;
									button{
										display: block;
										float: left;
										width: 60px;
										height: 30px;
										margin-left: 10px;
										color: white;
										border: none;
										border-radius: 4px;
									}
									.onebt{
										background: #909090;
									}
									.twobt{
										background: #22747B;
									}
								}
							}
						}
					}
				}
				
			}
		}	
	}
</style>