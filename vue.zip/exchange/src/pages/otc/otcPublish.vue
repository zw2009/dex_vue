<template>
	<div class="otcPublish">
		<div class="top-back">
			<router-link to="otc">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">发布广告</span>
		</div>
		<div class="warning">
			<svg-icon icon-class="otc_ggjg" class="icon-pay"></svg-icon>
			<span>您的钱包余额不足0.005BTC,广告将无法正常展示</span>
		</div>
		<div class="ggtiele" style="background: #287A81;">
			<span><strong></strong>发布一则交易广告是免费的</span>
			<span><strong></strong>每笔完成的交易需要缴纳0.7%的费用</span>
			<span><strong></strong>钱包中至少需要有0.005BTC,广告才会正常展示</span>
		</div>
		<ul>
			<li>
				<span>广告类型</span>
				<select name="" v-model="adTpye">
					<option v-for="(typeis,index) in listpye" :value='index' :key='index'>{{typeis.ggtype}}</option>
				</select>
				<em></em>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>
			<li>
				<span>选择币种</span>
				<select name="">
					<option value="">TC</option>
					<option value="">CNY</option>
				</select>
				<em></em>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>
			<li>
				<span>所在地</span>
				<select name="">
					<option value="">中国</option>
					<option value="">美国</option>
				</select>
				<em></em>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>
			<li>
				<span>货    币</span>
				<select name="">
					<option value="">CNY</option>
					<option value="">xx广告</option>
				</select>
				<em></em>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>
			<li style="border-bottom: none;">
				<span>交易价格</span>
				<input type="" name="" id="" value="54768.37" v-model="price"/>
				<span class="rightflot">CNY</span>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>
			<input type="checkbox" name="" id="" value="" style="width: 20px;height: 20px;background: red;"/>
			<!--<p>溢价设置(市场参考价格54768.37CNY/BTC</p>-->
			<!--<li>
				<span>溢    价</span>
				<select name="">
					<option value="">CNY</option>
					<option value="">xx广告</option>
				</select>
				<em></em>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>-->
			
			<!--<div class="ctotc">通过滑动溢价比例来调整广告报价，设置负数，报价将低于市场价，设置正数，报价高于市场价。比如当前价格为7000，溢价比例为10%，那么价格为7700。</div>-->
			<div class="backgrond" style="background: #F7F7F7;"><span style="display: block;line-height: 30px;padding-left: 20px;">当前报价大概排在第1位</span></div>
			<!--<li>
				<span>最 低 价</span>
				<input type="" name="" id="" value="" placeholder="广告最低可成交的价格"/>
				<span class="rightflot">CNY</span>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>-->
			<li>
				<span>最 小 量</span>
				<input type="" name="" id="" value="" placeholder="每一笔交易的最小限额" v-model="minimum"/>
				<span class="rightflot">CNY</span>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>
			<li>
				<span>最 大 量</span>
				<input type="" name="" id="" value="" placeholder="每一笔交易的的最大限额" v-model="maximum"/>
				<span class="rightflot">CNY</span>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>
			<li style="border-bottom: none;">
				<span>收款方式</span>
				<select name="" v-model="payment">
					<option value="">请选择收款方式</option>
					<option value="">xx广告</option>
				</select>
				<em></em>
				<svg-icon icon-class="otc_bianzu" class="icon-pays"></svg-icon>
			</li>
			<div class="backgrond" style="background: #F7F7F7;height: 10px;"></div>
			<div class="ctotc">
				<span>请说明有关您交易的相关要求，以便买家下单前先行查看，</span>
				<span>例如：</span>
				<span>1.请在有效期内付款并点击「标记已付款完成」按钮，我才会释放数字资产给您；</span>
				<span>2.如果您无法在有效期付款，请及时取消订单；</span>
				<span>3.下单后，数字资产将托管锁定，请放心交易。</span>
			</div>
			<div class="backgrond" style="background: #F7F7F7;height: 10px;"></div>
			<li style="border-bottom: none;line-height: 56px;">
				<span style="width: 60%;border-right: none;">仅限受信任的交易者</span>
				<span class="borderc" @click="clickimg">
					<img v-show="imggou" src="../../../static/img/gougou.png"/>
				</span>
			</li>
			<div class="backgrond" style="background: #F7F7F7;"><span style="display: block;line-height: 30px;padding-left: 20px;">启用后，仅限于自己信任的用户与本广告交易</span></div>
			<li style="border-bottom: none;line-height: 56px;">
				<span style="width: 60%;border-right: none;">仅限实名认证的交易者</span>
				<span class="borderc"  @click="clickimgT">
					<img v-show="imggouT" src="../../../static/img/gougou.png"/>
				</span>
			</li>
		    <div class="backgrond" style="background: #F7F7F7;"><span style="display: block;line-height: 30px;padding-left: 20px;">启用后，仅限于自己信任的用户与本广告交易</span></div>
			<!--<li style="border-bottom: none;line-height: 50px;">
				<span style="width: 40%; border-right: none;">高级设置  （选填）</span>
				<em style="right: 5px;"></em>
			</li>-->
			
			<li style="border-bottom: none;padding-left: 0;">
				<select name="" style="padding-left: 0;" v-model="stateSet">
					<option value="">开放中</option>
					<option value="">关闭中</option>
					<option value="">隐藏中</option>
				</select>
				<em></em>
			</li>
			
		</ul>
		<button @click="release">发布</button>
	</div>
</template>

<script>
	export default {
		created() {
			const notice_id = this.$route.query.editId
			
			console.log(notice_id,123123123)
		},
		data() {
			return {
				adTpye:0,
				adTpyes:'',      //    广告类型
				price:'',       //    交易价格
				minimum:'',		//    最小成交
				maximum:'',		//    最大成交
				payment:'',     //    收款方式
				stateSet:'',    //    状态设置
				notice_id:this.$route.query.editId ,
				imggou:false,
				imggouT:true,
				listpye:[{ggtype:"购买广告"},{ggtype:"出售广告"}]
			}
		},
		methods: {
			clickimg(){
				this.imggou = !this.imggou
			},
			clickimgT(){
				this.imggouT = !this.imggouT
			},
			release(){
				if(!this.minimum){
                    this.$dialog.toast({mes:'请输入最小量'})
                    return false;
                }
				if(!this.maximum){
                    this.$dialog.toast({mes:'请输入最大量'})
                    return false;
                }
				
				this.$dialog.confirm({
					title:'提示',
					mes:'您确定发布吗？',
					opts:[{
						txt:'取消',
						color:false,
					},
					{
						txt:'确定',
						color:true,
						callback:() => {
							this.$api.release({
								type:1,
								min_grand_total:this.minimum,
								max_grand_total:this.maximum,
								id:this.notice_id,
								trade_with_verified_user:1,
								trade_with_trust_user:1,
								status:1
							},res =>{
								console.log(res)	
								if(res.status) {
									this.$dialog.toast({
										mes: res.msg,
										timeout: 1000,
										callback: () => {
		                                    this.$router.replace({path:'/otcPoster'})
										}
									})
//									this.$router.replace('/')
								}
							})
						}
					}
					
					]
				})
//				this.$api.release({
//					type:1,
//					min_grand_total:this.minimum,
//					max_grand_total:this.maximum,
//					id:this.notice_id,
//					trade_with_verified_user:1,
//					trade_with_trust_user:1,
//					status:1
//				},res => {
//					console.log(res)
//				}
//				)
			}
			
		}	
	}
</script>

<style scoped src="@/style/style.css"></style>
<style scoped type="text/css">
	.otcPublish .yd-confirm-hd{
		    text-align: center!important;
	    }

</style>
<style lang="less" scoped>

	.otcPublish{
		.warning{
			text-align: center;line-height: 40px;background: #FFDCDC;color: #494949;font-size: 14px;
		}
		.ggtiele{
			padding: 16px 20px;			
			span{
				line-height: 20px;
				display: block;
				color: white;
				strong{
					display: inline-block;
					width: 5px;
					height: 5px;
					background: white;
					border-radius: 50%;
					margin-right: 5px;
				}
			}
		}
		button{
			margin: 30px auto;
				outline: none;
				border: none;
				color: white;
				font-size: 14px;
				display: block;
				width: 120px;
				line-height: 40px;
				background: rgb(34,116,123);
				border-radius: 4px;
			}
		ul{
			background: #fff;
			li{
				margin-left: 20px;
				margin-right: 20px;
				font-size: 14px;
				border-bottom: 1px solid #979797;
				overflow: hidden;
				position: relative;
				span{
					width: 22%;
					margin-top: 17px;
					display: block;
					float: left;
					border-right: 1px solid #979797;
				}
				.icon-pays{
					margin-top: 16px;
					width: 22px;
					height: 22px;
					float: right;
				}
				select{
					width: 60%;
					padding-left: 10px;
					border: none;
					line-height: 54px;
				}
				em{
					display: block;
					width: .18rem;
					height: .18rem;
					border-left: .02rem solid #979797;
					border-bottom: .02rem solid #979797;
					position: absolute;
					top: 50%;
					right:30px;
					transform: translate(0,-50%) rotate(-135deg) ;
				}
				input{
					display: block;
					float: left;
					width: 45%;
					border: none;
					line-height: 54px;
					padding-left: 10px;
				}
				::-webkit-input-placeholder {
					color: #DCDCDC;
				}
				.borderc{
					background: #FFFFFF;
					width: 20px;
					height: 20px;
					display: inline-block;
					border: 1px solid #979797;
					float: right;
					margin-top: 35px;
					img{
						width: 18px;
						height: 18px;
						margin-bottom: 20px;
					}
				}
				.rightflot{
					text-align: right;
					border-right: none;
					display: block;
					position: absolute;
					top: 2px;
					right: 30px;
				}
			}
			p{
				padding-left: 20px;
				background: #F7F7F7;
				line-height: 40px;
			}
			.ctotc{
				width: 90%;
				padding-left: 20px;
				padding-top: 10px;padding-bottom: 10px;
				span{
					display: block;
					line-height: 20px;
				}
				
			}
		}
	}

</style>