<template>
	<div class="otcSell">
		<div class="top-back">
			<router-link to="otc">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">出售TC</span>
		</div>
		<ul>
			<li>
				<span class="leftspp">价格</span>
				<div class="rightspp">
					<span>0.9803CNY</span>
				</div>
			</li>
			<li>
				<span class="leftspp">数量</span>
				<div class="rightspp">
					<span>29，892CNY</span>
				</div>
			</li>
			<li>
				<span class="leftspp">限额</span>
				<div class="rightspp">
					<span>100-30,000CNY</span>
				</div>
			</li>
			<li>
				<span class="leftspp">付款方式</span>
				<div class="rightspp">
					<img src="../../../static/img/wx.png"/>
					<img src="../../../static/img/zfb.png"/>
					<img src="../../../static/img/yhcard.png"/>
				</div>
			</li>
			<li style="border-bottom: 10px solid  #E3E3E3;">
				<span class="leftspp">交货期限</span>
				<div class="rightspp">
					<span>120分钟</span>
				</div>
			</li>
			<li>
				<span class="leftspp">出售数量</span>
				<div class="rightspp">
					<input type="" name="" id="" value="0" />
					CNY
				</div>
			</li>
			<li>
				<span class="leftspp">出售金额</span>
				<div class="rightspp">
					<input type="" name="" id="" value="0" />
					CNY
				</div>
			</li>
			<li>
				<span class="leftspp">收款方式</span>
				<div class="rightspp">
					<select name="">
						<option value="">支付宝</option>
						<option value="">微信</option>
						<option value="">银行卡</option>
					</select>
					<em></em>
				</div>
			</li>
		</ul>
		<div class="agree">
			<em @click="clickimg">
				<img v-show="imggou" src="../../../static/img/gougou.png"/>
			</em>
			<span>同意 <span style="color:#16686F;">OTC用户交易协议</span></span>
		</div>
		<div class="confirm"  style="border-bottom: 10px solid  #E3E3E3;">
			<yd-button size="large" type="primary" @click.native="out" shape="angle">确认出售</yd-button>
		</div>
		<div class="infor">
			<p>买方信息</p>
			<div class="ovfloo">
				<img src="../../../static/img/toux.png"/>
				<span>溜滴滑</span>
			</div>
			<div class="detail">
				<span>交易量 669</span>
				<span>好评 92%</span>
				<span>信任 30</span>
			</div>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				imggou:false
			}
		},
		methods: {
			clickimg(){
				this.imggou = !this.imggou
			},
			out(){
				console.log(123)
			}
		}	
	}
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>

	.otcSell{
		.yd-btn-primary:not(.yd-btn-loading){
			margin: 20px auto;
			text-align: center;
			width: 90%;
			background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
			border: 1px solid  #05535C ;
			color: #FFFFFF ;
			height: 45px;
			line-height: 45px;
			border-radius: 6px;
		}
		ul{
			li{
				overflow: hidden;
				line-height: 46px;
				font-size: 14px;
				position: relative;
				border-bottom: 1px solid #E3E3E3;
				.leftspp{
					float: left;
					display: block;
					padding-left: 20px;
				}
				.rightspp{
					padding-right: 20px;
					display: block;
					float: right;
					overflow: hidden;
					img{
						float: left;
						display: block;
						width: 24px;
						height: 24px;
						margin-left: 6px;
						margin-top: 12px;
					}
					input{
						border: none;
						padding-right: 10px;
						text-align: right;
						font-size: 14px;
					}
					select{
						border: none;
						padding-right: 10px;
					}
					em{
						display: block;
						width: 10px;
						height: 10px;
						border-left: 2px solid #979797;
						border-bottom: 2px solid #979797;
						position: absolute;
						top: 50%;
						right:20px;
						transform: translate(0,-50%) rotate(-135deg) ;
					}
						
				}
			}
		}
		.agree{
			padding-top: 20px;
			padding-left: 20px;
			overflow: hidden;
			cursor: pointer;
			em{
				float: left;
				margin-right: 10px;
				display: inline-block;
				width: 18px;
				height: 18px;
				background: #EFEFEF;
				img{
					width: 18px;
					height: 18px;
				}
			}
		}
		.infor{
			padding-left: 20px;
			p{
				color: #494949;
				font-size: 14px;
				padding-top: 16px;
				padding-bottom: 12px;
			}
			.ovfloo{
				overflow: hidden;
				img{
					float: left;
					width: 20px;
					height: 20px;
					margin-right: 10px;
					
				}
				span{
					display: block;
					float: left;
					font-size: 14px;
					color: #494949;
				}
			}
			.detail{
				overflow: hidden;
				padding-top: 12px;
				padding-bottom: 20px;
				span{
					width: 25%;
					display: block;
					float: left;
				}
			}
		}
	}
</style>