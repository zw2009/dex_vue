<template>
	<div class="otcSellposter">
		
	</div>
</template>

<script>
	import otcTab from '@/components/otcTab'
	export default {
		data() {
			return {
				
			}
		},
		methods: {
		},
	}
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
</style>