<template>
	<div class="otcTrust">
		<div class="top-back" style="    box-shadow: 0px 3px 4px #f1f1f1;">
			<router-link to="otc">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">信任管理</span>
		</div>
		<div class="trustCt">
			<yd-tab color="#000" active-color="#05535C">
		        <yd-tab-panel label="我信任的人">
		        	<div class="xinren">
		        		<ul>
		        			<li v-for="item in list">
		        				<img src="../../../static/img/toux.png"/>
		        				<div class="midCt">
		        					<span style="color: #555555;font-size: 16px;padding-bottom: 5px;">{{item.name}}</span>
		        					<span class="rightSp">交易{{item.deal}} | 好评率{{item.praise}} | 信任{{item.trust}}</span>
		        				</div>
		        				<span class="rrrght">跟他交易过1次</span>
		        			</li>
		        		</ul>
		        	</div>
		        </yd-tab-panel>
		        <yd-tab-panel label="信任我的人">
		        	
		        </yd-tab-panel>
		        <yd-tab-panel label="我屏蔽的人">
		        	
		        </yd-tab-panel>
		    </yd-tab>
		</div>
		
	</div>
</template>

<script>
	export default {
		data() {
			return {
				list : [
					{name:'Sunny609',deal:1435,praise:'100%',trust:142,},
					{name:'Sunny609',deal:1435,praise:'100%',trust:142,},
				]
			}
		},
		methods: {
		}	
	}
</script>
<style type="text/css">
	.trustCt .yd-tab-nav-nomal .yd-tab-nav{
		border-bottom: 10px solid #F7F7F7;
	}
		
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.otcTrust{
		.trustCt{
			.xinren{
				ul{
					padding-left:20px;
					padding-right: 20px;
					li{
						overflow: hidden;
						padding-top: 20px;
						border-bottom: 1px solid rgba(221,221,221,0.50);
						img{
							width: 46px;
							height: 46px;
							float: left;
							margin: 0 15px 20px 0;
						}
						.midCt{
							float: left;
							span{
								display: block;
								line-height: 20px;
								color: #7D899C;
								font-size: 12px;
							}
						}
						.rrrght{
							float: right;
							display: block;
							color: #287A81;
							font-size: 12px;
						}
					}
				}
			}
		}
		
	}
	
</style>