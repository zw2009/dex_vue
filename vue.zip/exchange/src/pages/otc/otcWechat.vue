<template>
	<div class="Alipay">
		<div class="top-back" style="    box-shadow: 0px 3px 4px #f1f1f1;">
			<router-link to="otcAccount">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">微信</span>
		</div>
		<ul>
			<li>
				<span>微信账户</span>
				<input type="" name="" id="" value="154546461" />
			</li>
			<li>
				<span>姓名</span>
				<input type="" name="" id="" value="猜猜猜" />
			</li>
			<li>
				<span>收款二维码</span>
				<div class="borderound">
					<div class="addimg">
						<img src="../../../static/img/otcadd.png"/>
						<span>添加收款二维码</span>
					</div>
				</div>
			</li>
		</ul>
		<div class="confirm" >
			<yd-button size="large" type="primary" @click.native="out" shape="angle">保存</yd-button>
		</div>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
		}	
	}
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.Alipay{
		.yd-btn-primary:not(.yd-btn-loading){
			margin: 20px auto;
			text-align: center;
			width: 90%;
			background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
			border: 1px solid  #05535C ;
			color: #FFFFFF ;
			height: 45px;
			line-height: 45px;
			border-radius: 6px;
		}
		ul{
			padding-left:22px;
			padding-right: 22px;
			li{
				border-bottom: 1px solid #979797;
				span{
					display:block;
					padding-top: 14px;
					padding-bottom: 8px;
					color: #868686;
				}
				input{
					display: block;
					color: #494949;
					border: none;
					font-size: 14px;
					margin-bottom: 10px;
				}
				.borderound{
					width: 100%;
					height: 272px;
					border: 1px solid #F4F4F4;
					.addimg{
						padding-top: 35%;
						width: 40%;
						margin: 0 auto;
						overflow: hidden;
						img{
							width: 24px;
							height: 24px;
							float: left;
							margin-top: 10px;
						}
						span{
							color: #287A81;
							display: block;
							float: left;
						}
					}
				}
			}
		}
	}
	
</style>