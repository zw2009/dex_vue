<template>
	<div class="register">
		<!--<yd-navbar color="#fff">
			<router-link to="/login" slot="left">
				<yd-navbar-back-icon color="#000"></yd-navbar-back-icon>
			</router-link>
		</yd-navbar>-->
		<div class="topNav" style="height: 50px;background: #FFF;">
			<router-link to="/login">
				<img src="../../../static/img/top_return.png"/>
			</router-link>
		</div>
		<span style="font-size: 20px;color: #434A59;padding:20px 0px 40px 15px;">注册</span>
		<div class="contentReg">
		<yd-tab v-model="tab1">
			<yd-tab-panel label="手机">
				<div class="phone">
					<ul>
						<!--<li>
							<span class="topSpan">国家/地区</span>
							<select id="sss" v-model='issue'>
			                    <option v-for="(item,index) in issues" :value='index' :key='index'>{{item}}</option>
			                </select>
						</li>-->
						<li>
							<em></em>
						<!-- 	<select id="sss" v-model='issue'>
                    <option v-for="(item,index) in issues" :value='index' :key='index'>+{{index}}</option>
              </select> -->
              <input  class="code"  v-model="issue" @click="selectCode" readonly="readonly">
                <em></em>
							<yd-cell-item>
								<yd-input  slot="right" v-model="phone"  placeholder="手机号"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="code"  placeholder="验证码"></yd-input>
				        	  	<yd-sendcode class="sendsms" slot="right" v-model="start" init-str="发送" @click.native="sendCode" type="warning"></yd-sendcode>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="phonePsone" placeholder="密码"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="phonePstwo" placeholder="再次请输入密码"></yd-input>
							</yd-cell-item>
						</li>
					</ul>
				</div>
			</yd-tab-panel>
			<yd-tab-panel label="邮箱">
				<div class="phone">
					<ul>
						<li>
							<!--<span class="topSpan">邮箱</span>-->
							<yd-cell-item>
								<yd-input slot="right" v-model="email" ref="input10" placeholder="邮箱"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<!--<span class="topSpan">验证码</span>-->
							<yd-cell-item>
								<yd-input slot="right" v-model="emailCode" ref="input10" placeholder="验证码"></yd-input>
								<yd-sendcode slot="right" v-model="start" @click.native="sendCode" init-str="发送" type="primary"></yd-sendcode>
							</yd-cell-item>
						</li>
						<li>
							<!--<span class="topSpan">密码</span>-->
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="emailone" placeholder="请输入密码"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<!--<span class="topSpan">确认密码</span>-->
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="emailtwo" placeholder="再次请输入密码"></yd-input>
							</yd-cell-item>
						</li>
					</ul>
				</div>
			</yd-tab-panel>
			<!--<yd-tab-panel label="密钥">
				<div class="phone">
					<ul>
						<li>
							<em></em>
							<select id="sss" v-model='issue'>
			                    <option v-for="(item,index) in issues" :value='index' :key='index'>+{{index}}</option>
			                </select>
			                <em></em>
							<yd-cell-item>
								<yd-input  slot="right" v-model="phone"  placeholder="手机号"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="code" ref="input10" placeholder="验证码"></yd-input>
								<yd-sendcode slot="right" v-model="start" @click.native="sendCode" init-str="发送" type="primary"></yd-sendcode>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="miyao" ref="input10" placeholder="私钥"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="miyaoone" placeholder="请输入密码"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="miyaotwo" placeholder="再次请输入密码"></yd-input>
							</yd-cell-item>
						</li>
					</ul>

				</div>
			</yd-tab-panel>-->
		</yd-tab>
		</div>
		<div class="buttonds" @click="confirm">
			<button>确定</button>
		</div>
	</div>
</template>

<script>
	export default {
		created(){
	        // this.getinfor()
          if(this.$route.query.issue){
            this.issue = this.$route.query.issue
          }
	    },
		data() {
			return {
				issue:'+86',
				address:'',		 //国家地区
				phone:'',        //手机号
				phoneCode:'',    //手机
				phonePsone:'',   //手机密码
				phonePstwo:'',   //手机在次密码
				email:'',		 //邮箱
				emailCode:'',	 //邮箱验证码
				emailone:'',     //邮箱密码
				emailtwo:'',	 //邮箱在次密码
//				miyaoone:'',	 //密钥密码
//				miyaotwo:'',     //密钥再次密码
//				miyao:'',	//密钥
				issues:[],
				tab1: 0,
				input10:'',
				code: '',
				start: false,
				input2: '',
//				operation:'reg'
			}
		},
		methods: {
			// getinfor(){
   //              this.$api.indexs({}, res =>{
   //              	this.issues = res.data
   //              })
   //          },
    selectCode(){
      this.$router.push('/countryCode')
    },
			sendCode(){
				let reg=/^1[3456789]\d{9}$/;
                if(!this.phone){
                    this.$dialog.toast({mes:'请输入手机号',timeout: 1000})
                    return;
                }
                if(!reg.test(this.phone)){
                	this.$dialog.toast({mes:'请输入正确手机号',timeout: 1000})
                	return;
                }
                this.$dialog.loading.open('发送中...');

                setTimeout(() => {
					this.$dialog.loading.close();
                    this.$api.checkSms({
                    	account:this.phone,
                    	operation:'reg',
                    	type:1,
                    	country:this.issue,
                    	code:this.code,
                    	}, res =>{

                                if(!res.status){
                                    this.$dialog.toast({mes:res.msg, timeout:1000})
                                    this.phone =""
                                }else{
                                    this.$dialog.toast({mes:'已发送',icon: 'success', timeout: 1500})
                                    this.start = true;
                                }
                            })
				}, 1000);
			},
			confirm(){
				let reg=/^1[3456789]\d{9}$/;
                if(!this.phone){
                    this.$dialog.toast({mes:'请输入手机号',timeout: 1000})
                    return false;
                }
                if(!reg.test(this.phone)){
                	this.$dialog.toast({mes:'请输入正确手机号',timeout: 1000})
                	return false;
                }
                if(!this.code){
                    this.$dialog.toast({mes:'请输入验证码'})
                    return false;
                }
				if(!this.phonePsone){
					 this.$dialog.toast({mes:'请输入密码',timeout: 1000})
					 return false;
				}
				if(!/^[a-zA-Z0-9]{8,16}$/.test(this.phonePsone)){
					this.$dialog.toast({mes:'密码长度为8到16位且不能有字符',timeout: 1000})
					this.phonePsone =""
            	    return false;
				}
				if(!this.phonePstwo){
					 this.$dialog.toast({mes:'请再次输入密码',timeout: 1000})
					 this.phonePstwo =""
            		 return false;
				}
				 if(this.phonePsone != this.phonePstwo){
                    this.$dialog.toast({mes:'密码与确认密码不一致',timeout:1500})
                    this.phonePsone =""
                    this.phonePstwo =""
                    return false;
                }
				this.$api.register({
					account:this.phone,
					password:this.phonePsone,
					code:this.code,
					twopassword:this.phonePstwo,
					operation:'reg',
					country:this.issue,
					type:1,
				}, res =>{
	               if(res.status){
                        this.$dialog.toast({mes:res.msg,callback:()=>{
                        	this.$router.replace('/login')
                        }})
                    }else{
                        this.$dialog.toast({mes:res.msg})
                    }
				})

			}

		}
	}
</script>

<style type="text/css">
	.contentReg .yd-navbar:after{
		display: none!important;
	}
	.contentReg .yd-tab-nav-nomal .yd-tab-nav .yd-tab-nav-item{
		width: 15%!important;
		flex: inherit
	}
	.contentReg .yd-tab-nav:after{
		display: none!important;
	}

	.contentReg .yd-tab-panel-item.yd-tab-active{
		padding-top: 30px!important;
	}


	.contentReg .yd-btn-warning:not(.yd-btn-loading){
		background: #FFFFFF!important;
		color: #05535C;
	}
	.contentReg .yd-input-password:after {
		color: #05535C;
	}

	.contentReg .yd-btn-primary:not(.yd-btn-loading):active {
		background: #FFFFFF;
	}

	.contentReg .yd-btn-primary:not(.yd-btn-loading) {
		width: 100px;
		text-align: right;
		font-size: 14px;
		color: #05535C;
		background: #FFFFFF!important;
	}

	.contentReg .yd-cell-item {
		padding-left: 15px !important;
		padding-top: 0!important;
		margin-top: 0!important;
	}

	.contentReg .yd-tab-nav-item {
		color: #05535C !important;
	}

	.contentReg .yd-tab-active {
		color: #05535C !important;
	}

	.contentReg .yd-tab-active:before {
		width: 18% !important;
		margin-left: -8% !important;
	}

	.contentReg .yd-btn-disabled{
		background-color:white!important;
		color: #05535C!important;
	}
</style>
<style lang="less" scoped>
	.register {
		background: #FFFFFF;
		padding-bottom: 200px;
		.topNav{
			position: relative;
			img{
				position: absolute;
				margin-top: 16px;
				margin-left: 15px;
				width: 9px;
				height: 17px;
			}
		}
		.phone {
			background: #FFFFFF;
			li {
				height: 50px;
				border-bottom: 1px solid #ECECEC;
				line-height: 50px;
				position: relative;
				em{
					display: block;
					width: .18rem;
					height: .18rem;
					border-left: .02rem solid #000000;
					border-bottom: .02rem solid #000000;
					position: absolute;
					top: 50%;
					left:1.3rem;
					transform: translate(0,-50%) rotate(315deg) ;

				}
				.code{
		            width: 15%;
		            display: block;
		            float: left;
		            margin-left: 15px;
		            line-height: 50px;
		            border: none;
		        }
			}
		}
		.buttonds {
			padding: 30px 15px 20px 15px;
			button {
				width: 100%;
				margin: 0 auto;
				border: none;
				color: white;
				font-size: 14px;
				line-height: 35px;
				background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
			}
		}
	}
</style>
