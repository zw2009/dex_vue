<template>
  <div class="wrap">
		<div class="top-back" style="    box-shadow: 0px 3px 4px #f1f1f1;">
			<router-link to="register">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan" style="text-align: center;padding-left: 0;">国家地区</span>
		</div>
    <countryCode :data="codeList"  @choose="onChoose" v-if="codeList.length"></countryCode>
  </div>
</template>
<script>
  import countryCode from "@/components/countryCode"
  import codeList from '../../../static/js/country.json'
  export default{
    data(){
      return{
        codeList
      }
    },
    components: {
      countryCode
    },
    methods:{
      onChoose(item) {
        console.log(item,123)
//      this.$router.push({path:'/register',query:{issue:item.number}})
        this.$router.push({path:'/login',query:{issue:item.number}})
      }
    }
  }
</script>
<style lang="less">
* {
  margin: 0;
  padding: 0;
}
.wrap {
  position: fixed;
  top: 0;
  bottom: 0;
  width: 100%;
}
</style>
<style scoped src="@/style/style.css"></style>