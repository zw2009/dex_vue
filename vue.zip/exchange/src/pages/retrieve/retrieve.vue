<template>
	<div class="retrieve">
		<div class="topNav" style="height: 50px;background: #FFF;">
			<router-link to="/login">
				<img src="../../../static/img/top_return.png"/>
			</router-link>	
		</div>
		<span style="font-size: 20px;color: #434A59;padding:20px 0px 40px 15px;">重置密码</span>
		<div class="contentReve">
		
		<yd-tab v-model="tab1">
			<yd-tab-panel label="手机">
				<div class="phone">
					<ul>
						<li>
							<em></em>
							<select id="sss" v-model='issue'>
			                    <option v-for="(item,index) in issues" :value='index' :key='index'>+{{index}}</option>
			                </select>
			                <em></em>
							<yd-cell-item>
								<yd-input  slot="right" v-model="phone"  placeholder="手机号"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="code" ref="input10" placeholder="验证码"></yd-input>
								<yd-sendcode slot="right" v-model="start" @click.native="sendCode" init-str="发送" type="primary"></yd-sendcode>
							</yd-cell-item>
						</li>
						<!--<li @click="scan">
							<yd-cell-item>
								<yd-input slot="right" v-model="input10" ref="input10" placeholder="私钥"></yd-input>
							</yd-cell-item>
							<img src="../../../static/img/contact_scanning.png"/>
						</li>-->
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="phoneone" placeholder="请输入密码"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="phonetwo" placeholder="再次请输入密码"></yd-input>
							</yd-cell-item>
						</li>
					</ul>
				</div>
			</yd-tab-panel>
			<yd-tab-panel label="邮箱">
				<div class="phone">
					<ul>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="input10" ref="input10" placeholder="邮箱"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="code" placeholder="验证码"></yd-input>
								<yd-sendcode slot="right" v-model="start" @click.native="sendCode" init-str="发送" type="primary"></yd-sendcode>
							</yd-cell-item>
						</li>
						<!--<li>
							<yd-cell-item>
								<yd-input slot="right" v-model="input10" ref="input10" placeholder="私钥"></yd-input>
							</yd-cell-item>
							<img src="../../../static/img/contact_scanning.png"/>
						</li>-->
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="emailone" placeholder="请输入密码"></yd-input>
							</yd-cell-item>
						</li>
						<li>
							<yd-cell-item>
								<yd-input slot="right" type="password" v-model="emailtwo" placeholder="再次请输入密码"></yd-input>
							</yd-cell-item>
						</li>
					</ul>
				</div>
			</yd-tab-panel>
		</yd-tab>	
		</div>
		<div class="buttonds" @click="confirm">
			<button>确认</button>
		</div>
	</div>
</template>

<script>
	export default {
		created(){
	        this.getinfor()
	    },
		data() {
			return {
				phone:'',        //手机号
				phoneone:'',     //手机密码
				phonetwo:'',     //手机在次密码
				emailone:'',     //邮箱密码
				emailtwo:'',	 //邮箱在次密码
//				miyaoone:'',	 //密钥密码
//				miyaotwo:'',     //密钥再次密码
//				miyao:'',	     //密钥
				tab1: 0,
				input10:'',
				code: '',
				start: false,
				input2: '',
				issue:86,
				issues:[],
			}
		},
		methods: {
			sendCode() {
				let reg=/^1[3456789]\d{9}$/;
				let phoneStandard = /^1[345678]{1}\d{9}$/gi;
                if(!this.phone){
                    this.$dialog.toast({mes:'请输入手机号',timeout: 1000})
                    return;
                }
                if(!reg.test(this.phone)){
                	this.$dialog.toast({mes:'请输入正确手机号',timeout: 1000})
                	return;
                }
                this.$dialog.loading.open('发送中...');
                setTimeout(() => {
					this.$dialog.loading.close();
                    this.$api.checkSms({
                    	account:this.phone, 
                    	operation:'veri',
                    	type:1,
                    	country:this.issue,
                    	code:this.code,
                    	}, res =>{
                                console.log(res)
                                if(!res.status){
                                    this.$dialog.toast({mes:res.msg, timeout:1000})
//                                  this.phone =""
                                }else{
                                    this.$dialog.toast({mes:'已发送',icon: 'success', timeout: 1500})
                                    this.start = true;
                                }
                            })
				}, 1000);
			},
			getinfor(){
                this.$api.indexs({}, res =>{
                	this.issues = res.data
					console.log(res.data)
                })
            },
            confirm(){
            	let reg=/^1[3456789]\d{9}$/;
				let phoneStandard = /^1[345678]{1}\d{9}$/gi;
                if(!this.phone){
                    this.$dialog.toast({mes:'请输入手机号',timeout: 1000})
                    return;
                }
                if(!reg.test(this.phone)){
                	this.$dialog.toast({mes:'请输入正确手机号',timeout: 1000})
                }
                if(!this.code){
                    this.$dialog.toast({mes:'请输入验证码'})
                    return false;
                }
				if(!this.phoneone){
					 this.$dialog.toast({mes:'请输入密码',timeout: 1000})
				}
				if(!this.phonetwo){
					 this.$dialog.toast({mes:'请再次输入密码',timeout: 1000})
				}
				if(this.phoneone != this.phonetwo){
                    this.$dialog.toast({mes:'密码与确认密码不一致',timeout:1500})
                }
				this.$api.resetpassword({
					account:this.phone,
					password:this.phoneone,
					twopassword:this.phonetwo,
					operation:'veri',
					code:this.code,
					country:this.issue,
					type:1,
				}, res =>{
	               if(res.status){
                        this.$dialog.toast({mes:res.msg,callback:()=>{
                        	this.$router.replace('/login')
                        }})
                    }else{
                        this.$dialog.toast({mes:res.msg})
                    }
				})
            },
//          scan(){
//                  var that = this
//                  cordova.plugins.barcodeScanner.scan(
//                          function (result) {
//                          	alert(result.text,111)
//                          },
//                          function (error) {
//                            alert(error,222)
//                          },
//                          {
//                              preferFrontCamera: false, // 设置前置摄像头
//                              showFlipCameraButton: true, // 显示旋转摄像头按钮
//                              showTorchButton: true, // 显示手电筒
//                              torchOn: false, // 默认开启手电筒
//                              saveHistory: false, // Android, save scan history (default false)
//                              prompt: "将二维码放入框内, 可自动扫描",
//                              resultDisplayDuration: 500, // 多久开始识别
//                              formats: "QR_CODE", // default: all but PDF_417 and RSS_EXPANDED
//                              orientation: "portrait", // 竖屏portrait，横屏landscape
//                              disableAnimations: false, // 禁止动画
//                              disableSuccessBeep: false // 禁用成功蜂鸣声
//                          }
//                      )
//          },
		}
	}
</script>

<!--<style scoped src="@/style/style.css"></style>-->
<style type="text/css">
	.contentReve .yd-navbar:after{
		display: none!important;
	}
	.contentReve .yd-tab-nav-nomal .yd-tab-nav .yd-tab-nav-item{
		width: 15%!important;
		flex: inherit
	}
	.contentReve .yd-tab-nav:after{
		display: none!important;
	}
	
	.contentReve .yd-tab-panel-item.yd-tab-active{
		padding-top: 30px!important;
	}
	
	.contentReve .yd-cell-item:not(:last-child):after{
		display: none!important;
	}


	.contentReve .yd-input-password:after {
		color: #05535C;
	}
	
	.contentReve .yd-btn-primary:not(.yd-btn-loading):active {
		background: #FFFFFF!important;
	}
	
	.contentReve .yd-btn-primary:not(.yd-btn-loading) {
		width: 100px;
		text-align: right;
		font-size: 14px;
		color: #05535C;
		background: #FFFFFF;
	}
	
	.contentReve .yd-cell-item {
		padding-left: 15px !important;
	}
	
	.contentReve .yd-tab-nav-item {
		color: #05535C !important;
	}
	
	.contentReve .yd-tab-active {
		color: #05535C !important;
	}
	
	.contentReve .yd-tab-active:before {
		width: 30% !important;
		margin-left: -15% !important;
	}
	.contentReve .yd-btn-disabled{
		background-color:white!important;
		color: #05535C!important;
	}
</style>
<style lang="less" scoped>
	.retrieve {
		background: #FFFFFF;
		padding-bottom: 200px;
		.topNav{
			position: relative;
			img{
				position: absolute;
				margin-top: 16px;
				margin-left: 15px;
				width: 9px;
				height: 17px;
			}
		}
		.phone {
			background: #FFFFFF;
			li {
				height: 50px;
				border-bottom: 1px solid #ECECEC;
				line-height: 50px;
				position: relative;
				img{
					width: 17px;
					height: 16px;
					position: absolute;
					top: 50%;
					right: 15px;
					transform: translateY(-50%);
				}
				em{
					display: block;
					width: .18rem;
					height: .18rem;
					border-left: .02rem solid #000000;
					border-bottom: .02rem solid #000000;
					position: absolute;
					top: 46%;
					left:1.3rem;
					transform: translate(0,-50%) rotate(315deg) ;
					
				}
				select{
		            width: 15%;
		            display: block;
		            float: left;
		            margin-left: 15px;
		            line-height: 50px;
		            border: none;
		        }
			}
		}
		.buttonds {
			padding: 30px 15px 20px 15px;
			button {
				width: 100%;
				margin: 0 auto;
				border: none;
				color: white;
				font-size: 14px;
				line-height: 35px;
				background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
			}
		}
	}
</style>