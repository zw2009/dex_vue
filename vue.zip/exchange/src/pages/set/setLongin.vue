<template>
	<div class="setassets">
		<div class="top-back">
			<router-link to="userSecurity">
				<em></em>
			</router-link>
			<span>更换登录密码</span>
		</div>
	    <yd-cell-group>
	    	<yd-cell-item arrow href="#" type="link">
	            <span slot="left">登入密码</span>
	            <input slot="right" style="font-size: 10px; color: #B8B8B8; text-align: right;" type="text" placeholder="登入密码">
	        </yd-cell-item>
	        <yd-cell-item href="#" type="link">
	            <span slot="left">验证码</span>
	            <yd-sendcode slot="right" 
	                         v-model="start" 
	                         @click.native="sendCode" 
	                         type="primary"
	            ></yd-sendcode>
	        </yd-cell-item>
	        <yd-cell-item arrow href="#" type="link">
	            <span slot="left">新密码</span>
	            <input slot="right" style="font-size: 10px; color: #B8B8B8; text-align: right;" type="text" placeholder="新密码">
	        </yd-cell-item>
	        <yd-cell-item arrow href="#" type="link">
	            <span slot="left">确认新密码</span>
	            <input slot="right" style="font-size: 10px; color: #B8B8B8; text-align: right;" type="text" placeholder="确认新密码">
	        </yd-cell-item>
	    </yd-cell-group>    
	    <yd-button size="large" type="primary" shape="angle">确定</yd-button>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				start:''
			}
		},
		methods: {
			sendCode(){
				
			}
		},
	}
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.yd-btn{
		color: #05565E !important;
		width: 100px!important;
		background: #FFFFFF !important;
		display: block;
		padding: 0 !important;
		margin: 0 !important;
		border: none!important;
	}
	.yd-btn-primary:not(.yd-btn-loading){
		margin:  74px auto;
		width: 90%;
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
		border: 1px solid  #05535C ;
		color: #FFFFFF ;
		height: 35px;
		line-height: 35px;
	}
</style>