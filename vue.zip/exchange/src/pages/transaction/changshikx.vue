<template>

	<div class="changshi">
		<div class="top-back" style="padding-bottom: 40px;">
			<router-link to="transactions">
				<div class="click"></div>
				<em></em>
			</router-link>
		</div>
		<div class="moreData">
				<div class="valueData">
					<span style="font-size: 28px;padding-right: 10px;">0.00586</span>
					<span>$0.00100↑</span>
				</div>
				<div class="leftcct">
						<div class="topcct">
							<span>-0.00044</span>
							<span>-8.14%</span>
						</div>
						<span>日成交量112,635,547</span>
				</div>
				<div class="rightcct">
						<span>开 0.00600</span>
						<span>高 0.00600</span>
						<span>低 0.00600</span>
				</div>
		</div>
		<div class="banner">
			<span v-for="(item,index) in banners" :key='index' @click="active(index)" :class="Index == index?'activeclass':''">{{item.title}}</span>
		</div>
		<div v-for="(items,index) in banners" :key1='index' v-if="Index == index && showBanner" class="banner-bottom">
			<span v-for="(item,cindex) in items.list" :key1="cindex" @click="select(cindex)" :class="cIndex == cindex?'selectclass':''">{{item}}</span>
		</div>
		<ve-candle :data="chartData" :settings="chartSettings" style="padding: 0 10px;"></ve-candle>

		<div class="bodyCont">
			<yd-tab v-model="tab1">
				<yd-tab-panel label="市场委托">
					<div class="entrust">
						<ul>
							<li class="firstLis">
								<span style="text-align: left;">数量</span>
								<span>买盘</span>
								<span>价格</span>
								<span style="text-align: left;">价格</span>
								<span>卖盘</span>
								<span style="text-align: right;">数量</span>
							</li>
							<li class="lastLis" v-for="list in lists">
								<span style="text-align: left;">{{list.num}}</span>
								<span style="color: #07AC71;">{{list.price}}</span>
								<span style="text-align: left;color: #E85353;">{{list.pricess}}</span>
								<span style="text-align: right;">{{list.number}}</span>
							</li>
						</ul>
					</div>
				</yd-tab-panel>
				<yd-tab-panel label="最新成交">
					<div class="deal">
						<ul>
							<li class="firstLiss">
								<span style="text-align: left;">时间</span>
								<span>价格</span>
								<span style="text-align: right;">数量</span>
							</li>
							<li v-for="item in items">
								<span style="text-align: left;">{{item.time}}</span>
								<span style="color: #E85353;">{{item.pricel}}</span>
								<span style="text-align: right;">{{item.nums}}</span>
							</li>
						</ul>
					</div>
				</yd-tab-panel>
				<yd-tab-panel label="介绍">
					<div class="introduce">
						<p>TC (System Working Token China)</p>
						<ul>
							<li>
								<span class="leftSpan">发行时间</span>
								<span class="rightSpan black">暂无数据</span>
							</li>
							<li>
								<span class="leftSpan">发行总量</span>
								<span class="rightSpan black">600,000,000,000</span>
							</li>
							<li>
								<span class="leftSpan">流通总量</span>
								<span class="rightSpan black">100,000,000,000</span>
							</li>
							<li>
								<span class="leftSpan">发行价格</span>
								<span class="rightSpan black">暂无数据</span>
							</li>
							<li>
								<span class="leftSpan">白皮书</span>
								<span class="rightSpan blue">http://tc.top/a/paper/</span>
							</li>
							<li>
								<span class="leftSpan">官网</span>
								<span class="rightSpan blue">http://tc.top/a/paper/</span>
							</li>
						</ul>
						<span class="content">TC (System Working Token China) Token是TC公链接的原声数字资产，由TC基金会（新加坡）发行并负责运营。其作用类似于比特币系统中的BTC或以太坊中的ETH，是TC公链上的底层燃料和通用通证。除了作用SETC公链系统中交易费用的消费手段、信用质押、跨链跨通证计价单位。同时，SETC Token可以保障系统运行的稳定和安全，提高恶意攻击的成本。
TC公链采用自有知识产权的RBFT共识算法，耗时5年研发，充分考虑了大规模商用化要求，支持高速的交易并发量、区块生成时间10秒、实现全球首个异步合约调用以及亚秒级拜占庭容错的快速合约调用，是国际上为数不多的，能够支撑大规模商用化、以及复杂业务场景的区块链底层公链。</span>
					</div>
				</yd-tab-panel>
			</yd-tab>
		</div>
		<div class="posBotoom">
			<div class="borderTwo">
				<span class="borderbuy">买入</span>
				<span class="bordersell">卖出</span>
			</div>
		</div>
	</div>
</template>
<script>
	export default {
		data() {
			this.chartSettings = {
				showVol: true, //	是否展示成交量
				showMA: true, //	是否展示移动平均线指标
				dataType: 'KMB', //    数据展示格式		
				showDataZoom: false, //	是否展示 dataZoom 控件
				downColor: '#F66765', // 下降颜色
				upColor: '#4DB374', // 上升颜色
			}
			return {
				tab1: 0,
				lists: [{
						num: '328,258',
						price: 0.00586,
						pricess: 0.00589,
						number: '328,258'
					},
					{
						num: '328,258',
						price: 0.00586,
						pricess: 0.00589,
						number: '328,258'
					},
					{
						num: '328,258',
						price: 0.00586,
						pricess: 0.00589,
						number: '328,258'
					},
				],
				items: [{
						time: '14:03:50',
						pricel: 0.00589,
						nums: '1,089,970'
					},
					{
						time: '14:03:50',
						pricel: 0.00589,
						nums: '1,089,970'
					},
				],
				banners: [{
						title: '分时',
						list: ['分时', '1分', '5分', '15分', '30分', '1小时', '2小时', '4小时', '6小时', '12小时', '日', '周', '月']
					},
					{
						title: '指标',
						list: ['1121', '22']
					},
					{
						title: '深度',
						list: ['112', '22']
					},
					{
						title: 'XXXX',
						list: ['1133', '22']
					}
				],
				Index: -1,
				cIndex: -1,
				showBanner: true,
				chartData: {
					columns: ['日期', 'open', 'close', 'lowest', 'highest', 'vol'],
					rows: [{
							'日期': '2004-01-05',
							open: 10411.85,
							close: 10544.07,
							lowest: 10411.85,
							highest: 10575.92,
							vol: 221290000
						},
						{
							'日期': '2004-01-06',
							open: 10543.85,
							close: 10538.66,
							lowest: 10454.37,
							highest: 10584.07,
							vol: 191460000
						},
						{
							'日期': '2004-01-07',
							open: 10535.46,
							close: 10529.03,
							lowest: 10432.12,
							highest: 10587.55,
							vol: 225490000
						},
						{
							'日期': '2004-01-08',
							open: 10530.07,
							close: 10592.44,
							lowest: 10480.59,
							highest: 10651.99,
							vol: 237770000
						},
						{
							'日期': '2004-01-09',
							open: 10589.25,
							close: 10458.89,
							lowest: 10420.52,
							highest: 10603.48,
							vol: 223250000
						},
						{
							'日期': '2004-01-12',
							open: 10461.55,
							close: 10485.18,
							lowest: 10389.85,
							highest: 10543.03,
							vol: 197960000
						},
						{
							'日期': '2004-01-13',
							open: 10485.18,
							close: 10427.18,
							lowest: 10341.19,
							highest: 10539.25,
							vol: 197310000
						},
						{
							'日期': '2004-01-14',
							open: 10428.67,
							close: 10538.37,
							lowest: 10426.89,
							highest: 10573.85,
							vol: 186280000
						},
						{
							'日期': '2004-01-15',
							open: 10534.52,
							close: 10553.85,
							lowest: 10454.52,
							highest: 10639.03,
							vol: 260090000
						},

					]
				}
			}
		},
		methods: {
			active(index) {
				this.showBanner = true
				this.Index = index
			},
			select(cindex) {
				this.cIndex = cindex
				this.banners[this.Index].title = this.banners[this.Index].list[cindex]
				this.showBanner = false
			}
		}
	}
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
.changshi{
	.moreData {
		padding-left: 15px;
		padding-right: 15px;
		overflow: hidden;
		width: 100%;
		/*height: 130px;*/
		background: #1C53D4;
		color: white;
		.valueData{
			padding-top: 15px;
			span{
				display: inline-block;
			}
		}
		.leftcct{
			float: left;
			width: 50%;
			padding-top: 20px;
			padding-bottom: 8px;
			span{
				display: inline-block;
				line-height: 30px;
			}
		}
		.rightcct{
			padding-top: 20px;
			width: 50%;
			float: right;
			text-align: right;
			span{
				display: block;
				line-height: 20px;
			}
		}
	}
	
	.banner {
		width: 100%;
		span {
			display: inline-block;
			width: 25%;
			height: 60px;
			line-height: 60px;
			text-align: center;
			font-size: 16px;
			color: #000000;
		}
		.activeclass {
			color: #ffffff;
			background: #3C4145;
			opacity: 0.9;
		}
	}
	
	.banner-bottom {
		width: 100%;
		background: #3C4145;
		opacity: 0.9;
		position: absolute;
		z-index: 9999;
		span {
			width: 20%;
			color: #ffffff;
			text-align: center;
			display: inline-block;
			height: 50px;
			line-height: 50px;
			font-size: 14px;
		}
		.selectclass {
			color: #FFC600;
		}
	}
	
	.posBotoom {
		width: 100%;
		padding: 0 15px 10px 15px;
		.borderTwo {
			width: 100%;
			margin: 0 auto;
			overflow: hidden;
			text-align: center;
			line-height: 35px;
			.borderbuy {
				float: left;
				display: block;
				width: 49%;
				background: #00A96C;
				border-radius: 3px;
				color: white;
			}
			.bordersell {
				width: 49%;
				float: right;
				display: block;
				background: #E85353;
				border-radius: 3px;
				color: white;
			}
		}
	}
	
	.bodyCont {
		/*padding-top: 50px;*/
		padding-bottom: 50px;
		.entrust {
			padding-left: 10px;
			padding-right: 10px;
			ul {
				.firstLis {
					overflow: hidden;
					text-align: center;
					span {
						display: block;
						width: 16.5%;
						line-height: 30px;
						color: #9A9A9A;
						float: left;
					}
				}
				.lastLis {
					overflow: hidden;
					span {
						text-align: center;
						display: block;
						float: left;
						line-height: 20px;
						width: 25%;
					}
				}
			}
		}
		.deal {
			padding-left: 10px;
			padding-right: 10px;
			ul {
				.firstLiss {
					line-height: 30px;
					span {
						display: block;
						color: #9A9A9A;
					}
				}
				li {
					overflow: hidden;
					text-align: center;
					span {
						float: left;
						width: 33%;
						line-height: 22px;
					}
				}
			}
		}
		.introduce {
			padding-left: 10px;
			padding-right: 10px;
			p {
				font-size: 14px;
				color: #222222;
				line-height: 40px;
			}
			.content {
				display: block;
				font-size: 11px;
				color: #000000;
				line-height: 20px;
			}
			ul {
				padding-bottom: 30px;
				li {
					overflow: hidden;
					line-height: 40px;
					border-bottom: 1px solid #ECECEC;
					span {
						color: #B8B8B8;
						font-size: 12px;
					}
					.black {
						color: #000000;
					}
					.blue {
						color: #3E63FD;
					}
					.leftSpan {
						display: block;
						float: left;
					}
					.rightSpan {
						float: right;
						display: block;
					}
				}
			}
		}
	}
		
}
</style>