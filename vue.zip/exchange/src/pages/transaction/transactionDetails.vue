<template>
	<div class="transactionDetails">
		<div class="top-back">
			<router-link to="userRecord">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>交易详情</span>
		</div>
	    <div class="top_nav">
	    	<img src="../../../static/img/record_for.png"/>
	    	<p>+35</p>
	    	<span>BTC</span>
	    </div>
	    <ul>
	    	<li>
	    		<span>发送方</span>
	    		<span>dhkoksahjkcjkbakjcbjka4674545</span>
	    	</li>
	    	<li>
	    		<span>接收方</span>
	    		<span>dhkoksahjkcjkbakjcbjka4674545</span>
	    	</li>
	    	<li>
	    		<span>网络费</span>
	    		<span>0.01 BTC</span>
	    	</li>
	    	<li>
	    		<span>备注</span>
	    		<span>-</span>
	    	</li>
	    </ul>
	    <ul style="border-top: none;">
	    	<li>
	    		<span>交易号</span>
	    		<span>dhkoksahjkcjkbakjcbjka4674545</span>
	    	</li>
	    	<li>
	    		<span>区块</span>
	    		<span>-</span>
	    	</li>
	    	<li>
	    		<span>交易时间</span>
	    		<span>2018-12-25 10:26:00</span>
	    	</li>
	    </ul>
	    <div class="copyBottom">
	    	<img src="../../../static/img/wallet_picture.png"/>
	    	<span>复制URL</span>
	    </div>
	</div>
</template>

<script>
	
	export default{
		data(){
			return {
				
			}
		},
		compnents: {
			
		}
	}
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.transactionDetails{
		.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			span{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
		}
		.top_nav{
			text-align: center;
			img{
				width: 47px;
				height: 47px;
				margin: 16px 0 12px 0;
			}
			p{
				font-size: 20px;
				color: #222222;
			}
			span{
				display: block;
				padding-bottom: 10px;
				font-size: 12px;
				color: #A1A4AC;
			}
		}
		ul{
			padding:10px 15px;
			border-top: 1px solid  #ECECEC;
			border-bottom: 1px solid  #ECECEC;
			li{
				line-height: 35px;
				overflow: hidden;
				span:first-child{
					font-size: 12px;
					color: #B8B8B8;
					display: block;
					float: left;
				}
				span:last-child{
					font-size: 12px;
					color: #7B808A;
					float: right;
					display: block;
				}
				
			}
		}
		.copyBottom{
			text-align: center;
			img{
				width: 83px;
				height: 84px;
				margin: 18px 0 16px 0;
			}
			span{
				margin: 0 auto;
				display: block;
				width: 90px;
				height: 25px;
				line-height: 25px;
				border: 1px solid #979797;
			}
		}
	}
</style>