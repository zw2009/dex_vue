<template>
	<div class="transactions">
		<!--<div class="topposNav">
			<router-link to="graph">
				<img class="logo" src="../../../static/img/trading_market.png" width="19" height="17" />
			</router-link>
			<span>BTC / TC</span>
			<img class="midimg" src="../../../static/img/market_Under_white.png" />
		</div>-->
		<div class="top-back" style="height: 68px; position: relative;">
			<!--<router-link to="assetSelection">-->
				<div @click="Choice" class="leftTitle" style="line-height: 68px;width: 50%; font-size: 16px;color: #434A59;padding-left: 15px;overflow: hidden;">
					<span style="display: block;float: left;"> {{item}}/ TC</span>
					<img class="logo" src="../../../static/img/landing_arrow.png" width="9" height="6" />
					
				</div>
			<!--</router-link>-->
			<span style="text-align: center; width: 50px;height: 69px;position: absolute;top: 0;right: 53px;display: block;">
				<img class="tradingOne" style="width: 16px;height: 16px;margin-top: 20px;" src="../../../static/img/trading_icon_one.png"/>
			</span>
			<router-link to="changshikx">
				<span style="text-align: center; width: 50px;height: 69px;position: absolute;top: 0;right: 13px;display: block;">
					<img class="tradingtwo" style="position: absolute;top: 40%;right: 13px;transform: translateY(-50%);width: 17px;height: 14px;"  src="../../../static/img/trading_icon_two.png"/>
				</span>
			</router-link>
		</div>
		<div class="twoContent" style="overflow: hidden;">
			<div class="leftBuyy" style="float: left;width: 50%;">
				<div class="topNavs">
					<div class="ger">
						<span @click="buy" class="buyl" :class="{cur:shows==1}">买入</span>
					</div>
					<div class="red">
						<span @click="out" class="outl" :class="{cur:shows==2}">卖出</span>
					</div>
					
					
				</div>
				<!--<yd-tab>
				<yd-tab-panel label="买入">-->
				<div class="buy" v-show="buyl">
					<div class="leftBuy">
						<p>限价单</p>
						<yd-spinner width="160px" height="30px" max="10000" unit="1" v-model="spinner1"></yd-spinner>
						<span class="Buyz">估值 ¥{{spinner1}}</span>
						<yd-spinner width="160px" height="30px" max="10000" unit="1" v-model="spinner2"></yd-spinner>
						<div class="percentile" v-show="greenPerce">
							<!--<span class="cur">25%</span><span>50%</span><span>75%</span><span class="lastSp">100%</span>-->
							<span :class="num == item ? 'active' : ''" v-for="(item, key) in arr" :key="key" @click = 'active(item)'>{{item}}%</span>
						</div>
						
						<span class="spinnerss">{{spinner1}}</span>
						<div class="ovflot">
							<span class="leftsP">可用</span>
							<span class="rightP">-- TC</span>
						</div>
						<yd-button size="large" bgcolor="#00A96C" color="#FFF">买入</yd-button>
						<img src="../../../static/img/trading_banner.png" width="100%" height="160" />
						
					</div>
				</div>
				<!--</yd-tab-panel>-->
				<!--<yd-tab-panel label="卖出">-->
				<div class="buy" v-show="outl">
					<div class="leftBuy">
						<p>限价单</p>
						<yd-spinner width="160px" height="30px" max="10000" unit="1" v-model="spinner3"></yd-spinner>
						<span class="Buyz">估值 ¥{{spinner1}}</span>
						<yd-spinner width="160px" height="30px" max="10000" unit="1" v-model="spinner4"></yd-spinner>
						<div class="percentile" v-show="redPerce">
							<span :class="num == item ? 'actives' : ''" v-for="(item, key) in arr" :key="key" @click = 'active(item)'>{{item}}%</span>
						</div>
						<span class="spinnerss">{{spinner1}}</span>
						<div class="ovflot">
							<span class="leftsP">可用</span>
							<span class="rightP">-- TC</span>
						</div>
						<yd-button size="large" type="danger">卖出</yd-button>
						<img src="../../../static/img/trading_banner.png" width="100%" height="160" />
						<!--<div class="filter_item">
							<span>xxx</span>
							<mt-range v-model="zoom"  :min="0" :max="5"  style='margin-top: 0.38rem;'>
					            <div slot="start"><img src="" style="width: 0.38rem;height: 0.28rem;margin-right:0.25rem;margin-right:0.1rem;"></div>
					            <div slot="end"><img src="" style="width: 0.32rem;height: 0.32rem;margin-left:0.15rem;"></div>
			        		</mt-range>
						</div>-->
					</div>

				</div>

				<!--</yd-tab-panel>

			</yd-tab>-->
			</div>
			<div class="rightbuyy" style="float: right;">
				<p>买卖盘</p>
				<div class="rightBuy">
					<div class="ovflotrig">
						<span class="leftpa">价格 TC</span>
						<span class="rightpa">数量 BTC</span>
					</div>
					<ul>
						<li v-for="item in items">
							<span class="leftss">{{item.price}}</span>
							<span class="rightss">{{item.num}}</span>
						</li>
					</ul>
					<span class="valuess">0.00560 ¥ 0.00560</span>
					<ul>
						<li v-for="list in lists">
							<span class="leftss" style="color: #00A96C;">{{list.prices}}</span>
							<span class="rightss">{{list.nums}}</span>
						</li>
					</ul>
				</div>
			</div>
		</div>
		<tabbar></tabbar>
		<div class="deal">
			<div class="title" style="text-align: center;">
				<span>— 最新成交 —</span>
				<!--<em class="noen"></em>
				<em class="twoo"></em>-->
			</div>
			<ul>
				<li class="firstLi">
					<span style="text-align: left;padding-left: 15px;">时间</span>
					<span style="color: #00A96C;">价格</span>
					<span style="text-align: right;padding-right: 15px;">数量</span>
				</li>
				<li v-for="todo in todos">
					<span style="text-align: left;padding-left: 15px;">{{todo.time}}</span>
					<span style="color: #00A96C;">{{todo.price}}</span>
					<span style="text-align: right;padding-right: 15px;">{{todo.number}}</span>
				</li>
			</ul>
		</div>
	</div>
</template>

<script>
	import tabbar from '@/components/TabBar'
	export default {
		created(){
			this.forget()
	        this.getinfor()
	        console.log(this.item,11111)
	    },
		data() {
			return {
				goodId:'',
				item:'SWTC',
				num: 1,
//				zoom: 1,
      			arr:[25, 50, 75,100],
				spinner1: 0,
				spinner2: 2,
				spinner3: 0,
				spinner4: 0,
				shows:1,
				buyl: true,
				outl: false,
				greenPerce:true,
				redPerce:false,
				items: [{
						price: 0.00589,
						num: "328,258"
					},
					{
						price: 0.00590,
						num: "1,089,970"
					},
					{
						price: 0.00589,
						num: "328,258"
					},
					{
						price: 0.00598,
						num: "6,157,225"
					},
					{
						price: 0.00589,
						num: "328,258"
					},
					{
						price: 0.00600,
						num: "437,628"
					},
					{
						price: 0.00587,
						num: "328,258"
					},
					{
						price: 0.00585,
						num: "437,628"
					},
					{
						price: 0.00584,
						num: "1,400,000"
					},
				],
				lists: [{
						prices: 0.01589,
						nums: '6,157,225'
					},
					{
						prices: 0.02583,
						nums: '492,571'
					},
					{
						prices: 0.07587,
						nums: '1,089,970'
					},
					{
						prices: 0.06586,
						nums: '437,628'
					},
					{
						prices: 0.05585,
						nums: '1,089,970'
					},
					{
						prices: 0.04584,
						nums: '975,977'
					},
					{
						prices: 0.03583,
						nums: '1,089,970'
					},
					{
						prices: 0.02582,
						nums: '437,628'
					},
					{
						prices: 0.01581,
						nums: '1,089,970'
					},
				],
				todos: [{
						time: "15:12:00",
						price: 0.00589,
						number: '328,258'
					},
					{
						time: "15:12:00",
						price: 0.00589,
						number: '1,089,970'
					},
					{
						time: "15:12:00",
						price: 0.00589,
						number: '492,571'
					},
					{
						time: "15:12:00",
						price: 0.00589,
						number: '89,32'
					},
					{
						time: "15:12:00",
						price: 0.00589,
						number: '349,9112'
					},
					{
						time: "15:12:00",
						price: 0.00589,
						number: '1239,570'
					},
				]
			}
		},
//		computed:{
//		  	zoom1(){
//		  		return 20-this.zoom;
//		  	}
//		},
		methods: {
			Choice(){
				console.log(this.item,123)
				this.$router.push({path:'/assetSelection',query:{typeId:this.item}})
			},
			out() {
				this.buyl = false;
				this.outl = true;
				this.greenPerce = false;
				this.redPerce = true;
				this.shows = 2;
				console.log(111)
			},
			buy() {
				this.buyl = true;
				this.outl = false;
				this.shows = 1;
				this.redPerce = false;
				this.greenPerce = true;
				console.log(222)
			}, 
			active (n) {
    		  this.num = n
   			},
   			getinfor(){
   				this.goodId = this.$route.query.typeName 
				this.item = this.goodId
   			},
   			forget(){
   				console.log(this.item,555)
   			}
		},
		components: {
			tabbar
		}
	}
</script>
<style type="text/css">
	.transactions .yd-input-password:after {
		color: #05535C;
	}
	
	.transactions .yd-btn-primary:not(.yd-btn-loading):active {
		background: #FFFFFF;
	}
	
	.transactions .yd-cell-item {
		padding-left: 15px !important;
	}
	
	.transactions .yd-tab-nav-item {
		color: #05535C !important;
	}
	
	.transactions .yd-tab-active {
		color: #05535C !important;
	}
	
	.transactions .yd-tab-active:before {
		width: 30% !important;
		margin-left: -15% !important;
	}
	
	.transactions .yd-cell-right {
		margin-top: 8px;
	}
</style>
<style lang="less" scoped>

.list {
ul {
  display: flex;
  display: -webkit-flex;
  width: 7.5rem;
  margin: 0 auto;
  li {
    width: 1rem;
  }
  .active {
    background: #0ff;
  }
}
}
	.yd-btn-block {
		margin-top: 5px!important;
		/*background: #00A96C;*/
		height: 30px;
		border-radius: 2px;
		margin-bottom: 10px;
	}
	
	.transactions {
		background: #FFFFFF;
		.topposNav {
			position: fixed;
			width: 100%;
			height: 50px;
			line-height: 50px;
			background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
			z-index: 999;
			.logo {
				margin-left: 15px;
				margin-top: 15px;
			}
			.midimg {
				width: 9px;
				height: 6px;
				display: block;
				position: absolute;
				top: 50%;
				left: 62%;
				transform: translateY(-50%);
			}
			span {
				position: absolute;
				font-size: 17px;
				left: 50%;
				top: 50%;
				transform: translate(-50%, -50%);
				color: white;
			}
		}
		.twoContent {
			.topNavs{
				overflow: hidden;text-align: center;font-size: 14px;line-height: 40px;
				.ger{
					.buyl{
						float: left;width: 50%;
						color: #45B57F ;
					}
					.cur{
						 border-bottom: 2px solid #45B57F;
					}
				}
				.red{
					.outl{
						float: left;width: 50%;
						color:#FD505D;
					}
					.cur{
						 border-bottom: 2px solid #FD505D;
					}
				}
				
				
			}
			.buy {
				padding-left: 15px;
				overflow: hidden;
				width: 100%;
				.leftBuy {
					/*width: 50%;*/
					float: left;
					/*.filter_item{
						height: 200px;
						padding: 0.25rem 0.25rem;
				.round{
					font-size: 0.28rem;
				}
				.round_num{
					font-size: 0.24rem;
					float: right;
					margin-top: 0.1rem;
					display: inline-block;
				}
			}*/
					p {
						line-height: 42px;
						font-size: 12px;
						color: #000000;
					}
					.Buyz {
						padding-top: 4px;
						padding-bottom: 4px;
						display: block;
						font-size: 10px;
						color: #B8B8B8;
					}
					.spinnerss {
						display: block;
						width: 100%;
						line-height: 30px;
						border: 1px solid #CDCDCD;
						text-align: center;
						margin-bottom: 10px;
					}
					.ovflot {
						overflow: hidden;
						.leftsP {
							font-size: 10px;
							color: #B8B8B8;
							display: block;
							float: left;
						}
						.rightP {
							float: right;
							font-size: 10px;
							color: #000000;
							display: block;
						}
					}
					.percentile {
						width: 100%;
						padding-top: 10px;
						padding-bottom: 8px;
						overflow: hidden;
						.active{
						    color: #00A96C;
						    border: 1px solid #00A96C;
						}
						.actives {
						    color: red;
						    border: 1px solid red;
						}
						span {
							text-align: center;
							color: #CDCDCD;
							display: block;
							width: 22%;
							height: 18px;
							margin-right: 2.5%;
							float: left;
							line-height: 18px;
							border: 1px solid #CDCDCD;
						}
						
						.lastSp {
							margin-right: 0;
						}
					}
				}
			}
			.rightbuyy {
				width: 50%;
				p {
					line-height: 40px;
					text-align: center;
				}
				.rightBuy {
					height: 434px;
					padding-right: 15px;
					padding-left: 10px;
					float: left;
					width: 100%;
					box-sizing: border-box;
					.ovflotrig {
						overflow: hidden;
						line-height: 42px;
						.leftpa {
							float: left;
							display: block;
						}
						.rightpa {
							float: right;
							display: block;
						}
					}
					ul {
						li {
							overflow: hidden;
							line-height: 19px;
							.leftss {
								display: block;
								float: left;
								font-size: 10px;
								color: #E85353;
							}
							.rightss {
								float: right;
								font-size: 10px;
								color: #000000;
								display: block;
							}
						}
					}
					.valuess {
						margin: 10px 0 12px 0;
						display: block;
						width: 100%;
						line-height: 25px;
						background: #F7F7F7;
						text-align: center;
					}
				}
			}
		}
		.deal {
			padding-top: 5px;
			padding-bottom: 55px;
			.title {
				position: relative;
				/*background: #F7F7F7;*/
				height: 30px;
				line-height: 30px;
				span {
					padding-left: 15px;
					display: block;
					font-size: 12px;
					color: #000000;
				}
				em {
					display: block;
					width: 10px;
					height: 10px;
					border-left: 1px solid #CECECE;
					border-bottom: 1px solid #CECECE;
					position: absolute;
					top: 50%;
					right: 15px;
					transform: translate(0, -50%) rotate(315deg);
				}
				.noen {
					top: 40%;
					right: 15px;
				}
			}
			ul {
				.firstLi {
					line-height: 30px;
					font-size: 12px;
					color: #9A9A9A;
					border-bottom: 1px solid #ECECEC;
				}
				li {
					overflow: hidden;
					span {
						display: block;
						line-height: 20px;
						float: left;
						width: 33%;
						text-align: center;
					}
				}
			}
		}
	}
</style>