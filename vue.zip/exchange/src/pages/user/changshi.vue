<template>
    <div class="qrscan">
        <!--<div class="qrscanner">
            <div class="qrscanner-area">
            </div>
            <div class="through-line"></div>
            <div class="button-bottom-camera">
                <button class="btn" @click="flashlight">
                    手电筒5
                </button>
                <button class="btn" @click="camera">
                    切换摄像头
                </button>
            </div>
        </div>-->
    </div>
</template>
<script>
    export default{
        mounted(){
                if (typeof (QRScanner) != 'undefined') {
                    //初始化检测，申请摄像头等权限
                    QRScanner.prepare(onDone);
                } else {
                    alert('插件加载失败');
                }
                function onDone(err, status) {
                    QRScanner.destroy();
                    if (err) {
                        console.error(err);
                    }
                    if (status.authorized) {
                        //绑定扫描监听
                        // `QRScanner.cancelScan()` is called.
                        QRScanner.scan(displayContents);
                        function displayContents(err, text) {
                            if (err) {
                                alert('启动扫描出错：' + JSON.stringify(err));
                            } else {
                                alert(text);
                            }
                        }
                        //开始扫描，需要将页面的背景设置成透明
                        QRScanner.show(
                            function(argument) {
                                $rootScope.$apply(function(argument) {
                                document.getElementById("app-view").style.display = 'none';
                            });
                        });
//                      window.document.querySelector('ion-app').classList.add('transparent-body');

                    } else if (status.denied) {
                        alert('用户拒绝访问摄像头');
                    } else {

                    }
                }
        },
        data(){
            return{
                light:false,
                frontCamera: false
            }
        },
        methods:{
            flashlight(){
                if(this.light){
                    QRScanner.enableLight();
                    alert('enableLight');
                }else{
                    QRScanner.disableLight();
                }
                this.light = !this.light
            },
            camera(){
                if(this.frontCamera){
                    QRScanner.useFrontCamera();
                    alert('useFrontCamera');
                }else{
                    QRScanner.useBackCamera();
                }
                this.frontCamera = !this.frontCamera;
            }
        }
    }
</script>

<style>
.qrscan{
    height: 100%;
    /*background: none;*/
   opacity: 0;
}
.qrscanner {
    width: 100%;
    height: 100%;
    background: none;
    background:rgba(0,0,0,0);
}
.qrscanner-area {
    width: 100%;
    background:rgba(0,0,0,0);
    background: none;
    height: 85%;
    opacity: 0;
    background-size: contain;
}
.through-line {
    left: 20%;
    width: 60%;
    height: 2px;
    position: absolute;
    animation: myfirst 5s linear infinite alternate;
}
@keyframes myfirst {
    0% {
        background: red;
        top: 180px;
    }

    25% {
        background: yellow;
        top: 220px;
    }

    50% {
        background: blue;
        top: 240px;
    }

    75% {
        background: green;
        top: 260px;
    }

    100% {
        background: red;
        top: 280px;
    }
}

.button-bottom-camera {
    width: 128px;
    position: absolute;
    left: 50%;
    bottom: 80px;
    margin-left: -64px;
}

.icon-camera {
    float: left;
}
.btn{
    width: 40px;
    height: 40px;
    vertical-align: top;
    margin-right: 20px;
    border: none;
    background: #f2f2f2;
    border: 1px solid #dddddd;
}
ion-app .cameraView, ion-app .cameraView ion-content, ion-app .cameraView .nav-decor {
  background: transparent none !important;
  opacity: 0;
  }
/*.transparent-body {
  background: none transparent !important;
  opacity: 0 !important;
}*/
</style>
