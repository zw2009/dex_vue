<template>
	<div class="user">
		<div class="topTitle" style="padding:23px 0px 23px 15px; ">
			<span style="font-size: 20px;color: #434A59;">我的</span>
		</div>
		<div class="logged" v-show="logged">
			<div class="borderLogin">
				<div class="userInfortwo">
					<p style="height: 44px;width: 100%;">2*******0@qq.com</p>
					<div class="content">
						<router-link to="userAuthentication">
							<span>未认证<em></em></span>
						</router-link>
						<router-link to="userWallet">
							<span>备份私钥<em style="right: 1px;"></em></span>
						</router-link>
					</div>
				</div>
			</div>
			<yd-cell-group>
				<yd-cell-item arrow href="userContacts" type="link">
		            <span slot="left">联系人</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userRecord" type="link">
		            <span slot="left">交易记录</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userSecurity" type="link">
		            <span slot="left">安全中心</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userFeedback" type="link">
		            <span slot="left">问题反馈</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userAbout" type="link">
		            <span slot="left">关于我们</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="" type="link">
		            <span slot="left">客服中心</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userSet" type="link">
		            <span slot="left">设置</span>
		        </yd-cell-item>
		    </yd-cell-group>
			
		</div>
		<div class="notlogged" v-show="notlogged">
			<div class="border" @click="login"> 
				<div class="userInfor">
					<span>未登录</span>
					<em></em>
				</div>
			</div>
			<yd-cell-group>
		        <yd-cell-item arrow href="userSecurity" type="link">
		            <span slot="left">安全中心</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userFeedback" type="link">
		            <span slot="left">问题反馈</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userAbout" type="link">
		            <span slot="left">关于我们</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="" type="link">
		            <span slot="left">客服中心</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userSet" type="link">
		            <span slot="left">设置</span>
		        </yd-cell-item>
		    </yd-cell-group>
		</div>

	    
	    <!--<yd-cell-group>
		        <yd-cell-item arrow href="" type="link">
		            <span slot="left">实名认证</span>
		            <span slot="right" style="font-size: 10px; color: #B8B8B8;">未认证</span>
		        </yd-cell-item>
		         <yd-cell-item arrow href="userSecurity" type="link">
		            <img slot="icon" src="../../../static/img/my_Security.png" style="width: 17px;height: 18px;">
		            <span slot="left">安全中心</span>
		        </yd-cell-item>
	    </yd-cell-group>
		    <yd-cell-group>
		        <yd-cell-item arrow href="userWalletaddress" type="link">
		            <img slot="icon" src="../../../static/img/my_wallet.png" style="width: 17px;height: 18px;">
		            <span slot="left">钱包地址</span>
		            <span slot="right" style="font-size: 10px; color: #B8B8B8;">未激活</span>
		        </yd-cell-item>
		         <yd-cell-item arrow href="userContacts" type="link">
		            <img slot="icon" src="../../../static/img/my_contact.png" style="width: 17px;height: 18px;">
		            <span slot="left">联系人</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userRecord" type="link">
		            <img slot="icon" src="../../../static/img/my_record.png" style="width: 17px;height: 18px;">
		            <span slot="left">交易记录</span>
		        </yd-cell-item>
		    </yd-cell-group>
		    <yd-cell-group>
		        <yd-cell-item arrow>
		            <img slot="icon" src="../../../static/img/my_Customer.png" style="width: 17px;height: 18px;">
		            <span slot="left">客服中心</span>
		        </yd-cell-item>
		         <yd-cell-item arrow href="userFeedback" type="link">
		            <img slot="icon" src="../../../static/img/my_problem.png" style="width: 17px;height: 18px;">
		            <span slot="left">问题反馈</span>
		        </yd-cell-item>
		        <yd-cell-item arrow href="userAbout" type="link">
		            <img slot="icon" src="../../../static/img/my_About.png" style="width: 17px;height: 18px;">
		            <span slot="left">关于我们</span>
		        </yd-cell-item>
		    </yd-cell-group>
		    <yd-cell-group>
		        <yd-cell-item arrow href="userSet" type="link">
		            <img slot="icon" src="../../../static/img/my_Setup.png" style="width: 17px;height: 18px;">
		            <span slot="left">设置</span>
		        </yd-cell-item>
		    </yd-cell-group>
  			<yd-button size="large" type="primary" @click.native="out" shape="angle">退出登入</yd-button>-->
  			
		<tabbar></tabbar>
		
	</div>
</template>

<script>
	import tabbar from '@/components/TabBar'
	import { removeStore,getStore } from '@/common/storage'
	export default {
//		created(){
//          this.getinfor()
//      },
		data() {
			return {
				logged:true ,
				notlogged: false
			}
		},
		methods: {
			login(){
//				console.log(getStore(user_token))
				this.$router.replace('/login')
			},
//			getinfor(){
//              this.$api.indexs({}, res =>{
//					console.log(res)
//              })
//          },
//			getconten(){
//				if () {
//					
//				} else{
//					
//				}
//			},
			out(){
		
				this.$dialog.confirm({
					title:'提示',
					mes:'您确定退出登录吗？',
					opts:[{
						txt:'取消',
						color:false,
					},
					{
						txt:'确定',
						color:true,
						callback:() => {
//							console.log(getStore('user_token'))
//							 this.$router.push('login')
//									removeStore('user_token')
//									this.$router.replace('/login')
							this.$api.logout({},res =>{
								console.log(res)	
								if(res.status) {
									removeStore('user_token')
									this.$router.replace('/login')
								}
							})
						}
					}
					
					]
				})
			}
		},
		components: {
			tabbar
		}
	}
</script>

<style lang="less" scoped>
	.yd-cell-right {
		margin-top: 0px!important;
	}
	.yd-btn-primary:not(.yd-btn-loading){
		text-align: center!important;
		margin:  0 auto;
		width: 90%;
		background:#ffffff;
		border: 1px solid  #05535C ;
		color: #05535C ;
	}
	.yd-cell-item{
		height: 45px;
	}
	.yd-cell-item{
		padding-left: 15px!important;
	}
	.yd-navbar {
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%)!important;
	}
	.user{
		padding-bottom: 60px;
		.notlogged{
		.border{
			padding:0 15px;
			.userInfor{
				width: 100%;
				height: 80px;
				background-image: radial-gradient(98% 50%, #2D7F86 2%, #04555D 99%);border-radius: 10px;
				position: relative;
				span{
					display: block;
					line-height: 80px;
					font-size: 16px;
					color: #FFFFFF;
					padding-left: 15px;
				}
				em{
					display: block;
					width: 10px;
					height: 10px;
					border-left: .02rem solid #fff;
					border-bottom: .02rem solid #fff;
					position: absolute;
					top: 50%;
					right:15px;
					transform: translate(0,-50%) rotate(225deg) ;	
				}
			}
					
		}
		}	
		.logged{
			.borderLogin{
				padding:0 15px;
				.userInfortwo{
					width: 100%;
					height: 80px;
					background-image: radial-gradient(98% 50%, #2D7F86 2%, #04555D 99%);border-radius: 10px;
					position: relative;	
					p{
						padding-left: 15px;
						font-size: 16px;
						color: #FFFFFF;
						padding-top: 16px;
						padding-bottom: 10px;
					}
					.content{
						padding-left: 15px;
						overflow: hidden;padding-top: 4px;
						span{
							float: left;
							width: 60px;
							display: block;
							font-size: 12px;
							color: #FFFFFF;
							position: relative;
							em{
								display: block;
								width: 8px;
								height: 8px;
								border-left: .02rem solid #fff;
								border-bottom: .02rem solid #fff;
								position: absolute;
								top: 50%;
								right:12px;
								transform: translate(0,-50%) rotate(225deg) ;	
							}
						}
					}
				}
			}
		}
	}
</style>