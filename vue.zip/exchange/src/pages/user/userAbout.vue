<template>
	<div class="userAbout">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>关于我们</span>
		</div>
		<div class="cotnetR">
			<img src="../../../build/logo.png"/>
			<p>TC Wallet</p>
			<span>Version 4.3.1（26）</span>
		</div>
	
	</div>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		}
	}	
</script>
<style lang="less" scoped>
.userAbout{
	margin: 0 auto;
		.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			span{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
		}
		.cotnetR{
			text-align: center;
			img{
				margin-top: 85px;
				margin-bottom: 35px;
				width: 75px;
				height: 75px;
			}
			p{
				font-size: 14px;
				color: #222222;
				line-height: 30px;
			}
			span{
				font-size: 10px;
				color: #A1A4AC;
			}			
		}
}
</style>