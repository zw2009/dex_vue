<template>
	<div class="userAddcontacts">
		<div class="top-back">
			<router-link to="userContacts">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>联系人</span>
		</div>
		<ul>
			<li>
				<span>姓名</span>
				<input type="" name="" id="" value="" placeholder="名字"/>
				<i class="rightBrackets"></i>
			</li>
			<li>
				<span>钱包地址</span>
				<img src="../../../static/img/contact_scanning.png" width="16px" height="16px"/>
			</li>
			<li>
				<span>备注</span>
				<input type="" name="" id="" value="" placeholder="备注"/>
				<i class="rightBrackets"></i>
			</li>
		</ul>
		<yd-button size="large" type="primary"  shape="angle">确定</yd-button>
	</div>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		methods: {
		},
	}
</script>
<style type="text/css">
	.userAddcontacts .yd-btn-primary:not(.yd-btn-loading){
		text-align: center;
		margin:  74px auto;
		width: 90%;
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
		color: #FFFFFF ;
		height: 35px;
		line-height: 35px;
		border-radius: 5px;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
.userAddcontacts{
	ul{
		li{
			line-height: 50px;
			overflow: hidden;
			margin-left: 15px;
			border-bottom: 1px solid #F6F6F6;
			position: relative;
			span{
				float: left;
				display: block;
				width: 30%;
			}
			input{
				width: 60%;
				border: none;
				line-height: 50px;
				float: left;
				text-align: right;
				font-size: 12px;
				
			}
			::-webkit-input-placeholder { /* WebKit browsers */
			    color:  #B8B8B8;
			}
			img{
				float: right;
				margin: 16px;
			}
		}
	}
	
}			
</style>
