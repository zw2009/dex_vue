<template>
	<div class="Authentication">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>实名认证</span>
		</div>
	    <yd-cell-group>
	        <yd-cell-item arrow href="#" type="link">
	            <span slot="left">姓名</span>
	            <input slot="right" style="font-size: 10px; color: #000; text-align: right;" type="text" placeholder="姓名">
	        </yd-cell-item>
	        <yd-cell-item arrow href="#" type="link">
	            <span slot="left">身份证</span>
	            <input slot="right" style="font-size: 10px; color: #000; text-align: right;" type="number" placeholder="身份证">
	        </yd-cell-item>
	        <div class="redinput">
		        <yd-cell-item arrow href="#" type="link">
		            <span slot="left">银行卡号</span>
		            <input slot="right" style="font-size: 10px; color: #000; text-align: right;" type="text" placeholder="必须使用中国大陆开户的银行卡">
		        </yd-cell-item>
            </div>
	        <yd-cell-item arrow href="#" type="link">
	            <span slot="left">手机号</span>
	            <input slot="right" v-model="phone" style="font-size: 10px; color: #000; text-align: right;" type="number" placeholder="银行预留">
	        </yd-cell-item>
			<yd-cell-item>
				<yd-input slot="right" v-model="code"  placeholder="验证码"></yd-input>
        	  	<yd-sendcode class="sendsms" slot="right" v-model="start" init-str="发送" @click.native="sendCode" type="warning"></yd-sendcode>
			</yd-cell-item>
	    </yd-cell-group>
		<yd-button size="large" type="primary" shape="angle" @click.native="Authe">实名认证</yd-button>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				start:false,
				code:'',
				phone:''
				
			}
		},
		methods: {
			sendCode(){
				let reg=/^1[3456789]\d{9}$/;
                if(!this.phone){
                    this.$dialog.toast({mes:'请输入手机号',timeout: 1000})
                    return;
                }
                if(!reg.test(this.phone)){
                	this.$dialog.toast({mes:'请输入正确手机号',timeout: 1000})
                	return;
                }
                this.$dialog.loading.open('发送中...');
               
                setTimeout(() => {
					this.$dialog.loading.close();
//                  this.$api.checkSms({
//                  	account:this.phone, 
//                  	operation:'reg',
//                  	type:1,
//                  	country:this.issue,
//                  	code:this.code,
//                  	},
//                  	res =>{
//                          
//                              if(!res.status){
//                                  this.$dialog.toast({mes:res.msg, timeout:1000})
//                                  this.phone =""
//                              }else{
//                                  this.$dialog.toast({mes:'已发送',icon: 'success', timeout: 1500})
//                                  this.start = true;
//                              }
//                          })
				}, 1000);
			},
            Authe(){
            	  this.$dialog.confirm({
                    title: '承诺',
                    mes: '本人承诺提交的信息完全属实，不存在伪造、盗用他人信息的行为，若信息有误，自愿承担一切后果。！',
//                  opts: () => {
//                      this.$dialog.toast({
//                      	mes: '完成',
//                      	callback:() => {
//                            this.$router.push('user')
//                              }
//                      	})
//                      ;
//                  }
					opts:[{
						txt:'取消',
						color:false,
					},
					{
						txt:'确定',
						color:true,
						callback:() => {
							this.$router.push('user')
						}
					}
					]
                });
            }
		},
	}
</script>
<style type="text/css">
	.Authentication .redinput ::-webkit-input-placeholder{
		color: red;
	}
	.Authentication ::-webkit-input-placeholder{
		color: #B8B8B8;
	}
	 .yd-confirm-hd {
		text-align: center!important;
		font-size: 18px!important;
		font-weight: 600!important;
		color: #000000;
	}

	.Authentication .yd-confirm {
		width: 280px;
		border-radius: 12px!important;
	}
	.Authentication .yd-confirm-ft{
		border-top: 1px solid #f1f1f1!important;
	}

	.Authentication .yd-confirm-bd{
		font-size: 13px!important;
		color: #000000!important;
	}
	.Authentication .yd-confirm-ft>a.default {
		color: #007aff!important;
		border-right: 1px solid #f1f1f1!important;
		font-size: 17px!important;
	}
	.Authentication .yd-confirm-ft>a.primary{
		color:#007aff!important;
		font-size: 17px!important;
	}
</style>
<style lang="less" scoped>
	.yd-confirm-hd{
		text-align: center!important;
	}
	.yd-confirm{
		width: 70% !important;
		border-radius: 10px;
	}
	.yd-btn{
		color: #05565E !important;
		width: 100px!important;
		background: #FFFFFF !important;
		display: block;
		padding: 0 !important;
		margin: 0 !important;
		border: none!important;
	}
	.yd-btn-primary:not(.yd-btn-loading){
		margin:  74px auto;
		width: 90%;
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
		border: 1px solid  #05535C ;
		color: #FFFFFF ;
		height: 35px;
		line-height: 35px;
	}
	.Authentication{
		.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			span{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
		}
	}
	
</style>