<template>
	<div class="Contacts">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span class="leftSpan">联系人</span>
			<router-link to="userAddcontacts">
				<span class="rigtSpan">添加</span>
			</router-link>
		</div>
	    <div class="imgll" v-show="nocont">
	    	 <img src="../../../static/img/contact_picture.png"/>
	    	 <p>暂无内容</p>
	    </div>
	    <div class="cont" v-show="cont">
	    	<yd-search v-model="value1" :on-submit="submitHandler"></yd-search>
	    	<ul>
	    		<router-link to="userSendcontacts">
		    		<li>
		    			<div class="left_surname">
		    				<span>逗</span>
		    			</div>
		    			<div class="rightimg">
		    				<span>豆豆</span>
		    				<span>dhkoksahjkcjkbakjcbjka4674545</span>
		    			</div>
		    		</li>
	    		</router-link>
	    		<li>
	    			<div class="left_surname">
	    				<span>逗</span>
	    			</div>
	    			<div class="rightimg">
	    				<span>豆豆</span>
	    				<span>dhkoksahjkcjkbakjcbjka4674545</span>
	    			</div>
	    		</li>
	    	</ul>
	    </div>
	    
	</div>
</template>

<script>
	export default {
		data() {
			return {
				nocont:false,
				cont:true,
				value1: ''
			}
		},
		methods: {
			submitHandler(value) {
                this.$dialog.toast({mes: `搜索：${value}`});
            }
		},
	}
</script>
<style type="text/css">
	.Contacts .yd-search-input>.cancel-text{
		display: none;
	}
	.Contacts .yd-search-input:after, .yd-search-input:before{
		display: none;
	}
	.Contacts .yd-search-input{
		background: #fff;
	}
	.Contacts .yd-search-input>.search-input, .yd-search-input>.search-input .search-icon{
		border-radius: 10px;
		    background: #F5F6F6;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
.Contacts{
		.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			.leftSpan{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
			.rigtSpan{
				position: absolute;
				right: 15px;
				top: 50%;
				transform: translateY(-50%);
			}
			
		}
	.imgll{
		text-align: center;
		padding-top: 130px;
		img{
			width: 148px;
			height: 110px;
		}
		p{
			font-size: 12px;
			color: #AEAEAE;
		}
	}
	.cont{
		ul {
			li {
				overflow: hidden;
				margin: 15px;
				border-bottom: 1px solid #ECECEC;
				padding-bottom: 10px;
				.left_surname {
					float: left;
					width: 15%;
					text-align: center;
					line-height: 30px;
					span {
						width: 30px;
						height: 30px;
						border-radius: 50%;
						background-image: linear-gradient(-90deg, #2D7F86 2%, #04555D 100%);
						line-height: 30px;
						display: block;
						font-size: 14px;
						color: #FFFFFF;
					}
				}
				.rightimg{
					float: left;
					span{
						display: block;
						line-height: 16px;
					}
				}
			}
		}
	}			
}
</style>