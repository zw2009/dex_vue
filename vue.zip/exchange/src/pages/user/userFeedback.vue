<template>
	<div class="userFeedback">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>意见反馈</span>
			<img src="../../../static/img/dynamic_more.png" width="20" height="4"  />
		</div>
		<div class="title">SWTC钱包问题反馈</div>
		<div class="list">
			<p>类型<em>*</em></p>
			<select v-model='issue'>
				<option v-for="(item,index) in issues" :value='index' :key='index'>{{item.title}}</option>
			</select>
		</div>
		<div class="list">
			<p>设备<em>*</em></p>
			<select>
				<option>IOS</option>
				<option>安卓</option>
				<option>网页版</option>
			</select>
		</div>
		<div class="list">
			<p>设备<em>*</em></p>
			<span>如iPhone X，Huawei Mate9等。</span>
			<input type="text" name="" id="" value="" v-model="equipment" />
		</div>
		<div class="list">
			<p>系统版本<em>*</em></p>
			<span>如iOS 11，Android 5.0，网页版填写浏览器类型，如谷歌Chrome或Safari等。</span>
			<input type="text" name="" id="" value="" v-model="system" />
		</div>
		<div class="list">
			<p>APP版本号<em>*</em></p>
			<span>可在“关于我们”中查看。</span>
			<input type="text" name="" id="" value="" v-model="appsystem" />
		</div>
		<div class="list">
			<p>內容<em>*</em></p>
			<span>请详细填写您遇到的问题，操作步骤，便于我们查找原因。</span>
			<textarea v-model="content" style="width: 100%;height: 65px;padding:5px;" name="" rows="" cols=""></textarea>
		</div>
		<div class="list">
			<p>截图</p>
			<span>尽量提供截图，便于快速定位问题。</span>
			<div class="border">
				<img class="add" src="../../../static/img/problem_off.png" />
				<span>点此选择上传文件、限制5.0MB以内。仅支持：jpg、ipeg、png、gif、bmp、psd、tif。</span>
				<!--<input name="file" type="file" accept = "image/*" @change="upload($event)"/>-->
				<input type="file" name="file" id="file" value="" />
			</div>
		</div>
		<div class="list">
			<p>视频</p>
			<span>点此选择上传文件、限制每个20.0MB以内。</span>
			<div class="border" style="height: 25px;">
				<img style="margin-top: 5px;" class="add" src="../../../static/img/problem_off.png" />
				<span>点此选择上传文件、限制每个20.0MB以内。</span>
				<input type="file" name="file" id="file" value="" />
			</div>
		</div>
		<div class="list">
			<p>联系方式</p>
			<span>如果您愿意参与问题调试，请留下您的联系方式：QQ/微信，如有必要，我们会联系您。</span>
			<input type="text" name="" id="" value="" />
		</div>
		<div class="list" @click="Submit">
			<yd-button size="large" type="primary" shape="angle">提交</yd-button>
		</div>
		<yd-popup v-model="show" position="bottom">
			<div class="popup">
				<div class="round">
					<ul>
						<li><img src="../../../static/img/dynamic_refresh.png" /><span>刷新</span></li>
						<li><img src="../../../static/img/dynamic_copy.png" /><span>复制</span></li>
						<li><img src="../../../static/img/dynamic_browser.png" /><span>浏览器中打开</span></li>
					</ul>
					<span style="display: block;line-height: 40px;color: #888888;text-align: center;" @click="show = false">取消</span>
				</div>
			</div>
		</yd-popup>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				issue: 0,
				issues: [{
						title: '问题'
					},
					{
						title: '建议'
					},
				],
				show: false,
				equipment: '',
				system: '',
				appsystem: '',
				content: '',
			}
		},
		methods: {
			Submit() {
				if(!this.equipment) {
					this.$dialog.toast({
						mes: '设备必填，不能为空 ',
						timeout: 1000
					})
				} else if(!this.system) {
					this.$dialog.toast({
						mes: '系统版本必填，不能为空 ',
						timeout: 1000
					})
				} else if(!this.appsystem) {
					this.$dialog.toast({
						mes: 'APP版本必填，不能为空 ',
						timeout: 1000
					})
				} else if(!this.content) {
					this.$dialog.toast({
						mes: '内容版本必填，不能为空 ',
						timeout: 1000
					})
				} else {
					this.$dialog.confirm({
						title: '提示',
						mes: '您确定提交吗！',
						opts: [{
								txt: '取消',
								color: false,
							},
							{
								txt: '确定',
								color: true,
								callback: () => {
									this.$router.push('/user')
								}
							}
						]

					})
				}
			}
		}
	}
</script>
<style scoped src="@/style/style.css"></style>
<style>
	.yd-navbar:after{
		display: none!important;
	}
	.yd-confirm-hd {
		text-align: center!important;
		font-size: 18px!important;
		font-weight: 600!important;
	}
	.yd-btn-primary[data-v-62fe9860]:not(.yd-btn-loading){
		border-radius: 5px!important;
	}
	.yd-confirm {
		width: 280px;
		border-radius: 12px!important;
	}
	.yd-confirm-ft{
		border-top: 1px solid #f1f1f1!important;
	}
	.yd-confirm-ft>a.default {
		color: #007aff!important;
		border-right: 1px solid #f1f1f1!important;
		font-size: 17px!important;
	}
	.yd-confirm-ft>a.primary{
		color:#007aff!important;
		font-size: 17px!important;
	}
</style>
<style lang="less" scoped>
	.yd-btn-primary:not(.yd-btn-loading) {
		text-align: center;
		margin: 40px auto;
		width: 100%;
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
		border: 1px solid #05535C;
		color: #FFFFFF;
		height: 35px;
		line-height: 35px;
	}
	.userFeedback {
		.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			img{
				position: absolute;
				right: 15px;
				top: 50%;
				transform: translateY(-50%);
			}
			span{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
		}
		.title {
			display: block;
			font-family: PingFangSC-Semibold;
			font-size: 14px;
			color: #222222;
			padding: 20px 15px;
			font-weight: 600;
		}
		.list {
			padding: 10px 15px;
			select {
				width: 100%;
				height: 35px;
				padding-left: 5px;
			}
			input {
				width: 100%;
				height: 35px;
				line-height: 35px;
				outline: none;
				border: 1px solid #0000000;
				padding-left: 5px;
			}
			p {
				font-size: 14px;
				color: #222222;
				margin-bottom: 5px;
				em {
					color: red;
					font-size: 16px;
				}
			}
			span {
				padding-bottom: 5px;
				display: block;
				font-size: 10px;
			}
			.border {
				width: 100%;
				height: 40px;
				border: 1px dashed #C3C9CF;
				margin-bottom: 20px;
				overflow: hidden;
				position: relative;
				.add {
					float: left;
					width: 14px;
					height: 14px;
					margin: 12px;
				}
				span {
					margin-top: 3px;
					float: left;
					display: block;
					width: 80%;
					font-size: 10px;
					color: #04555D;
				}
				input {
					width: 300px;
					height: 90px;
					right: 0;
					top: 0;
					background: red;
					position: absolute;
					opacity: 0;
					display: block;
				}
			}
		}
		.popup {
			width: 100%;
			padding: 0 8px;
			.round {
				height: 135px;
				background: rgba(248, 248, 248, 0.82);
				border-radius: 14px;
				ul {
					border-bottom: 1px solid #3F3F3F;
					overflow: hidden;
					li {
						float: left;
						width: 25%;
						text-align: center;
						img {
							width: 40px;
							height: 40px;
							margin-top: 20px;
							margin-bottom: 5px;
						}
						span {
							display: block;
							padding-bottom: 12px;
						}
					}
				}
				p {
					padding-top: 12px;
					font-size: 17px;
					color: #828282;
					text-align: center;
				}
				span {}
			}
		}
	}
</style>