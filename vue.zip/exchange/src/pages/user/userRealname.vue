<template>
	<div class="userRealname">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>实名信息</span>
		</div>	 
		<ul>
			<li>
				<span>姓名</span>
				<em>张*</em>
			</li>
			<li>
				<span>身份证号</span>
				<em>4402221******81234</em>
			</li>
			<li>
				<span>银行卡号</span>
				<em>62145******11793</em>
			</li>
			<li>
				<span>手机号</span>
				<em>1366***56334</em>
			</li>
		</ul>
	</div>
</template>

<script>
	export default {
		data() {
			return {
			}
		},
		methods: {
			
		},
	}
</script>

<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.userRealname{
		ul{
			li{
				line-height: 50px;
				overflow: hidden;
				margin-left: 15px;
				border-bottom: 1px solid #F6F6F6;
				span{
					float: left;
					display: block;
					width: 30%;
					}
				em{
					width: 70%;
					text-align: right;
					float: right;
					padding-right: 15px;
					color: #B8B8B8;
				}
			}
		}
	}
</style>