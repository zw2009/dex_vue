<template>
	<div class="userRecord">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>交易记录</span>
		</div>
	    <ul>
	    	<router-link to="transactionDetails">
		    	<li v-for="item in list">
		    		<span class="leftSpan">{{item.ids}}</span>
		    		<div class="rightSpan">
		    			<div class="topTpye">
		    				<span class="leftSpanss">{{item.name}}</span>
		    				<span class="rightTime">{{item.time}}</span>
		    			</div>
		    			<span class="typess">{{item.num}}</span>
		    		</div>
		    	</li>
	    	</router-link>
	    </ul>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				list:[
					{ids:'豆',name:'+ 35.0 SWTC',time:'10:56',num:'dhkoksahjkcjkbakjcbjka4674545'},
					{ids:'心',name:'心累',time:'10:56',num:'dhkoksahjkcjkbakjcbjka4674545'},
				]
			}
		},
		methods: {
			
		},
	}
</script>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.userRecord{
		ul{
			padding: 0 15px;
			li{
				width: 100%;
				overflow: hidden;
				border-bottom: 1px solid #ECECEC;
				.leftSpan{
					float: left;
					display: block;
					text-align: center;
					line-height: 35px;
					background: #04555D;
					color: white;
					width: 30px;
					height: 30px;
					border-radius: 50%;
					margin: 10px 0;
				}
				.rightSpan{
					padding-top: 12px;
					padding-left: 10px;
					width: 90%;
					float: left;
					display: block;
					.topTpye{
						padding-bottom: 2px;
						overflow: hidden;
						.leftSpanss{
							font-size: 12px;
							color: #222222;
							float: left;
							display: block;
						}
						.rightTime{
							display: block;
							float: right;
							font-size: 10px;
							color: #A1A4AC;
						}
					}
					.typess{
						display: block;
					}
				}

			}
		}
	}
</style>