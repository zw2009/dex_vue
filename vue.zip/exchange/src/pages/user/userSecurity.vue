<template>
	<div class="security">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>安全中心</span>
		</div>
	    
	    <yd-cell-group>
	        <yd-cell-item arrow href="setPhone" type="link">
	            <span slot="left">手机号</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;">暂无</span>
	        </yd-cell-item>
	        <yd-cell-item arrow href="setEmail" type="link">
	            <span slot="left">邮箱</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;">236243520@qq.com</span>
	        </yd-cell-item>
	        <yd-cell-item arrow href="#" type="link">
	            <span slot="left">验证码发送至</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;">236243520@qq.com</span>
	        </yd-cell-item>
	        <yd-cell-item arrow href="setLongin" type="link">
	            <span slot="left">登陆密码</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;"></span>
	        </yd-cell-item>
	         <yd-cell-item arrow href="setAssets" type="link">
	            <span slot="left">资产密码</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;"></span>
	        </yd-cell-item>
	    </yd-cell-group>    
	</div>
</template>

<script>
	export default {
		data() {
			return {
				start:''
			}
		},
		methods: {
		},
	}
</script>
<style lang="less" scoped>
.security{

			.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			span{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
		}
			
}
</style>