<template>
	<div class="userSendcontacts">
		<div class="onePage" v-show="onePage">
		<div class="top-back">
			<router-link to="userContacts">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>发送</span>
		</div>
		<div class="topUl">
		<ul>
			<li>
				<span>接收方</span>
				<input style="width: 45%;" type="" name="" id="" value="" placeholder="接收方"/>
				<div class="twoimg">
					<img @click="scan" class="miyao" src="../../../static/img/contact_scanning.png" width="16px" height="16px"/>
					<img @click="show1 = true" class="contact" src="../../../static/img/trading_icon_one.png" width="16px" height="16px"/>
				</div>
				
			</li>
			<li>
				<span>数量</span>
				<input type="" name="" id="" value="" placeholder="数量"/>
				<em>STWC</em>
			</li>
			
			<li>
				<span>备注</span>
				<input style="width: 60%;" type="" name="" id="" value="" placeholder="备注"/>
				<i class="rightBrackets"></i>
			</li>
		</ul>
		</div>
		<yd-button @click.native="sss" size="large" type="primary"  shape="angle">发送</yd-button>
		<div class="notice">
			<p>发送须知</p>
			<span>1，只能往SWTC公链上生成的钱包地址里发送资产。</span>
			<span>2,地址必须是以字母"J"开头的，注意识别</span>
			<span>3,如接收方钱包地址填写错误赵成的资产损失，责任自负</span>
		</div>
		  <yd-popup v-model="show2" position="bottom" height="60%">
		  	<div class="dedail">
		  		<div class="titleP">
		  			<img @click="Closeimg" src="../../../static/img/top_wrong.png"/>
		  			<p>发送详情</p>
		  		</div>
		  		<div class="infor" v-show="infor">
			  		<ul>
			  			<li>
			  				<span class="leftSp">发送方</span>
			  				<span class="rightSp">jsmrrgfdgthdfghddaw2543dfghwsdfgsgd</span>
			  			</li>
			  			<li>
			  				<span class="leftSp">接收方</span>
			  				<span class="rightSp">jsmrrgfdgthdfghddaw2543dfghwsdfgsgd</span>
			  			</li>
			  			<li>
			  				<span class="leftSp">数量 SWTC</span>
			  				<span class="rightSp">1</span>
			  			</li>
			  			<li>
			  				<span class="leftSp">备注</span>
			  				<span class="rightSp">15697</span>
			  			</li>
			  		</ul>
			  		<div class="Next">
				  		<yd-button @click.native="Next" size="large" type="primary"  shape="angle">下一步</yd-button>
				  	</div>
			  	</div>
			  	<div class="assets" v-show="asinput">
			  		<input type="password" name="" id="" value=""  placeholder="资产密码" />
			  		<div class="Send">
			  			<yd-button @click.native="Nexttwo" size="large" type="primary"  shape="angle">确定</yd-button>
			  		</div>
			  	</div>
		  	</div>
		  	
		  </yd-popup>
		  </div>
		  <div class="twoPage" v-show="twoPage">
		  		<img src="../../../static/img/record_for.png"/>
		  		<p>发送成功</p>
		  		<div class="Close">
		  			<yd-button @click.native="Close" size="large" type="primary"  shape="angle">关闭</yd-button>
		  		</div>
		  </div>
		  <yd-popup v-model="show1" position="center" width="75%">
            <div class="Popup">
            	<p>钱包地址</p>
            	<img src="../../../static/img/record_picture.png"/>
            	<span style="color: #04555D;display: block;padding-bottom: 30px;">保存二维码</span>
            	<span>{{secret}}</span>
           		<div class="clickButton" @click="copy" style="width: 60%;margin: 0 auto;line-height: 35px;">
					<button>复制地址</button>
				</div>
            </div>
        </yd-popup>
		  
	</div>
</template>

<script>
	export default {
		data() {
			return {
				secret:'bcjkdsbjabcjkdbsvkjabvjkdsbvkjbjkavbaskv',
				onePage:true,
				show2:false,
				show1: false,
				infor:true,
				asinput:false,
				twoPage:false
			}
		},
		methods: {
			Next(){
				this.infor = false 
				this.asinput = true
			},
			Nexttwo(){
				this.onePage =  false
				this.twoPage = true
			},
			sss(){
				this.show2 = true
				this.infor =  true
				this.asinput = false
			},
			Close(){
				this.$router.replace('/userContacts')
			},
			Closeimg(){
				this.show2 = false 
			},
			copy(){
				cordova.plugins.clipboard.copy(this.secret);
                cordova.plugins.clipboard.paste(function (text) {  });
			},
            scan(){
                var that = this
                cordova.plugins.barcodeScanner.scan(
                        function (result) {
                        	alert(result.text,111)
                        },
                        function (error) {
                          alert(error,222)
                        },
                        {
                            preferFrontCamera: false, // 设置前置摄像头
                            showFlipCameraButton: true, // 显示旋转摄像头按钮
                            showTorchButton: true, // 显示手电筒
                            torchOn: false, // 默认开启手电筒
                            saveHistory: false, // Android, save scan history (default false)
                            prompt: "将二维码放入框内, 可自动扫描",
                            resultDisplayDuration: 500, // 多久开始识别
                            formats: "QR_CODE", // default: all but PDF_417 and RSS_EXPANDED
                            orientation: "portrait", // 竖屏portrait，横屏landscape
                            disableAnimations: false, // 禁止动画
                            disableSuccessBeep: false // 禁用成功蜂鸣声
                        }
                    )
            },
		},
	}
</script>

<style type="text/css">
	.userSendcontacts .yd-btn-primary:not(.yd-btn-loading){
		text-align: center;
		margin:  120px auto 40px auto;
		width: 90%;
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
		color: #FFFFFF ;
		height: 35px;
		line-height: 35px;
		border-radius: 5px;
	}
	.Next .yd-btn-primary:not(.yd-btn-loading){
		margin:  20px auto 20px auto;
	}
	.Send .yd-btn-primary:not(.yd-btn-loading){
		margin:  80px auto 20px auto;
	}
	.Close .yd-btn-primary:not(.yd-btn-loading){
		margin:  130px auto 20px auto;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.userSendcontacts{
		.Popup{
			background-color:#FCFCFC;text-align: center;border-radius: 12px!important;
			p{
				font-size: 14px;
				color: #222222;
				line-height: 60px;
			}
			img{
				width: 120px;
				height: 120px;
				margin-bottom: 30px;
			}
		}
		.twoPage{
			text-align: center;			
			img{
				width: 65px;
				height: 65px;
				margin-top: 120px;
				margin-bottom: 80px;
			}
			p{
				font-size: 16px;
				color: #222222;
			}
		}
			.dedail{
				.assets{
					border-bottom: 1px solid #F6F6F6;
					input{
						width: 80%;
						margin: 120px auto 0 auto;
						display: block;
						text-align: center;
						border:none;
						line-height: 50px;
					}
				}
				ul{
					padding-top: 40px;
					li{
						overflow: hidden;
						height: 50px;
						.leftSp{
							width: 30%;
							padding-left: 15px;
							float: left;
							display: block;
						}
						.rightSp{
							display: block;
							width: 68%;
							padding-right: 15px;
							float: right;
							text-align: right;
						}
					}
				}
				.titleP{
					position: relative;
					text-align: center;
					line-height: 42px;
					p{
						font-size: 14px;
						color: #4E4E4E;
					}
					img{
						width: 13px;
						height: 13px;
						position: absolute;
						left: 15px;
						top: 50%;
						transform: translateY(-50%);
					}
				}
			}
			.topUl{

			ul{
				li{
					height: 50px;
					line-height: 50px;
					overflow: hidden;
					margin-left: 15px;
					border-bottom: 1px solid #F6F6F6;
					position: relative;
					span{
						float: left;
						display: block;
						width: 30%;
					}
					input{
						width: 53%;
						border: none;
						line-height: 50px;
						float: left;
						text-align: right;
						font-size: 14px;
					}
					::-webkit-input-placeholder { /* WebKit browsers */
						    color:  #B8B8B8;
						}
					em{
						width: 13%;
						float: right;
						padding-right: 10px;
					}
					.twoimg{
						float: right;
						width: 23%;
						overflow: hidden;
						/*padding-right: 15px;*/
						.miyao{
							margin: 15px 14px;
							float: left;
						}
						.contact{
							float: left;
							margin: 15px 0;
						}
					}
					
				}
			}
							
			}
			.notice{
				padding-left: 15px;
				p{
					color: #000000;
					line-height: 40px;
				}
				span{
					display: block;
					line-height: 20px;
					color: #333333;
				}
			}
	}
</style>