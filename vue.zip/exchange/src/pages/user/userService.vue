<template>
	<div  class="information_windows">
		<yd-navbar  color="#fff" title="官方客服" fontsize="17px" >
	        <router-link to="/user" slot="left">
	            <yd-navbar-back-icon color="#fff"></yd-navbar-back-icon>
	        </router-link>
	    </yd-navbar>   

	</div>
</template>
<script>
    import msgItem from "@/components/msg-item"
	export default{
		data(){
			return{
				read:true,
			}
		},
		methods:{

        },
        components: {
            msgItem
        },
	}
</script>
<style lang="less">
	.desc-time{
		padding-top: 20px;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.information_windows{
		.information_header{
			width: 100%;
			height: 0.88rem;
			background: #91C3D2;
			box-sizing: border-box;
			padding: 0.22rem 0.22rem;
			position: relative;
			.chatroom_name{
				margin: 0 auto;
				width: 1.6rem;
				text-align: center;
				span{
					color:#ffffff;
					font-size: 0.32rem;
					width:0.96rem;
					vertical-align: 0.04rem;
				}
			}
				.img_edit{
					display: inline-block;
					width: 0.34rem;
					height: 0.38rem;
					position: absolute;
					right: 15px;
					top: 15px;

				}
		}
		
	}
</style>