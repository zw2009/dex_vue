<template>
	<div class="Set">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>设置</span>
		</div>
		<div class="contentSet">
		<yd-cell-group>
	        <yd-cell-item arrow @click.native="activeGC">
	            <span slot="left">语言</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;">简体中文</span>
	        </yd-cell-item>
	         <yd-cell-item arrow @click.native="showpopup = true">
	            <span slot="left">货币单位</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;">CNY</span>
	        </yd-cell-item>
	        <yd-cell-item arrow  @click.native="showpopup = true" >
	            <span slot="left">行情样式</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;">竖版</span>
	        </yd-cell-item>
	         <yd-cell-item arrow @click.native="showpopup = true" >
	            <span slot="left" >盘口样式</span>
	            <span slot="right" style="font-size: 10px; color: #B8B8B8;">竖版</span>
	        </yd-cell-item>
	    </yd-cell-group>
	    <!--<yd-button size="large" type="primary" shape="angle" @click.native="Authe">退出登入</yd-button>-->
	    <yd-button size="large" type="primary" @click.native="out" shape="angle">退出登入</yd-button>
		<!--<vue-pickers
	          :show="show"
	          :columns="columns"
	          :selectData="pickData"
	          @cancel="close"
	          @confirm="confirmFn"
	          >
      	</vue-pickers>-->
      	
        <!--<yd-popup v-model="show4" position="bottom" height="60%" >
      		<div class="popupBottom" style="width:300px ;margin: 0 auto;height: 200px;">
      			<span>啊都是克己奉公</span>
      		</div>   
        </yd-popup>-->
     
      	<!--<div class="box" v-show="show2" @click="Close"></div>
      	<div v-show="show2" class="popupBottom">      	
	      		<div class="contetxx">
		      		<div class="oneChoice" style="width: 100%;margin-bottom: 20px;">
		      			<ul>
		      				<li @click="li1" style="border-bottom: 1px solid #ececec; border-radius: 12px 12px 0 0;">
		      					<span style="display: block;">确定</span>
		      				</li>
		      				<li @click="li2" style="border-radius:0 0 12px 12px;">
		      					<span style="display: block;">确定2</span>
		      				</li>
		      			</ul>
		      		</div>
		      		<div class="clickClose" @click="show2 = false">
		      			<span style="display: block;">取消</span>
		      		</div>
	      		</div>
      	</div>-->
	    </div>
        <yd-popup v-model="showpopup" position="bottom" width="95%">
     	  	<div class="popup">
     	  		<div class="oneChoice" style="width: 100%;">
	      			<ul>
	      				<li @click="li1" style="border-bottom: 1px solid #ececec;border-radius: 12px 12px 0 0!important;">
	      					<span style="display: block;">确定</span>
	      				</li>
	      				<li @click="li2" style="border-radius: 0 0 12px 12px!important;">
	      					<span style="display: block;">确定2</span>
	      				</li>
	      				<li style="background:#7f7f7f!important;height: 20px;width: 100%;">
	      					
	      				</li>
	      				<li class="clickClose" style="border-radius: 12px;">
			      			<span style="display: block;">取消</span>
				      	</li>
				      	<li style="background:#7f7f7f!important;height: 10px;width: 100%;">
	      					
	      				</li>
	      			</ul>
	      		</div>
    	    </div>
    	   
        </yd-popup>
        
	</div>
</template>
<script>
	import vuePickers from 'vue-pickers'
	import { removeStore,getStore } from '@/common/storage'
	export default {
		data() {
			return {
				pickData:{},
				isA:false,
				columns: 1,
				show2:false,
				show:false,
				show4:false,
				showpopup:false,
			}
		},
		 components:{
			vuePickers
		},
		methods: {
			Close(){
//				this.popupBottomclose = true
				this.show2 = false
			},
			li1(){
				console.log(111111)
			},
			li2(){
				console.log(222222)
			},
//			Authe() {
//				this.$dialog.confirm({
//					title: '提示',
//					mes: '您确定退出登陆吗！',
//					opts: [{
//							txt: '取消',
//							color: false,
//						},
//						{
//							txt: '确定',
//							color: true,
//							callback: () => {
////								this.$api.outlogin({}, res => {
////									console.log(res)
////									if(res.status) {
////										removeStore('user_token')
////                                      removeStore('twopassword')
//										this.$router.replace('/login')
////									}
////								})
//							}
//						}
//					]
//				})
//			},
			out(){
				this.$router.replace('/login')
			},
//			out(){
//				this.$dialog.confirm({
//					title:'提示',
//					mes:'您确定退出登录吗？',
//					opts:[{
//						txt:'取消',
//						color:false,
//					},
//					{
//						txt:'确定',
//						color:true,
//						callback:() => {
//							this.$api.logout({},res =>{
//								console.log(res)	
//								if(res.status) {
//									this.$router.replace('/login')
////									removeStore('user_token')
//								}
//							})
//						}
//					}
//					]
//				})
//			},
			 activeGC() {
			 console.log(222)
               this.pickData = {
                    data1:[
                        {
                            text:'简体中文',
                            value:'11'
                        },
                        {
                            text: '简体繁体',
                            value: '12',
                        }, {
                            text: '英语',
                            value: '13',
                        },]
                },
                this.show = true;
            },
             confirmFn(val) {
              this.show = false
//            this.$refs.package_type.innerHTML='您选择'+val.select1.text
//            this.option = val.select1.value
            },
            close() {
              this.show = false
            }
		}
	}
</script>
<style type="text/css">
	.Set .yd-popup{
		width: 94%!important;
	    margin-left: 3%;
	    margin-right: 3%;
	    border-radius: 12px;
	    height: auto;
	    background:#7f7f7f!important; 
	    /*background: rgb(0, 0, 0)!important;*/
	    /*opacity: 0.5;*/
	}
	.oneChoice ul li{
		background: #FFFFFF!important; text-align: center;line-height: 50px;font-size:18px;
	}
	.oneChoice ul li span{
		display: block;
		color: red;
	}
	.clickClose{
		background: #FFFFFF!important;width: 100%;line-height: 40px;text-align: center;font-size: 18px;
	}
	.popupBottom{
		position: relative;bottom: 0;left: 0;width: 90%;margin-left: 5%;margin-right: 5%;z-index: 12;
		animation:mymove 0.3s infinite;
		-webkit-animation:mymove 0.3s infinite; /*Safari and Chrome*/
		animation-iteration-count:1;
		/*webkit-animation:'index' 5s ease-in-out 0s 1 alternate forwards;*/
		
	}
	@keyframes mymove
	{
	from {top:200px;}
	to {top:0px;}
	}
	@-webkit-keyframes mymove /*Safari and Chrome*/
	{
	from {top:0px;}
	to {top:0;}
	}
	/*.Set .box{
		position: fixed;
		top: 0;
		width: 100%;
		height: 100%;
		background-color: rgb(0, 0, 0);
  		opacity: 0.5;
		z-index: 10;
	}*/
	.contentSet .yd-btn-primary:not(.yd-btn-loading){
		text-align: center;
		margin:  74px auto;
		width: 90%;
		background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
		border: 1px solid  #05535C ;
		color: #FFFFFF ;
		height: 45px;
		line-height: 45px;
		border-radius: 6px;
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.Set{
	.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			span{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
		}
	}	
</style>