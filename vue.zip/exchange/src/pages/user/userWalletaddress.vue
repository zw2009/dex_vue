<template>
	<div class="Walleaddress">
		<div class="top-back">
			<router-link to="user">
				<div class="click"></div>
				<em></em>
			</router-link>
			<span>备份私钥</span>
		</div>	    
	    
	    
	    <div class="erm">
	    	<img src="../../../static/img/record_picture.png"/>
	    	<p class="testP">保存二维码</p>
	    	<p class="testPP">bcjkdsbjabcjkdbsvkjabvjkdsbvkjbjkavbaskv</p>
	    	<button class="copy">复制地址</button>
	    	<!--<button  @click="show1 = true" class="backups">备份私钥</button>-->
	    </div>
	    <!--<yd-popup v-model="show1" position="center" width="75%">
            <div class="Popup">
                <p style="padding-top: 21px;font-size: 16px;color: #030303;">身份验证 </p>
                <p style="margin-top: 10px;font-size: 13px;color: #030303;padding-bottom: 20px;"> 验证码已发送至2*******0@qq.com</p>
                <input  type="" name="" id="" value="" placeholder="验证码"/>
                <input style="margin-bottom: 34px;border-top: none;" type="" name="" id="" value="" placeholder="获取私钥"/>
           		<div class="Obtain" style="">
           			<span @click="show1 = false" style="width: 49%;float: left;border-right: 1px solid #4D4D4D;">取消</span>
           			<span style="float: right;">获取秘钥</span>
           		</div>
            </div>
        </yd-popup>-->
	    
	</div>
</template>

<script>
	export default {
		data() {
			return {
//				show1: false,
			}
		},
		methods: {
			
		},
	}
</script>
<style type="text/css">
	.Walleaddress .yd-popup-center.yd-popup-show *{
	    pointer-events: auto;
   		/*border-radius: 12px;*/
	}
</style>
<style scoped src="@/style/style.css"></style>
<style lang="less" scoped>
	.Walleaddress{
		.Popup{
			background-color:#FCFCFC;text-align: center;border-radius: 12px!important;
			input{
				line-height: 24px;padding-left: 5px;width: 80%;border: 1px solid #4D4D4D;
			}
			.Obtain{
				border-top: 1px solid #4D4D4D;overflow: hidden;border-radius: 1px!important;line-height: 43px;
				span{
					font-size: 17px;color: #007AFF;width: 50%;text-align: center;display: block;
				}
			}
		}
		.top-back{
			position: relative;
			line-height: 50px;
			em{
				display: block;
				width: 12px;
				height: 12px;
				border-left: .02rem solid #000;
				border-bottom: .02rem solid #000;
				position: absolute;
				top: 50%;
				left:15px;
				transform: translate(0,-50%) rotate(45deg) ;
			}
			span{
				display: block;
				font-size: 16px;
				color: #434A59;
				padding-left: 40px;
			}
		}
		.erm{
			text-align: center;
			padding-top: 74px;
			img{
				width: 120px;
				height: 120px;
				margin-bottom: 30px;
			}
			.testP{
				font-size: 12px;
				color: #04555D;
			}
			.testPP{
				padding: 30px 0;
			}
			.copy{
				width: 50%;
				margin-bottom: 20px;
				background-image: linear-gradient(-180deg, #2D7F86 2%, #04555D 97%);
				border-radius: 4px;
				line-height: 35px;
				color: #FFFFFF;
				border: none;
			}
			.backups{
				width: 50%;
				border: 1px solid #979797;
				line-height: 35px;
				color: #04555D;
			}
		}
	}
</style>