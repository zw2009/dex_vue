
const routers = [
	{
		path: '/',
		redirect: '/index'
	},
	{
	 	path:'/index',
	 	component: resolve => require(['@/pages/Index'], resolve),
	 	name: 'Index'
	},
	{
	 	path:'/assets',
	 	component: resolve => require(['@/pages/asset/assets'], resolve),
	 	name: 'assets'
	},
	{
	 	path:'/dynamics',
	 	component: resolve => require(['@/pages/dynamic/dynamics'], resolve),
	 	name: 'dynamics'
	},
	{
	 	path:'/assetsDetails',
	 	component: resolve => require(['@/pages/asset/assetsDetails'], resolve),
	 	name: 'assetsDetails'
	},
	{
	 	path:'/dynamicsDetails',
	 	component: resolve => require(['@/pages/dynamic/dynamicsDetails'], resolve),
	 	name: 'dynamicsDetails'
	},
	{
	 	path:'/transactionsEntrust',
	 	component: resolve => require(['@/pages/transaction/transactionsEntrust'], resolve),
	 	name: 'transactionsEntrust'
	},
	{
	 	path:'/transactions',
	 	component: resolve => require(['@/pages/transaction/transactions'], resolve),
	 	name: 'transactions'
	},
	{
	 	path:'/transactionDetails',
	 	component: resolve => require(['@/pages/transaction/transactionDetails'], resolve),
	 	name: 'transactionDetails'
	},
	{
	 	path:'/graph',
	 	component: resolve => require(['@/pages/graph/graph'], resolve),
	 	name: 'graph'
	},
	{
	 	path:'/user',
	 	component: resolve => require(['@/pages/user/user'], resolve),
	 	name: 'user'
	},
	{
	 	path:'/userAuthentication',
	 	component: resolve => require(['@/pages/user/userAuthentication'], resolve),
	 	name: 'userAuthentication'
	},
	{
	 	path:'/userSecurity',
	 	component: resolve => require(['@/pages/user/userSecurity'], resolve),
	 	name: 'userSecurity'
	},
	{
	 	path:'/userAbout',
	 	component: resolve => require(['@/pages/user/userAbout'], resolve),
	 	name: 'userAbout'
	},
	{
	 	path:'/userFeedback',
	 	component: resolve => require(['@/pages/user/userFeedback'], resolve),
	 	name: 'userFeedback'
	},
	{
	 	path:'/userSet',
	 	component: resolve => require(['@/pages/user/userSet'], resolve),
	 	name: 'userSet'
	},
	{
	 	path:'/setPhone',
	 	component: resolve => require(['@/pages/set/setPhone'], resolve),
	 	name: 'setPhone'
	},
	{
	 	path:'/setEmail',
	 	component: resolve => require(['@/pages/set/setEmail'], resolve),
	 	name: 'setEmail'
	},
	{
	 	path:'/setAssets',
	 	component: resolve => require(['@/pages/set/setAssets'], resolve),
	 	name: 'setAssets'
	},
	{
	 	path:'/setLongin',
	 	component: resolve => require(['@/pages/set/setLongin'], resolve),
	 	name: 'setLongin'
	},
	{
	 	path:'/userWalletaddress',
	 	component: resolve => require(['@/pages/user/userWalletaddress'], resolve),
	 	name: 'userWalletaddress'
	},
	{
	 	path:'/userWallet',
	 	component: resolve => require(['@/pages/user/userWallet'], resolve),
	 	name: 'userWallet'
	},
	{
	 	path:'/userContacts',
	 	component: resolve => require(['@/pages/user/userContacts'], resolve),
	 	name: 'userContacts'
	},
	{
	 	path:'/userRecord',
	 	component: resolve => require(['@/pages/user/userRecord'], resolve),
	 	name: 'userRecord'
	},
	{
	 	path:'/userService',
	 	component: resolve => require(['@/pages/user/userService'], resolve),
	 	name: 'userService'
	},
	{
	 	path:'/login',
	 	component: resolve => require(['@/pages/login/login'], resolve),
	 	name: 'login'
	},
	{
	 	path:'/register',
	 	component: resolve => require(['@/pages/register/register'], resolve),
	 	name: 'register'
	},
	{
	 	path:'/retrieve',
	 	component: resolve => require(['@/pages/retrieve/retrieve'], resolve),
	 	name: 'retrieve'
	},
	{
	 	path:'/ctwoc',
	 	component: resolve => require(['@/pages/ctwoc/ctwoc'], resolve),
	 	name: 'ctwoc'
	},
	{
	 	path:'/ctwocBankcard',
	 	component: resolve => require(['@/pages/ctwoc/ctwocBankcard'], resolve),
	 	name: 'ctwocBankcard'
	},
	{
	 	path:'/ctwocAddcard',
	 	component: resolve => require(['@/pages/ctwoc/ctwocAddcard'], resolve),
	 	name: 'ctwocAddcard'
	},
	{
	 	path:'/userAddcontacts',
	 	component: resolve => require(['@/pages/user/userAddcontacts'], resolve),
	 	name: 'userAddcontacts'
	},
	{
	 	path:'/userSendcontacts',
	 	component: resolve => require(['@/pages/user/userSendcontacts'], resolve),
	 	name: 'userSendcontacts'
	},
	{
	 	path:'/userRealname',
	 	component: resolve => require(['@/pages/user/userRealname'], resolve),
	 	name: 'userRealname'
	},
//	{
//	 	path:'/ctwocOrder',
//	 	component: resolve => require(['@/pages/ctwoc/ctwocOrder'], resolve),
//	 	name: 'ctwocOrder'
//	},
//	{
//	 	path:'/ctwocOrderdedetails',
//	 	component: resolve => require(['@/pages/ctwoc/ctwocOrderdedetails'], resolve),
//	 	name: 'ctwocOrderdedetails'
//	},
	{
	 	path:'/assetSelection',
	 	component: resolve => require(['@/pages/asset/assetSelection'], resolve),
	 	name: 'assetSelection'
	},
//	{
//	 	path:'/changshi',
//	 	component: resolve => require(['@/pages/user/changshi'], resolve),
//	 	name: 'changshi'
//	},
	{
	 	path:'/otc',
	 	component: resolve => require(['@/pages/otc/otc'], resolve),
	 	name: 'otc'
	},
	{
	 	path:'/otcTrust',
	 	component: resolve => require(['@/pages/otc/otcTrust'], resolve),
	 	name: 'otcTrust'
	},
	{
	 	path:'/otcBuy',
	 	component: resolve => require(['@/pages/otc/otcBuy'], resolve),
	 	name: 'otcBuy'
	},
	{
	 	path:'/otcSell',
	 	component: resolve => require(['@/pages/otc/otcSell'], resolve),
	 	name: 'otcSell'
	},
	{
	 	path:'/otcPublish',
	 	component: resolve => require(['@/pages/otc/otcPublish'], resolve),
	 	name: 'otcPublish'
	},
	{
	 	path:'/otcAlipay',
	 	component: resolve => require(['@/pages/otc/otcAlipay'], resolve),
	 	name: 'otcAlipay'
	},
	{
	 	path:'/otcWechat',
	 	component: resolve => require(['@/pages/otc/otcWechat'], resolve),
	 	name: 'otcWechat'
	},
	{
	 	path:'/otcOrder',
	 	component: resolve => require(['@/pages/otc/otcOrder'], resolve),
	 	name: 'otcOrder'
	},
	{
	 	path:'/otcPoster',
	 	component: resolve => require(['@/pages/otc/otcPoster'], resolve),
	 	name: 'otcPoster'
	},
	{
	 	path:'/otcAccount',
	 	component: resolve => require(['@/pages/otc/otcAccount'], resolve),
	 	name: 'otcAccount'
	},
	{
	 	path:'/otcSellposter',
	 	component: resolve => require(['@/pages/otc/otcSellposter'], resolve),
	 	name: 'otcSellposter'
	},
	{
	 	path:'/otcAddcard',
	 	component: resolve => require(['@/pages/otc/otcAddcard'], resolve),
	 	name: 'otcAddcard'
	},
	{
	 	path:'/otcBuyorder',
	 	component: resolve => require(['@/pages/otc/otcBuyorder'], resolve),
	 	name: 'otcBuyorder'
	},
	
	
	{
	 	path:'/areaCode',
	 	component: resolve => require(['@/pages/areaCode/areaCode'], resolve),
	 	name: 'areaCode'
	},
	{
	    path:'/countryCode',
	    component: resolve => require(['@/pages/register/registerPhoneCode'], resolve),
	    name:'countryCode'
	  },
	{
	 	path:'/changshikx',
	 	component: resolve => require(['@/pages/transaction/changshikx'], resolve),
	 	name: 'changshikx'
	},
]
export default routers
